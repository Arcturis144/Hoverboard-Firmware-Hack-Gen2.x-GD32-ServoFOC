#!/usr/bin/env python3
"""Apply audited Gyroor G5 Phase-3 firmware integration and Keil Studio support.

The existing GD32F130 µVision target remains the authoritative hardware/project
definition. This wrapper applies the Phase-3 firmware patch, including optional
main-loop g5mon monitoring, then installs only editor/tool-environment support
needed to convert that GD32 target to a CMSIS Solution inside Arm Keil Studio
for VS Code.

It does NOT build, flash, or enable the motor bridge.
"""
from __future__ import annotations

import argparse
import hashlib
import shutil
import subprocess
import sys
import re
from pathlib import Path

EXPECTED_DEVICE = "<Device>GD32F130C8</Device>"
EXPECTED_TARGET = "<TargetName>GD32F130</TargetName>"
EXPECTED_PACK = "GigaDevice.GD32F1x0_DFP.3.2.1"
SAFE_DEFINE_RE = re.compile(r"^\s*#define\s+FOC_SAFE_BRINGUP\s+1(?:\s|$)", re.MULTILINE)
AI_GUIDELINES = {
    "ai_guidelines.md": "c7d826a77008232db08e7e9cb472b9cf57701dae",
    "ai_guidelines_v0.md": "4361e659dfbaad2dfeca2c3e299910e8aadc86bd",
    "ai_guidelines_v1.md": "fd95d97ccbf662585ec53ef58c0c633c1b37cc9d",
}
EFERU_GUARD = "GYROOR_G5_EFERU_BLDC_FOC_GUARD"


def git_blob_sha1(data: bytes) -> str:
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()


def copy_file(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() and dst.read_bytes() == src.read_bytes():
        print(f"already installed {dst}")
        return
    if dst.exists():
        bak = dst.with_suffix(dst.suffix + ".keilstudio.bak")
        if not bak.exists():
            shutil.copy2(dst, bak)
    shutil.copy2(src, dst)
    print(f"installed {dst}")


def validate_ai_guidelines(root: Path) -> None:
    for rel, expected in AI_GUIDELINES.items():
        p = root / rel
        if not p.is_file():
            raise RuntimeError(f"Required AI guideline missing: {rel}")
        actual = git_blob_sha1(p.read_bytes())
        if actual != expected:
            raise RuntimeError(
                f"AI guideline drift after patch: {rel}; audited={expected}, current={actual}"
            )


def require_text(text: str, needle: str, label: str) -> None:
    if needle not in text:
        raise RuntimeError(f"Validation failed: {label}")


def validate_repo(root: Path) -> None:
    validate_ai_guidelines(root)

    hg = root / "HoverBoardGigaDevice"
    project = hg / "Hoverboard.uvprojx"
    foc_config = hg / "Inc" / "foc_config.h"
    config = hg / "Inc" / "config.h"
    layout = hg / "Inc" / "defines" / "defines_2-1-20.h"
    bldc_h = hg / "Inc" / "bldc.h"
    main_c = hg / "Src" / "main.c"
    setup_c = hg / "Src" / "setup.c"
    foc_c = hg / "Src" / "bldcFOC.c"
    cap_c = hg / "Src" / "driveCapability.c"
    mon_c = hg / "Src" / "g5Monitor.c"
    ctrl_c = hg / "Src" / "BLDC_controller.c"
    data_c = hg / "Src" / "BLDC_controller_data.c"

    required_files = [
        hg / "Inc" / "bldcFOC.h",
        hg / "Inc" / "driveCapability.h",
        hg / "Inc" / "g5Monitor.h",
        foc_c, cap_c, mon_c, ctrl_c, data_c,
        hg / "Inc" / "BLDC_controller.h",
        hg / "Inc" / "rtwtypes.h",
    ]
    missing = [str(p.relative_to(root)) for p in required_files if not p.is_file()]
    if missing:
        raise RuntimeError("Missing Phase-3 files after patch:\n  " + "\n  ".join(missing))

    ptxt = project.read_text(encoding="utf-8")
    for marker, label in [
        (EXPECTED_TARGET, "GD32F130 target not found in Hoverboard.uvprojx"),
        (EXPECTED_DEVICE, "GD32F130C8 device not found in Hoverboard.uvprojx"),
        (EXPECTED_PACK, "GigaDevice GD32F1x0 DFP 3.2.1 not found in Hoverboard.uvprojx"),
        ("<FileName>bldcFOC.c</FileName>", "FOC adapter source not in GD32 project"),
        ("<FileName>driveCapability.c</FileName>", "capability source not in GD32 project"),
        ("<FileName>g5Monitor.c</FileName>", "g5mon source not in GD32 project"),
        ("<FileName>BLDC_controller.c</FileName>", "generated FOC controller source not in GD32 project"),
    ]:
        require_text(ptxt, marker, label)

    ftxt = foc_config.read_text(encoding="utf-8")
    if not SAFE_DEFINE_RE.search(ftxt):
        raise RuntimeError("Validation failed: FOC_SAFE_BRINGUP is not forced to 1")
    require_text(ftxt, "#define FOC_ADC_COUNTS_PER_AMP           PHASE_CURRENT_ADC_COUNTS_PER_AMP",
                 "phase-current scale is not sourced from the layout")
    require_text(ftxt, "#define CAP_MOTOR_NTC_PIN                MOTOR_NTC",
                 "motor NTC pin is not sourced from the layout")

    ctxt = config.read_text(encoding="utf-8")
    require_text(ctxt, "#if defined(GD32F130) && (LAYOUT == 20)",
                 "FOC selection is not constrained to GD32F130 layout 20")
    require_text(ctxt, "#define BLDC_FOC", "BLDC_FOC not selected for the bring-up configuration")
    require_text(ctxt, "#define G5_MONITOR", "G5_MONITOR feature gate not selected")
    require_text(ctxt, "#define BLDC_SINE", "upstream SINE fallback not preserved for other targets/layouts")

    ltxt = layout.read_text(encoding="utf-8")
    require_text(ltxt, "#define MOTOR_NTC\tPA6", "tentative PA6 hardware fact not kept in layout 2.1.20")
    require_text(ltxt, "PHASE_CURRENT_ADC_COUNTS_PER_AMP", "phase ADC scale not kept in layout 2.1.20")
    require_text(ltxt, "ADC_BATTERY_UV_PER_COUNT", "battery monitor scale not kept in layout 2.1.20")

    btxt = bldc_h.read_text(encoding="utf-8")
    require_text(btxt, "#elif defined(BLDC_FOC)", "FOC backend is not using the bldcXY selector")
    require_text(btxt, "#ifndef BLDC_SERVICE", "low-rate backend service extension hook missing")

    mtxt = main_c.read_text(encoding="utf-8")
    if mtxt.count("BLDC_SERVICE();") != 2:
        raise RuntimeError("Validation failed: expected BLDC_SERVICE() in both normal main-loop variants")

    stxt = setup_c.read_text(encoding="utf-8")
    require_text(stxt, "PIN_TO_CHANNEL(MOTOR_NTC)", "layout MOTOR_NTC is not in the FOC ADC scan")
    if "CAP_MOTOR_NTC_PIN" in stxt or "CAP_USE_MOTOR_NTC" in stxt:
        raise RuntimeError("Validation failed: setup.c depends on feature-policy macros instead of layout hardware facts")

    fctxt = foc_c.read_text(encoding="utf-8")
    require_text(fctxt, "DriveCapability_SampleFast", "bounded ISR capability sampler missing")
    require_text(fctxt, "void BldcFocService(void)", "main-loop FOC service missing")
    require_text(fctxt, "DriveCapability_Service();", "slow capability update not in main-loop service")
    if "foc_monitor_tick" in fctxt or "G5Monitor_Update();" in fctxt:
        raise RuntimeError("Validation failed: g5mon update still occurs in the PWM/ADC-DMA FOC path")

    captxt = cap_c.read_text(encoding="utf-8")
    require_text(captxt, "#ifdef BLDC_FOC", "capability source is not feature-gated")
    require_text(captxt, "void DriveCapability_SampleFast", "fast capability sampler missing")
    require_text(captxt, "void DriveCapability_Service", "slow capability service missing")

    montxt = mon_c.read_text(encoding="utf-8")
    require_text(montxt, "#ifdef G5_MONITOR", "g5 monitor source is not feature-gated")
    require_text(montxt, "void G5Monitor_Service", "main-loop monitor service missing")

    for p in (ctrl_c, data_c):
        txt = p.read_text(encoding="utf-8", errors="replace")
        require_text(txt, EFERU_GUARD, f"{p.name} is not isolated from non-FOC PlatformIO builds")
        require_text(txt, "#ifdef BLDC_FOC", f"{p.name} lacks BLDC_FOC compile guard")


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Apply AI-guidelines-audited Gyroor G5 Phase 3 and Keil Studio support without building/flashing"
    )
    ap.add_argument("repo_root", help="Path to Hoverboard-Firmware-Hack-Gen2.x-GD32 checkout")
    ap.add_argument("--allow-upstream-drift", action="store_true")
    ap.add_argument("--skip-vendor", action="store_true", help="Skip downloading pinned EFeru FOC source")
    ns = ap.parse_args()

    bundle = Path(__file__).resolve().parent
    root = Path(ns.repo_root).expanduser().resolve()

    if not (root / "HoverBoardGigaDevice" / "Hoverboard.uvprojx").is_file():
        print(f"ERROR: Not a supported Gen2.x-GD32 checkout: {root}", file=sys.stderr)
        return 2

    # The user chose to backtrack from the CubeIDE branch. Refuse known CubeIDE
    # residue rather than silently mixing two IDE migrations in one checkout.
    cube_residue = [p for p in (root / ".project", root / "Makefile", root / "CubeIDE") if p.exists()]
    if cube_residue:
        print("ERROR: This checkout contains CubeIDE migration files:", file=sys.stderr)
        for item in cube_residue:
            print(f"  {item}", file=sys.stderr)
        print("Use a fresh/clean RoboDurden GD32 checkout for the Keil Studio migration.", file=sys.stderr)
        return 2

    cmd = [sys.executable, str(bundle / "apply_phase3.py"), str(root)]
    if ns.allow_upstream_drift:
        cmd.append("--allow-upstream-drift")
    if ns.skip_vendor:
        cmd.append("--skip-vendor")

    print("=== Applying AI-guidelines-audited Phase-3 firmware ===")
    rc = subprocess.call(cmd)
    if rc:
        return rc

    print("\n=== Installing Keil Studio support ===")
    support = bundle / "keilstudio"
    copy_file(support / ".vscode" / "extensions.json", root / ".vscode" / "extensions.json")
    copy_file(support / "vcpkg-configuration.json", root / "vcpkg-configuration.json")
    copy_file(support / "README_KEIL_STUDIO.md", root / "KeilStudio" / "README_KEIL_STUDIO.md")
    copy_file(support / "G5MON_WATCHES.txt", root / "KeilStudio" / "G5MON_WATCHES.txt")
    copy_file(bundle / "AI_GUIDELINES_AUDIT.md", root / "KeilStudio" / "AI_GUIDELINES_AUDIT.md")

    try:
        validate_repo(root)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 3

    print("\n=== Validation passed ===")
    print("Guidelines   : ai_guidelines.md + v0 + v1 exact audited blobs verified")
    print("GD32 target  : GD32F130C8 / layout 2.1.20")
    print("Device pack  : GigaDevice::GD32F1x0_DFP@3.2.1 (declared by upstream µVision project)")
    print("Compiler     : keep AC6 for the FIRST Keil Studio conversion/build")
    print("Architecture : BLDC_FOC backend + main-loop BLDC_SERVICE; slow monitor/thermal work outside ISR")
    print("Build matrix : non-FOC sources remain gated; SINE fallback preserved elsewhere")
    print("Monitor      : G5_MONITOR/g5mon installed, main-loop serviced")
    print("Safety       : FOC_SAFE_BRINGUP=1 verified; this script did NOT build or flash")
    print("\nNext: open the repository folder in VS Code, install the recommended Arm Keil Studio Pack,")
    print("then right-click HoverBoardGigaDevice/Hoverboard.uvprojx and convert the GD32F130 target")
    print("to a CMSIS Solution. See KeilStudio/README_KEIL_STUDIO.md.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
