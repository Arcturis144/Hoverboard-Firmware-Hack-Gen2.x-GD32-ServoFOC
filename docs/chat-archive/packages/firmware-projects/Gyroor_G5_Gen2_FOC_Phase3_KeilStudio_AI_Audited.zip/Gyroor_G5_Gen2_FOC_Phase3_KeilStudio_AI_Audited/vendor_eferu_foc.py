#!/usr/bin/env python3
"""Vendor the pinned EFeru generated FOC core into a Gen2.x-GD32 checkout.

Only the generated motor-controller core is imported. The STM32 HAL/application
layer from EFeru is deliberately not imported; Gen2.x remains the hardware/base
firmware layer for the GD32F130 split board.

The generated .c files are wrapped in BLDC_FOC so PlatformIO's Src/*.c discovery
does not link the EFeru core into unrelated GD32F103/GD32E230/SINE builds.
"""

from __future__ import annotations
import argparse
import hashlib
from pathlib import Path
from urllib.request import Request, urlopen

COMMIT = "4f141cbc97b297e194fd58e56444bd0322f902ac"
BASE = f"https://raw.githubusercontent.com/EFeru/hoverboard-firmware-hack-FOC/{COMMIT}"
GUARD_MARKER = "GYROOR_G5_EFERU_BLDC_FOC_GUARD"

FILES = {
    "Inc/BLDC_controller.h": "9d663c24c08a646f05aad8e3be736eb516311576",
    "Inc/rtwtypes.h": "3f68038730a6176838691de74668ce0adf692a7d",
    "Src/BLDC_controller.c": "ae63bd4053ebb5225f6fd2edd307ce48c76d6155",
    "Src/BLDC_controller_data.c": "626c5371980b8939e0086196fa82968b51d54afc",
}


def git_blob_sha1(data: bytes) -> str:
    header = f"blob {len(data)}\0".encode("ascii")
    return hashlib.sha1(header + data).hexdigest()


def fetch(url: str) -> bytes:
    req = Request(url, headers={"User-Agent": "Gyroor-G5-FOC-integration/phase3-ai-audited"})
    with urlopen(req, timeout=30) as r:
        return r.read()


def wrap_foc_source(rel: str, raw: bytes) -> bytes:
    if not rel.startswith("Src/") or not rel.endswith(".c"):
        return raw
    prefix = (
        f"/* {GUARD_MARKER}: keep generated EFeru code out of non-FOC builds. */\n"
        '#include "../Inc/defines.h"\n\n'
        "#ifdef BLDC_FOC\n\n"
    ).encode("utf-8")
    suffix = b"\n\n#endif /* BLDC_FOC */\n"
    return prefix + raw + suffix


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("repo_root", help="Path to Hoverboard-Firmware-Hack-Gen2.x-GD32 checkout")
    ap.add_argument("--force", action="store_true", help="overwrite already-vendored files")
    ns = ap.parse_args()

    root = Path(ns.repo_root).resolve()
    project = root / "HoverBoardGigaDevice"
    if not (project / "Inc" / "defines.h").is_file():
        raise SystemExit(f"Not a Gen2.x-GD32 checkout: {root}")

    for rel, expected_sha in FILES.items():
        out = project / rel
        is_generated_c = rel.startswith("Src/") and rel.endswith(".c")

        raw: bytes | None = None
        if out.exists() and not ns.force:
            existing = out.read_bytes()
            if is_generated_c and GUARD_MARKER.encode() in existing:
                print(f"already guarded: {out.relative_to(root)}")
                continue
            if git_blob_sha1(existing) == expected_sha:
                if is_generated_c:
                    # Upgrade an earlier raw Phase-3 vendor copy in place.
                    raw = existing
                else:
                    print(f"already present: {out.relative_to(root)}")
                    continue
            else:
                raise SystemExit(f"Refusing to overwrite existing non-matching file: {out}")

        if raw is None:
            url = f"{BASE}/{rel}"
            print(f"fetching {url}")
            raw = fetch(url)
            actual = git_blob_sha1(raw)
            if actual != expected_sha:
                raise SystemExit(
                    f"Pinned EFeru file failed Git blob verification: {rel}\n"
                    f" expected {expected_sha}\n actual   {actual}"
                )
        else:
            actual = git_blob_sha1(raw)

        data = wrap_foc_source(rel, raw)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        if is_generated_c:
            print(f"wrote guarded {out.relative_to(root)} ({len(data)} bytes; source blob {actual})")
        else:
            print(f"wrote {out.relative_to(root)} ({len(data)} bytes, blob {actual})")

    print(f"EFeru FOC core pinned to commit {COMMIT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
