#ifndef BLDC_FOC_H
#define BLDC_FOC_H

#include <stdint.h>
#include "driveCapability.h"
#ifdef G5_MONITOR
#include "g5Monitor.h"
#endif

/* Optional low-rate backend service invoked from main-loop context. */
void BldcFocService(void);
#define BLDC_SERVICE() BldcFocService()

/* Debugger-visible bring-up values. */
extern volatile uint16_t foc_adc_phase_a_raw;
extern volatile uint16_t foc_adc_phase_b_raw;
extern volatile uint16_t foc_adc_motor_ntc_raw;
extern volatile int16_t  foc_adc_phase_a_offset;
extern volatile int16_t  foc_adc_phase_b_offset;
extern volatile int16_t  foc_current_a_model;
extern volatile int16_t  foc_current_b_model;
extern volatile int16_t  foc_target_model;
extern volatile int16_t  foc_out_phase_a;
extern volatile int16_t  foc_out_phase_b;
extern volatile int16_t  foc_out_phase_c;
extern volatile int16_t  foc_speed_rpm_x16;
extern volatile int16_t  foc_iq_raw;
extern volatile int16_t  foc_id_raw;
extern volatile uint8_t  foc_error;
extern volatile uint8_t  foc_offsets_ready;
extern volatile uint16_t foc_dynamic_i_max_q4;

#endif /* BLDC_FOC_H */
