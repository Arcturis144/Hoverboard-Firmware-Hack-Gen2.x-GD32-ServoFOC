# Gyroor G5 Phase 3 — Keil Studio / VS Code

This support layer moves the **build/debug workflow** for the Gyroor G5 GD32F130C8 Phase-3 firmware into **Arm Keil Studio for Visual Studio Code**, using the repository's real GigaDevice µVision target as the source of truth.

This revision was rebuilt after auditing the repository's `ai_guidelines.md`, `ai_guidelines_v0.md`, and `ai_guidelines_v1.md`. Read `KeilStudio/AI_GUIDELINES_AUDIT.md` after installation.

## Use a clean checkout

Use a fresh RoboDurden `Hoverboard-Firmware-Hack-Gen2.x-GD32` checkout. The wrapper intentionally rejects the earlier CubeIDE `.project`, root `Makefile`, or `CubeIDE/` tree.

## What gets installed

Firmware integration:

- layout 2.1.20 for GD32F130
- `BLDC_FOC` backend following the existing `bldcXY` architecture
- pinned EFeru generated FOC core
- phase-current + tentative PA6 motor-NTC ADC integration
- split fast/slow capability manager
- `G5_MONITOR` / `g5mon` debugger snapshot
- low-rate `BLDC_SERVICE()` main-loop extension hook

Keil Studio support:

- `.vscode/extensions.json`
- `vcpkg-configuration.json`
- `KeilStudio/README_KEIL_STUDIO.md`
- `KeilStudio/G5MON_WATCHES.txt`
- `KeilStudio/AI_GUIDELINES_AUDIT.md`

No CubeIDE/OpenOCD migration files are installed.

## Safety state

The migration does not enable motor output:

```c
#define FOC_SAFE_BRINGUP 1
```

The FOC adapter therefore forces zero phase output. PA6 remains a tentative motor-NTC identification and is not yet fail-required.

## Why the first converted build stays on AC6

The existing upstream `GD32F130` µVision target already specifies:

- device `GD32F130C8`
- pack `GigaDevice::GD32F1x0_DFP@3.2.1`
- Arm Compiler 6
- 64 KiB flash at `0x08000000`
- 8 KiB RAM at `0x20000000`

Keeping AC6 for the first Keil Studio build avoids changing the compiler/startup/linker model at the same time as the FOC migration. A GCC switch can be evaluated later as a separate controlled change.

## Convert the existing µVision target

1. Open the **root of the patched repository** in VS Code.
2. Install the recommended **Arm Keil Studio Pack**.
3. Let Environment Manager install/activate the declared tools.
4. Locate `HoverBoardGigaDevice/Hoverboard.uvprojx`.
5. Right-click it and choose **Convert µVision project to csolution** (wording may vary by extension version).
6. Convert/use the **GD32F130** target.
7. Verify the resulting context resolves `GD32F130C8`, the GigaDevice F1x0 device pack, and AC6.
8. **Build only. Do not flash yet.**

## First build acceptance checks

Before programming the controller, verify:

- no compile/link errors;
- target remains GD32F130C8/Cortex-M3;
- flash usage < 64 KiB;
- RAM usage < 8 KiB;
- `g5mon` appears in the debug image;
- `FOC_SAFE_BRINGUP` is still 1;
- no unintended STM32 HAL/startup files appeared.

Send the full first build output for review.

## Why g5mon no longer runs in the motor ISR

The repository guidance explicitly requires `CalculateBLDC()` / ADC-DMA work to stay fast and deterministic. The audited package therefore uses:

```text
ADC-DMA/PWM path:
    DriveCapability_SampleFast()

5 ms normal main loop:
    BLDC_SERVICE()
        -> DriveCapability_Service()
        -> G5Monitor_Service()
```

The main-loop service performs RMS/thermal/NTC and debugger snapshot work. This removes those slow calculations from the PWM-rate ISR. The remaining fast sampler still needs target timing measurement before motor bridge enable.

## ST-Link debugging

After the build is accepted:

1. Connect ST-Link SWDIO, SWCLK and GND.
2. Power the controller normally; do not power it from ST-Link 3.3 V.
3. Select the ST-Link debug adapter/SWD path from Keil Studio's Run/Debug controls.
4. Keep `FOC_SAFE_BRINGUP=1` for the first flash and attach.

The current bench connection does not rely on exposed NRST. Reset behavior must be validated in the debug configuration rather than assuming a physical NRST connection.

## g5mon live monitoring

Add the global symbol:

```text
g5mon
```

Start with:

```text
g5mon.magic
g5mon.update_counter
g5mon.foc.safe_bringup
g5mon.foc.bridge_enabled
```

Expected before bridge enable:

```text
g5mon.magic              0x47354D31
g5mon.update_counter     increasing
g5mon.foc.safe_bringup   1
g5mon.foc.bridge_enabled 0
```

Then add the ADC/current/Hall/capability fields from `KeilStudio/G5MON_WATCHES.txt` to Keil Studio's live/watch facilities.

Do not disable safe bring-up merely to make monitored motor-output values change.
