# Keil Studio migration for Gyroor G5 Phase 3

This package uses the existing upstream `GD32F130` µVision target as the authoritative GD32 device/project definition and converts it to a CMSIS Solution in Arm Keil Studio for VS Code.

The firmware integration was re-audited against all three root `ai_guidelines*` files. See `AI_GUIDELINES_AUDIT.md`.

## First build policy

Keep the existing AC6 compiler for the first conversion/build. Do not simultaneously change compiler, startup, linker, FOC backend, and IDE. GCC can be evaluated later as a separate controlled migration.

## Safety

`FOC_SAFE_BRINGUP=1` is mandatory for the first build/debug sessions. In this audited revision it vetoes the common BLDC timer bridge-enable path, not merely the FOC command.

PA6 is **not** sampled or treated as an NTC. Its physical role remains unconfirmed.

## VS Code / Keil Studio sequence

1. Open the patched repository folder in VS Code.
2. Install the recommended Arm Keil Studio Pack.
3. Convert `HoverBoardGigaDevice/Hoverboard.uvprojx` to a CMSIS Solution.
4. Select only the `GD32F130` target (`GD32F130C8`, GigaDevice DFP).
5. Build. Do not flash on the first pass.
6. Send the complete build output for review.

After a clean build, the next stage is debug attach / live monitoring with `g5mon`.
