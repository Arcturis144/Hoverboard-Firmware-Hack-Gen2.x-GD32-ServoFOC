# Keil Studio migration for Gyroor G5 Phase 3

This revision installs a native CMSIS Solution directly into the patched repository. It does not require the VS Code µVision converter.

After applying the package, open:

`HoverBoardGigaDevice/Gyroor_G5_Phase3.csolution.yml`

Keil Studio should resolve the target as `GigaDevice::GD32F130C8` using `GigaDevice::GD32F1x0_DFP@3.2.1` and Arm CMSIS 6.0.0.

The first build deliberately uses AC6 so the IDE migration is not mixed with a compiler/startup migration. The project generates ELF, HEX, BIN, and MAP outputs.

The solution contains an ST-Link@pyOCD SWD debug target at a conservative 400 kHz. Do not flash on the first pass; build first and review the complete output.

## Fallback converter source

The installer also creates:

`HoverBoardGigaDevice/Gyroor_G5_Phase3.uvprojx`

This is a copy of the fully patched upstream µVision project and can be used with Keil Studio's µVision-to-CMSIS converter if the direct CMSIS solution needs comparison or recovery.

## Safety

`FOC_SAFE_BRINGUP=1` remains mandatory. The audited Phase-3 backend vetoes the common BLDC bridge-enable path. PA6 is not sampled or treated as an NTC because its hardware role is not confirmed.

## g5mon

Use the debugger's live/watch facilities with the global `g5mon` structure. Suggested fields are in `KeilStudio/G5MON_WATCHES.txt`.
