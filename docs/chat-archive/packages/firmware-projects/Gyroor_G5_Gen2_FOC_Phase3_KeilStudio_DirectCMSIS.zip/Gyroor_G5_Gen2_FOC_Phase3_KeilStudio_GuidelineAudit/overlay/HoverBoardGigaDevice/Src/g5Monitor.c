#include "../Inc/defines.h"

#ifdef DEBUG_G5MON
#if defined(BLDC_FOC)

#include "../Inc/g5Monitor.h"
#include "../Inc/foc_config.h"
#include "../Inc/driveCapability.h"
#include <stdint.h>

extern adc_buf_t adc_buffer;
extern uint8_t hall_a;
extern uint8_t hall_b;
extern uint8_t hall_c;
extern FlagStatus bldc_enable;

extern volatile uint16_t foc_adc_phase_a_raw;
extern volatile uint16_t foc_adc_phase_b_raw;
extern volatile int16_t  foc_adc_phase_a_offset;
extern volatile int16_t  foc_adc_phase_b_offset;
extern volatile int16_t  foc_current_a_model;
extern volatile int16_t  foc_current_b_model;
extern volatile int16_t  foc_target_model;
extern volatile int16_t  foc_out_phase_a;
extern volatile int16_t  foc_out_phase_b;
extern volatile int16_t  foc_out_phase_c;
extern volatile int16_t  foc_speed_rpm_x16;
extern volatile int16_t  foc_iq_raw;
extern volatile int16_t  foc_id_raw;
extern volatile uint8_t  foc_error;
extern volatile uint8_t  foc_offsets_ready;
extern volatile uint16_t foc_dynamic_i_max_q4;

volatile G5_MonitorData g5mon = {
    .magic = 0x47354D31UL
};

static int16_t g5mon_clamp_i16(int32_t v)
{
    if (v > 32767) return 32767;
    if (v < -32768) return -32768;
    return (int16_t)v;
}

static int16_t g5mon_model_to_centiamp(int32_t model)
{
    if (FOC_MODEL_COUNTS_PER_AMP <= 0) return 0;
    return g5mon_clamp_i16((model * 100L) / FOC_MODEL_COUNTS_PER_AMP);
}

void G5Monitor_Update(void)
{
    int32_t phase_c_model;
    uint32_t battery_uv;

    g5mon.magic = 0x47354D31UL;
    g5mon.update_counter++;

    g5mon.adc.battery_raw = adc_buffer.v_batt;
    g5mon.adc.phase_a_raw = foc_adc_phase_a_raw;
    g5mon.adc.phase_b_raw = foc_adc_phase_b_raw;
    g5mon.adc.motor_ntc_raw = 0U; /* PA6/NTC not enabled until physically confirmed. */
    battery_uv = (uint32_t)adc_buffer.v_batt * (uint32_t)G5_MONITOR_BATTERY_UV_PER_COUNT;
    g5mon.adc.battery_millivolt = (battery_uv + 500UL) / 1000UL;

    phase_c_model = -((int32_t)foc_current_a_model + (int32_t)foc_current_b_model);
    g5mon.current.phase_a_model = foc_current_a_model;
    g5mon.current.phase_b_model = foc_current_b_model;
    g5mon.current.phase_c_model_reconstructed = g5mon_clamp_i16(phase_c_model);
    g5mon.current.phase_a_centiamp = g5mon_model_to_centiamp(foc_current_a_model);
    g5mon.current.phase_b_centiamp = g5mon_model_to_centiamp(foc_current_b_model);
    g5mon.current.phase_c_centiamp_reconstructed = g5mon_model_to_centiamp(phase_c_model);
    g5mon.current.rms_centiamp = cap_current_rms_centiamp;
    g5mon.current.offset_a = foc_adc_phase_a_offset;
    g5mon.current.offset_b = foc_adc_phase_b_offset;
    g5mon.current.offsets_ready = foc_offsets_ready;
    g5mon.current.sensor_valid = cap_current_sensor_valid;

    g5mon.motor_ntc.raw = cap_motor_ntc_raw;
    g5mon.motor_ntc.filtered_raw = cap_motor_ntc_filtered_raw;
    g5mon.motor_ntc.resistance_ohm = cap_motor_ntc_ohm;
    g5mon.motor_ntc.limit_centiamp = cap_motor_ntc_limit_centiamp;
    g5mon.motor_ntc.valid = cap_motor_ntc_valid;

    g5mon.capability.thermal_load_permille = cap_thermal_load_permille;
    g5mon.capability.absolute_limit_centiamp = cap_absolute_limit_centiamp;
    g5mon.capability.thermal_limit_centiamp = cap_thermal_limit_centiamp;
    g5mon.capability.battery_limit_centiamp = cap_battery_limit_centiamp;
    g5mon.capability.temperature_limit_centiamp = cap_temperature_limit_centiamp;
    g5mon.capability.motor_ntc_limit_centiamp = cap_motor_ntc_limit_centiamp;
    g5mon.capability.global_limit_centiamp = cap_global_limit_centiamp;
    g5mon.capability.profile_limit_centiamp = cap_profile_limit_centiamp;
    g5mon.capability.effective_limit_centiamp = cap_effective_limit_centiamp;
    g5mon.capability.profile = cap_profile;
    g5mon.capability.fault_flags = cap_fault_flags;

    g5mon.motor.hall_a = hall_a ? 1U : 0U;
    g5mon.motor.hall_b = hall_b ? 1U : 0U;
    g5mon.motor.hall_c = hall_c ? 1U : 0U;
    g5mon.motor.hall_state = (uint8_t)(g5mon.motor.hall_a |
                                      (uint8_t)(g5mon.motor.hall_b << 1U) |
                                      (uint8_t)(g5mon.motor.hall_c << 2U));
    g5mon.motor.speed_rpm_x16 = foc_speed_rpm_x16;
    g5mon.motor.speed_rpm = (int16_t)(foc_speed_rpm_x16 / 16);

    g5mon.foc.target = foc_target_model;
    g5mon.foc.iq_raw = foc_iq_raw;
    g5mon.foc.id_raw = foc_id_raw;
    g5mon.foc.iq_centiamp = g5mon_model_to_centiamp(foc_iq_raw);
    g5mon.foc.id_centiamp = g5mon_model_to_centiamp(foc_id_raw);
    g5mon.foc.pwm_a = foc_out_phase_a;
    g5mon.foc.pwm_b = foc_out_phase_b;
    g5mon.foc.pwm_c = foc_out_phase_c;
    g5mon.foc.dynamic_i_max_q4 = foc_dynamic_i_max_q4;
    g5mon.foc.error = foc_error;
#if FOC_SAFE_BRINGUP
    g5mon.foc.bridge_enabled = 0U;
    g5mon.foc.safe_bringup = 1U;
#else
    g5mon.foc.bridge_enabled = ((bldc_enable == SET) &&
                                (foc_dynamic_i_max_q4 > 0U) &&
                                (foc_error == 0U)) ? 1U : 0U;
    g5mon.foc.safe_bringup = 0U;
#endif
}

#endif /* BLDC_FOC */
#endif /* DEBUG_G5MON */
