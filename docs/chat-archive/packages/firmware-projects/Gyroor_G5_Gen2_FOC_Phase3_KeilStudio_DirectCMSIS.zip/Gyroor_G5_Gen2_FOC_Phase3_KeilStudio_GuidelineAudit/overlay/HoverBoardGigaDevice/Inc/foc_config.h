#ifndef FOC_CONFIG_H
#define FOC_CONFIG_H

/*
 * Gyroor G5 / OLSZ OL20180703-V4.1 FOC integration configuration.
 *
 * Phase 3 integrates the EFeru FOC backend for GD32F130 layout 2.1.20.
 * Hardware assumptions that are not yet proven (notably PA6 as an NTC) are
 * deliberately excluded from the active ADC scan.
 */

#define FOC_SAFE_BRINGUP                 1

/* EFeru BLDC_controller numeric selections. */
#define FOC_CONTROL_TYPE_FOC             2
#define FOC_CONTROL_MODE_VOLTAGE         1
#define FOC_DIAGNOSTICS_ENABLE           1

/*
 * Provisional HARD ceiling for the first powered tests after SAFE_BRINGUP is
 * removed.  Do not raise this until PA0/PB0 current scaling and polarity are
 * measured and the inverter/motor thermal limits are characterized.
 */
#define FOC_I_MOT_MAX_A                  5
#define FOC_N_MOT_MAX_RPM                500

/* Field weakening is deliberately disabled during bring-up. */
#define FOC_FIELD_WEAK_ENABLE            0
#define FOC_FIELD_WEAK_MAX_A             0
#define FOC_PHASE_ADV_MAX_DEG            0
#define FOC_FIELD_WEAK_HI                1000
#define FOC_FIELD_WEAK_LO                750

/* EFeru's generated controller uses 50 internal current counts per ampere. */
#define FOC_MODEL_COUNTS_PER_AMP         50

/*
 * PROVISIONAL hardware scale only.
 * Layout 2.1.20 documents 4 mOhm low-side shunts and approximately 20x gain.
 * That implies about 99.3 ADC counts/A at a 3.3 V, 12-bit ADC.
 * Measure/calibrate this before enabling the bridge.
 */
#define FOC_ADC_COUNTS_PER_AMP           99

/* Current polarity: current = (zero_offset - ADC_sample) * sign. */
#define FOC_PHASE_A_SIGN                 1
#define FOC_PHASE_B_SIGN                 1

/* Hall-model mapping. Keep identity until verified with the motor unloaded. */
#define FOC_HALL_A_INVERT                0
#define FOC_HALL_B_INVERT                0
#define FOC_HALL_C_INVERT                0

/* Preserve a low-side-shunt sampling window. */
#define FOC_PWM_MARGIN_PERMILLE          55

/* Offset average length. At 16 kHz this is nominally 125 ms. */
#define FOC_CURRENT_OFFSET_SAMPLES       2000

/* ------------------------------------------------------------------------- */
/* Global adaptive drive-capability manager                                  */
/* ------------------------------------------------------------------------- */

#define CAP_ABSOLUTE_CURRENT_CENTIAMP    (FOC_I_MOT_MAX_A * 100)
#define CAP_CONTINUOUS_CURRENT_CENTIAMP  300

/* Profiles are preferences, not safety limits. */
#define CAP_PROFILE_NORMAL_PERMILLE      650
#define CAP_PROFILE_SNOW_PERMILLE        850
#define CAP_PROFILE_BOOST_PERMILLE       1000
#define CAP_DEFAULT_PROFILE              DRIVE_PROFILE_NORMAL

/* Capability model update rate and provisional current-heating model. */
#define CAPABILITY_UPDATE_HZ             100
#define CAP_USE_THERMAL_MODEL            0
#define CAP_THERMAL_TAU_SECONDS          120
#define CAP_THERMAL_SOFT_PERMILLE        700
#define CAP_THERMAL_HARD_PERMILLE        1000
#define CAP_THERMAL_CUTOFF_PERMILLE      1250

/* Raw phase-current ADC readings closer than this to either rail are invalid. */
#define CAP_CURRENT_ADC_RAIL_GUARD       16

/*
 * Battery derating is wired into the common manager but OFF until the final
 * mower battery configuration is confirmed.
 */
#define CAP_USE_BATTERY_DERATE           0

/* Optional temperature-input hook. It remains OFF for first bring-up. */
#define CAP_USE_TEMPERATURE_SENSOR       0
#define CAP_TEMP_DERATE_START_DECIC      700
#define CAP_TEMP_CUTOFF_DECIC            900

/* ------------------------------------------------------------------------- */
/* Future motor-temperature input (disabled until the physical pin is proven) */
/* ------------------------------------------------------------------------- */

#define CAP_USE_MOTOR_NTC                0
#define CAP_MOTOR_NTC_PIN                0
#define CAP_MOTOR_NTC_FIXED_OHM          10000UL
#define CAP_MOTOR_NTC_ADC_FULL_SCALE     4096UL
#define CAP_MOTOR_NTC_ADC_RAIL_GUARD     8U
#define CAP_MOTOR_NTC_DERATE_START_OHM   8000UL
#define CAP_MOTOR_NTC_CUTOFF_OHM         6000UL

/* If a motor-temperature input is later confirmed and enabled, require-valid
 * can be set to 1 to make sensor loss fail-safe. */
#define CAP_MOTOR_NTC_REQUIRE_VALID      0

#if CAP_CONTINUOUS_CURRENT_CENTIAMP > CAP_ABSOLUTE_CURRENT_CENTIAMP
#error "Continuous current cannot exceed absolute current"
#endif

#if CAP_MOTOR_NTC_CUTOFF_OHM >= CAP_MOTOR_NTC_DERATE_START_OHM
#error "For an NTC, cutoff resistance must be lower than derate-start resistance"
#endif

/* EFeru's i_max parameter is int16 Q4 at 50 counts/A; keep under its range. */
#if CAP_ABSOLUTE_CURRENT_CENTIAMP > 4000
#error "Phase-3 EFeru adapter supports at most 40.00 A without changing model scaling"
#endif

#endif /* FOC_CONFIG_H */
