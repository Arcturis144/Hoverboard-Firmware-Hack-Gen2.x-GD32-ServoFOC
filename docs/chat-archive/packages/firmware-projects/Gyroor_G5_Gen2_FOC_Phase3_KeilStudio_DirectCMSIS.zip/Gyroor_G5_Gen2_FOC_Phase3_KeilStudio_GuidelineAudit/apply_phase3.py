#!/usr/bin/env python3
"""Apply guideline-audited Gyroor G5 Gen2.1.20 + EFeru FOC integration.

This revision follows the repository AI guidelines: BLDC_FOC is a normal bldcXY
backend, unrelated IMU/layout behavior is untouched, unconfirmed PA6/NTC wiring
is not enabled, other MCU targets retain BLDC_SINE, debug monitoring is gated,
and safe bring-up inhibits the common timer bridge-enable path.
"""

from __future__ import annotations
import argparse
import hashlib
import re
import shutil
import subprocess
import sys
from pathlib import Path

EXPECTED = {
    "HoverBoardGigaDevice/Inc/config.h": "75aee4d4e25ed1e3366621120423b9005321d426",
    "HoverBoardGigaDevice/Inc/bldc.h": "8b450cbbca99cf964d7be1d0071a2fbfe2f8b8cb",
    "HoverBoardGigaDevice/Inc/defines.h": "683a72c7f4ab2f0e87b41670a75c5aa452724931",
    "HoverBoardGigaDevice/Inc/defines/defines_2-1-20.h": "b977d94ea58a34ce59f9ce8ecfb5761b0e4b7241",
    "HoverBoardGigaDevice/Src/bldc.c": "996352961679df04359efc58a339058631cbab05",
    "HoverBoardGigaDevice/Src/setup.c": "5bbf6761749decc814ddd0ca49855f77b45e1317",
    "HoverBoardGigaDevice/Hoverboard.uvprojx": "fabcacb87f3de51c4d1ac25c72949d65bd3cce69",
}

MARKER = "GYROOR_G5_FOC_PHASE3_GUIDELINE_AUDIT"
OLD_MARKERS = ("GYROOR_G5_FOC_PHASE1", "GYROOR_G5_FOC_PHASE2", "GYROOR_G5_FOC_PHASE3")


def git_blob_sha1(data: bytes) -> str:
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()


def has_old_marker(text: str) -> bool:
    return any(m in text for m in OLD_MARKERS)


def checked_read(root: Path, rel: str, allow_drift: bool) -> str:
    path = root / rel
    data = path.read_bytes()
    text = data.decode("utf-8")
    if MARKER in text:
        return text
    if has_old_marker(text):
        raise RuntimeError(
            f"Older Gyroor Phase patch detected in {rel}. "
            "Use a fresh upstream checkout for the guideline-audited revision."
        )
    actual = git_blob_sha1(data)
    expected = EXPECTED[rel]
    if actual != expected and not allow_drift:
        raise RuntimeError(
            f"Upstream file changed; refusing automatic patch: {rel}\n"
            f" expected blob {expected}\n actual blob   {actual}\n"
            f"Review upstream changes, then rerun with --allow-upstream-drift if appropriate."
        )
    return text


def backup_and_write(root: Path, rel: str, text: str) -> None:
    path = root / rel
    backup = path.with_suffix(path.suffix + ".phase3.bak")
    if not backup.exists():
        shutil.copy2(path, backup)
    path.write_text(text, encoding="utf-8", newline="")
    print(f"patched {rel}")


def require_once(text: str, old: str, new: str, label: str) -> str:
    if old not in text:
        raise RuntimeError(f"Could not find expected text for {label}")
    return text.replace(old, new, 1)


def patch_config(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Inc/config.h"
    text = checked_read(root, rel, allow_drift)
    if MARKER in text:
        print(f"base integration already present: {rel}")
        return

    text, n = re.subn(
        r"(\t#ifdef GD32F130\t\t// TARGET = 1\r?\n)\t\t#define LAYOUT 1\r?\n\t\t#define LAYOUT_SUB 1[^\r\n]*",
        r"\1\t\t#define LAYOUT 20\n\t\t//#define LAYOUT_SUB 1\t// not used by layout 2.1.20",
        text,
        count=1,
    )
    if n != 1:
        raise RuntimeError("Could not select GD32F130 layout 20")

    old = """\t//#define BLDC_BC\t\t\t// old block commutation bldc control
\t#define BLDC_SINE\t\t\t// silent sine-pwm motor control, added 2025 by Robo Durden. 
\t//#define BLDC_SINE_BOOSTER\t\t// can boost speed by 15% starting from 87% throttle.
"""
    new = f"""\t//#define BLDC_BC\t\t\t// old block commutation bldc control
\t#if defined(GD32F130) && (LAYOUT == 20)
\t\t#define BLDC_FOC\t\t// {MARKER}: Gyroor G5 / layout 2.1.20 only
\t\t#define DEBUG_G5MON\t// debugger-only structured monitor; no serial logging
\t#else
\t\t#define BLDC_SINE\t\t// preserve the existing backend for every other target/layout
\t#endif
\t//#define BLDC_SINE_BOOSTER\t\t// only applies to BLDC_SINE
"""
    text = require_once(text, old, new, "target-scoped BLDC_FOC selection")
    backup_and_write(root, rel, text)



def patch_bldc_h(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Inc/bldc.h"
    text = checked_read(root, rel, allow_drift)
    if "bldcFOC.h" in text and "BLDC_BACKEND_OUTPUT_ALLOWED" in text:
        print(f"FOC backend selector already present: {rel}")
        return
    old = """#if defined(BLDC_BC)
\t#include "../Inc/bldcBC.h"
#elif defined(BLDC_SINE)
\t#include "../Inc/bldcSINE.h"
#endif
"""
    new = f"""#if defined(BLDC_BC)
\t#include "../Inc/bldcBC.h"
#elif defined(BLDC_SINE)
\t#include "../Inc/bldcSINE.h"
#elif defined(BLDC_FOC) /* {MARKER}: normal bldcXY backend */
\t#include "../Inc/bldcFOC.h"
#endif

/* Optional backend safety veto. Existing backends default to allowed. */
#ifndef BLDC_BACKEND_OUTPUT_ALLOWED
\t#define BLDC_BACKEND_OUTPUT_ALLOWED() (1U)
#endif
"""
    text = require_once(text, old, new, "bldc backend selector")
    backup_and_write(root, rel, text)


def phase3_adc_struct() -> str:
    return f"""// ADC buffer struct
#ifdef BLDC_FOC /* {MARKER}: FOC requires two phase-current samples */
\t#if defined(REMOTE_ADC)
\t\t#error "BLDC_FOC phase-current ADC scan cannot be combined with REMOTE_ADC yet"
\t#endif
\t#if !defined(VBATT) || !defined(PHASE_A) || !defined(PHASE_B)
\t\t#error "BLDC_FOC requires VBATT, PHASE_A and PHASE_B in the selected layout"
\t#endif
\ttypedef struct
\t{{
\t\tuint16_t v_batt;
\t\tuint16_t phase_a;
\t\tuint16_t phase_b;
\t}} adc_buf_t;
#else
\ttypedef struct
\t{{
\t  uint16_t v_batt;
\t\tuint16_t current_dc;
\t\t#ifdef REMOTE_ADC
\t\t\tuint16_t speed;
\t\t\tuint16_t steer;
\t\t#endif
\t}} adc_buf_t;
#endif
"""


def patch_defines_h(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Inc/defines.h"
    text = checked_read(root, rel, allow_drift)
    if MARKER in text and "phase_b" in text:
        print(f"FOC ADC buffer already present: {rel}")
        return
    clean = """// ADC buffer struct
typedef struct
{
  uint16_t v_batt;
\tuint16_t current_dc;
\t#ifdef REMOTE_ADC
\t\tuint16_t speed;
\t\tuint16_t steer;
\t#endif
\t
} adc_buf_t;
"""
    if clean not in text:
        raise RuntimeError("Could not identify clean ADC buffer in defines.h; use a fresh upstream checkout")
    text = text.replace(clean, phase3_adc_struct(), 1)
    backup_and_write(root, rel, text)


def patch_setup(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Src/setup.c"
    text = checked_read(root, rel, allow_drift)
    if MARKER in text and "PIN_TO_CHANNEL(PHASE_B)" in text:
        print(f"FOC ADC setup already present: {rel}")
        return

    clean_gpio = """\t\t#ifdef CURRENT_DC
\t\t\tpinMode(CURRENT_DC, GPIO_MODE_ANALOG);
\t\t#endif
\t\t#ifdef REMOTE_ADC
"""
    foc_gpio = f"""\t\t#ifdef CURRENT_DC
\t\t\tpinMode(CURRENT_DC, GPIO_MODE_ANALOG);
\t\t#endif
\t\t#ifdef BLDC_FOC /* {MARKER}: phase-current inputs required by backend */
\t\t\tpinMode(PHASE_A, GPIO_MODE_ANALOG);
\t\t\tpinMode(PHASE_B, GPIO_MODE_ANALOG);
\t\t#endif
\t\t#ifdef REMOTE_ADC
"""
    text = require_once(text, clean_gpio, foc_gpio, "FOC ADC GPIO setup")

    clean_adc = """\t\t#ifdef VBATT
\t\t\tTARGET_adc_regular_channel_config(0, PIN_TO_CHANNEL(VBATT), ADC_SAMPLETIME_13POINT5);
\t\t#endif
\t\t#ifdef CURRENT_DC
\t\t\tTARGET_adc_regular_channel_config(1, PIN_TO_CHANNEL(CURRENT_DC), ADC_SAMPLETIME_13POINT5);
\t\t#endif
\t\t#ifdef REMOTE_ADC
\t\t\tadc_regular_channel_config(2, PIN_TO_CHANNEL(PA2), ADC_SAMPLETIME_13POINT5);
\t\t\tadc_regular_channel_config(3, PIN_TO_CHANNEL(PA3), ADC_SAMPLETIME_13POINT5);
\t\t#endif
"""
    foc_adc = f"""\t\t#ifdef BLDC_FOC /* {MARKER}: order matches BLDC_FOC adc_buf_t */
\t\t\tTARGET_adc_regular_channel_config(0, PIN_TO_CHANNEL(VBATT), ADC_SAMPLETIME_13POINT5);
\t\t\tTARGET_adc_regular_channel_config(1, PIN_TO_CHANNEL(PHASE_A), ADC_SAMPLETIME_13POINT5);
\t\t\tTARGET_adc_regular_channel_config(2, PIN_TO_CHANNEL(PHASE_B), ADC_SAMPLETIME_13POINT5);
\t\t#else
\t\t\t#ifdef VBATT
\t\t\t\tTARGET_adc_regular_channel_config(0, PIN_TO_CHANNEL(VBATT), ADC_SAMPLETIME_13POINT5);
\t\t\t#endif
\t\t\t#ifdef CURRENT_DC
\t\t\t\tTARGET_adc_regular_channel_config(1, PIN_TO_CHANNEL(CURRENT_DC), ADC_SAMPLETIME_13POINT5);
\t\t\t#endif
\t\t\t#ifdef REMOTE_ADC
\t\t\t\tadc_regular_channel_config(2, PIN_TO_CHANNEL(PA2), ADC_SAMPLETIME_13POINT5);
\t\t\t\tadc_regular_channel_config(3, PIN_TO_CHANNEL(PA3), ADC_SAMPLETIME_13POINT5);
\t\t\t#endif
\t\t#endif
"""
    idx = text.rfind(clean_adc)
    if idx < 0:
        raise RuntimeError("Could not identify ADC scan setup in setup.c")
    text = text[:idx] + foc_adc + text[idx + len(clean_adc):]
    backup_and_write(root, rel, text)


def patch_bldc_c(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Src/bldc.c"
    text = checked_read(root, rel, allow_drift)
    if MARKER in text and "BLDC_BACKEND_OUTPUT_ALLOWED" in text:
        print(f"backend output gate already present: {rel}")
        return

    old = "if (currentDC > DC_CUR_LIMIT  || bldc_enable == RESET  || timedOut == SET)"
    new = f"if (currentDC > DC_CUR_LIMIT  || bldc_enable == RESET  || timedOut == SET || !BLDC_BACKEND_OUTPUT_ALLOWED()) /* {MARKER} */"
    text = require_once(text, old, new, "common backend safety veto")

    old2 = "\tbldc_get_pwm(bldc_outputFilterPwm, pos, &y, &b, &g);\n"
    new2 = old2 + "\t/* Re-check after the backend step so a newly-detected backend fault inhibits the bridge in this cycle. */\n\tif (!BLDC_BACKEND_OUTPUT_ALLOWED()) timer_automatic_output_disable(TIMER_BLDC);\n"
    text = require_once(text, old2, new2, "post-backend safety veto")
    backup_and_write(root, rel, text)

def patch_keil_project(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Hoverboard.uvprojx"
    text = checked_read(root, rel, allow_drift)
    changed = False

    source_anchor = """            <File>
              <FileName>bldcSINE.c</FileName>
              <FileType>1</FileType>
              <FilePath>.\\Src\\bldcSINE.c</FilePath>
            </File>
"""
    source_insert = source_anchor + """            <File>
              <FileName>bldcFOC.c</FileName>
              <FileType>1</FileType>
              <FilePath>.\\Src\\bldcFOC.c</FilePath>
            </File>
            <File>
              <FileName>driveCapability.c</FileName>
              <FileType>1</FileType>
              <FilePath>.\\Src\\driveCapability.c</FilePath>
            </File>
            <File>
              <FileName>g5Monitor.c</FileName>
              <FileType>1</FileType>
              <FilePath>.\\Src\\g5Monitor.c</FilePath>
            </File>
            <File>
              <FileName>BLDC_controller.c</FileName>
              <FileType>1</FileType>
              <FilePath>.\\Src\\BLDC_controller.c</FilePath>
            </File>
            <File>
              <FileName>BLDC_controller_data.c</FileName>
              <FileType>1</FileType>
              <FilePath>.\\Src\\BLDC_controller_data.c</FilePath>
            </File>
"""
    if "<FileName>bldcFOC.c</FileName>" not in text:
        text = require_once(text, source_anchor, source_insert, "Keil FOC source files")
        changed = True

    header_anchor = """            <File>
              <FileName>bldcSINE.h</FileName>
              <FileType>5</FileType>
              <FilePath>.\\Inc\\bldcSINE.h</FilePath>
            </File>
"""
    header_insert = header_anchor + """            <File>
              <FileName>bldcFOC.h</FileName>
              <FileType>5</FileType>
              <FilePath>.\\Inc\\bldcFOC.h</FilePath>
            </File>
            <File>
              <FileName>driveCapability.h</FileName>
              <FileType>5</FileType>
              <FilePath>.\\Inc\\driveCapability.h</FilePath>
            </File>
            <File>
              <FileName>foc_config.h</FileName>
              <FileType>5</FileType>
              <FilePath>.\\Inc\\foc_config.h</FilePath>
            </File>
            <File>
              <FileName>g5Monitor.h</FileName>
              <FileType>5</FileType>
              <FilePath>.\\Inc\\g5Monitor.h</FilePath>
            </File>
            <File>
              <FileName>BLDC_controller.h</FileName>
              <FileType>5</FileType>
              <FilePath>.\\Inc\\BLDC_controller.h</FilePath>
            </File>
            <File>
              <FileName>rtwtypes.h</FileName>
              <FileType>5</FileType>
              <FilePath>.\\Inc\\rtwtypes.h</FilePath>
            </File>
"""
    if "<FileName>foc_config.h</FileName>" not in text:
        text = require_once(text, header_anchor, header_insert, "Keil FOC header files")
        changed = True

    if changed:
        text = text.replace("</Project>", f"  <!-- {MARKER} -->\n</Project>", 1)
        backup_and_write(root, rel, text)
    else:
        print(f"Keil FOC files already present: {rel}")


def install_overlay(bundle: Path, root: Path) -> None:
    overlay = bundle / "overlay"
    for src in overlay.rglob("*"):
        if not src.is_file():
            continue
        rel = src.relative_to(overlay)
        dst = root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists() and dst.read_bytes() != src.read_bytes():
            backup = dst.with_suffix(dst.suffix + ".phase3.bak")
            if not backup.exists():
                shutil.copy2(dst, backup)
        shutil.copy2(src, dst)
        print(f"installed {rel}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("repo_root", help="Path to RoboDurden Hoverboard-Firmware-Hack-Gen2.x-GD32 checkout")
    ap.add_argument("--allow-upstream-drift", action="store_true")
    ap.add_argument("--skip-vendor", action="store_true", help="do not download pinned EFeru core")
    ns = ap.parse_args()

    root = Path(ns.repo_root).resolve()
    bundle = Path(__file__).resolve().parent
    if not (root / "HoverBoardGigaDevice" / "Inc" / "defines.h").is_file():
        raise SystemExit(f"Not a Gen2.x-GD32 checkout: {root}")

    try:
        patch_config(root, ns.allow_upstream_drift)
        patch_bldc_h(root, ns.allow_upstream_drift)
        patch_defines_h(root, ns.allow_upstream_drift)
        patch_setup(root, ns.allow_upstream_drift)
        patch_bldc_c(root, ns.allow_upstream_drift)
        patch_keil_project(root, ns.allow_upstream_drift)
        install_overlay(bundle, root)
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    if not ns.skip_vendor:
        vendor = bundle / "vendor_eferu_foc.py"
        rc = subprocess.call([sys.executable, str(vendor), str(root)])
        if rc:
            return rc

    print("\nGuideline-audited Phase-3 source integration applied.")
    print("IMPORTANT: FOC_SAFE_BRINGUP=1 vetoes the common bridge-enable path, not just the FOC command.")
    print("PA6/NTC is NOT enabled; its function remains unconfirmed.")
    print("Other target/layout builds retain BLDC_SINE; BLDC_FOC is selected only for GD32F130 layout 20.")
    print("DEBUG_G5MON is enabled only for the G5 FOC build and performs no serial/logging I/O.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
