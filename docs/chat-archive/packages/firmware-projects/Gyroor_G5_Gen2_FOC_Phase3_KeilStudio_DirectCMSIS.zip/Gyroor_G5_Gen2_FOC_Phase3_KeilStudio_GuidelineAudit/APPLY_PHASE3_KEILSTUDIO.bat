@echo off
setlocal
set "REPO=%~1"
if "%REPO%"=="" (
  echo.
  set /p "REPO=Full path to CLEAN Hoverboard-Firmware-Hack-Gen2.x-GD32 checkout: "
)
if "%REPO%"=="" (
  echo No repository path supplied.
  pause
  exit /b 2
)

where py >nul 2>nul
if not errorlevel 1 goto use_py
where python >nul 2>nul
if not errorlevel 1 goto use_python

echo Python 3 was not found in PATH.
echo Install Python, reopen this window, then run this file again.
pause
exit /b 3

:use_py
py "%~dp0apply_phase3_keilstudio.py" "%REPO%"
set "RC=%ERRORLEVEL%"
goto done

:use_python
python "%~dp0apply_phase3_keilstudio.py" "%REPO%"
set "RC=%ERRORLEVEL%"

goto done

:done
echo.
if not "%RC%"=="0" echo Migration installer exited with code %RC%.
pause
exit /b %RC%
