# AI-guideline audit — Gyroor G5 Phase 3 / Keil Studio

Audited against the repository root files `ai_guidelines.md`, `ai_guidelines_v0.md`, and `ai_guidelines_v1.md` on 2026-09-10.

## Changes made after the audit

- `BLDC_FOC` remains a normal `bldcXY` backend through `bldc.h` / `bldcFOC.c`.
- Removed the previous unrelated IMU-selection rewrite. Layout 2.1.20 keeps its upstream MPU6050/I2C declarations.
- Removed active PA6 motor-NTC sampling. PA6 remains unconfirmed and is not added to the ADC DMA scan.
- `BLDC_FOC` is selected only for `GD32F130` + layout `20`; other targets/layouts keep `BLDC_SINE`.
- Added a generic `BLDC_BACKEND_OUTPUT_ALLOWED()` extension hook to the common BLDC layer. Existing backends default to allowed; FOC can veto bridge output.
- `FOC_SAFE_BRINGUP=1` now causes the FOC backend to veto the common timer bridge-enable path. This is stronger than merely commanding zero phase offsets.
- The common BLDC layer re-checks the backend veto after `bldc_get_pwm()` so a newly detected FOC fault can disable the bridge in the same control cycle.
- `DEBUG_G5MON` is enabled only for the selected G5 FOC build. It performs no serial printing or blocking I/O and updates at 20 Hz.
- The adaptive thermal model is disabled for first bring-up (`CAP_USE_THERMAL_MODEL=0`) so its heavier RMS/thermal math is not executed in the PWM-rate interrupt. Current-sensor validity and a conservative current/profile ceiling remain active.
- Vendored EFeru generated `.c` files are wrapped with `#ifdef BLDC_FOC` so PlatformIO builds for other MCU targets do not link the FOC implementation.
- No unrelated refactors were made.

## Unavoidable core-file hooks

The guidelines prefer avoiding core files, but FOC needs two phase-current ADC channels and a hardware-output safety veto. The audited patch therefore makes small, localized edits to:

- `Inc/config.h`: select layout 20 / FOC for the G5 build only.
- `Inc/defines.h`: select a three-entry ADC DMA struct for FOC (`VBATT`, `PHASE_A`, `PHASE_B`).
- `Src/setup.c`: configure those two additional ADC inputs and scan channels when `BLDC_FOC` is selected.
- `Inc/bldc.h`: add the FOC backend and generic backend-output-veto hook.
- `Src/bldc.c`: consult that veto before enabling the timer bridge and after the backend control step.

These hooks are feature-required and preserve the existing BLDC base/backend architecture rather than embedding FOC control logic into the core files.

## Still unverified on hardware

- PA0/PB0 current polarity and exact counts-per-amp.
- Hall ordering/inversion expected by the EFeru FOC controller.
- Phase A/B/C output mapping to yellow/blue/green.
- First successful compile/link after CMSIS Solution conversion.
- First safe debug boot on the physical GD32F130C8.

`FOC_SAFE_BRINGUP` must remain `1` through those checks.
