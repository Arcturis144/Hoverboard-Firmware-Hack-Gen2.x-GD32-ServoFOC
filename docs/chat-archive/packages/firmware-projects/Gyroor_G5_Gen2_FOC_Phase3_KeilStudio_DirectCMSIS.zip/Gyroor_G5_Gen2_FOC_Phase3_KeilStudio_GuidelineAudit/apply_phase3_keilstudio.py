#!/usr/bin/env python3
"""Apply Gyroor G5 Phase-3 firmware integration and install Keil Studio/VS Code support.

This wrapper deliberately keeps the existing GD32F130 µVision target as the authoritative
hardware/project definition.  It applies the Phase-3 firmware patch, including g5mon,
then installs only editor/tool-environment support needed to convert that GD32 target to
a CMSIS Solution from inside Arm Keil Studio for VS Code.

It does NOT build, flash, or enable the motor bridge.
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
import re
from pathlib import Path

EXPECTED_DEVICE = "<Device>GD32F130C8</Device>"
EXPECTED_TARGET = "<TargetName>GD32F130</TargetName>"
EXPECTED_PACK = "GigaDevice.GD32F1x0_DFP.3.2.1"
SAFE_DEFINE_RE = re.compile(r"^\s*#define\s+FOC_SAFE_BRINGUP\s+1(?:\s|$)", re.MULTILINE)


def copy_file(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() and dst.read_bytes() == src.read_bytes():
        print(f"already installed {dst}")
        return
    if dst.exists():
        bak = dst.with_suffix(dst.suffix + ".keilstudio.bak")
        if not bak.exists():
            shutil.copy2(dst, bak)
    shutil.copy2(src, dst)
    print(f"installed {dst}")


def validate_repo(root: Path) -> None:
    project = root / "HoverBoardGigaDevice" / "Hoverboard.uvprojx"
    foc_config = root / "HoverBoardGigaDevice" / "Inc" / "foc_config.h"
    required_files = [
        root / "HoverBoardGigaDevice" / "Inc" / "bldcFOC.h",
        root / "HoverBoardGigaDevice" / "Inc" / "driveCapability.h",
        root / "HoverBoardGigaDevice" / "Inc" / "g5Monitor.h",
        root / "HoverBoardGigaDevice" / "Src" / "bldcFOC.c",
        root / "HoverBoardGigaDevice" / "Src" / "driveCapability.c",
        root / "HoverBoardGigaDevice" / "Src" / "g5Monitor.c",
        root / "HoverBoardGigaDevice" / "Src" / "BLDC_controller.c",
        root / "HoverBoardGigaDevice" / "Src" / "BLDC_controller_data.c",
    ]

    missing = [str(p.relative_to(root)) for p in required_files if not p.is_file()]
    if missing:
        raise RuntimeError("Missing Phase-3 files after patch:\n  " + "\n  ".join(missing))

    ptxt = project.read_text(encoding="utf-8")
    for marker, label in [
        (EXPECTED_TARGET, "GD32F130 target"),
        (EXPECTED_DEVICE, "GD32F130C8 device"),
        (EXPECTED_PACK, "GigaDevice GD32F1x0 DFP 3.2.1"),
        ("<FileName>bldcFOC.c</FileName>", "FOC adapter source"),
        ("<FileName>driveCapability.c</FileName>", "capability source"),
        ("<FileName>g5Monitor.c</FileName>", "g5mon source"),
        ("<FileName>BLDC_controller.c</FileName>", "generated FOC controller source"),
    ]:
        if marker not in ptxt:
            raise RuntimeError(f"Validation failed: {label} not found in Hoverboard.uvprojx")

    ftxt = foc_config.read_text(encoding="utf-8")
    if not SAFE_DEFINE_RE.search(ftxt):
        raise RuntimeError("Validation failed: FOC_SAFE_BRINGUP is not forced to 1")
    if "#define CAP_USE_MOTOR_NTC                0" not in ftxt:
        raise RuntimeError("Validation failed: tentative PA6/NTC must remain disabled")

    config_txt = (root / "HoverBoardGigaDevice" / "Inc" / "config.h").read_text(encoding="utf-8")
    bldc_h_txt = (root / "HoverBoardGigaDevice" / "Inc" / "bldc.h").read_text(encoding="utf-8")
    bldc_c_txt = (root / "HoverBoardGigaDevice" / "Src" / "bldc.c").read_text(encoding="utf-8")
    if "defined(GD32F130) && (LAYOUT == 20)" not in config_txt:
        raise RuntimeError("Validation failed: BLDC_FOC selection is not target/layout scoped")
    if "BLDC_BACKEND_OUTPUT_ALLOWED" not in bldc_h_txt or "BLDC_BACKEND_OUTPUT_ALLOWED" not in bldc_c_txt:
        raise RuntimeError("Validation failed: common backend bridge safety veto is missing")
    if not (root / "ai_guidelines_v1.md").is_file():
        raise RuntimeError("Validation failed: upstream ai_guidelines_v1.md is missing")

    solution = root / "HoverBoardGigaDevice" / "Gyroor_G5_Phase3.csolution.yml"
    cproject = root / "HoverBoardGigaDevice" / "Gyroor_G5_Phase3.cproject.yml"
    fallback_uv = root / "HoverBoardGigaDevice" / "Gyroor_G5_Phase3.uvprojx"
    if not solution.is_file() or not cproject.is_file() or not fallback_uv.is_file():
        raise RuntimeError("Validation failed: Keil Studio project files were not installed")
    stxt = solution.read_text(encoding="utf-8")
    ctxt = cproject.read_text(encoding="utf-8")
    if "device: GigaDevice::GD32F130C8" not in stxt:
        raise RuntimeError("Validation failed: CMSIS solution does not target GD32F130C8")
    if "name: ST-Link@pyOCD" not in stxt:
        raise RuntimeError("Validation failed: ST-Link debug adapter is missing from CMSIS solution")
    if "GigaDevice::Device:GD32F1x0_StdPeripherals:ADC" not in ctxt:
        raise RuntimeError("Validation failed: GD32 peripheral components are missing from CMSIS project")


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Apply Gyroor G5 Phase 3 and install Keil Studio support without building/flashing"
    )
    ap.add_argument("repo_root", help="Path to Hoverboard-Firmware-Hack-Gen2.x-GD32 checkout")
    ap.add_argument("--allow-upstream-drift", action="store_true")
    ap.add_argument("--skip-vendor", action="store_true", help="Skip downloading pinned EFeru FOC source")
    ns = ap.parse_args()

    bundle = Path(__file__).resolve().parent
    root = Path(ns.repo_root).expanduser().resolve()

    if not (root / "HoverBoardGigaDevice" / "Hoverboard.uvprojx").is_file():
        print(f"ERROR: Not a supported Gen2.x-GD32 checkout: {root}", file=sys.stderr)
        return 2

    # The user chose to backtrack from the CubeIDE branch. Refuse known CubeIDE wrapper
    # residue rather than silently mixing two IDE migrations in one checkout.
    cube_residue = [p for p in (root / ".project", root / "Makefile", root / "CubeIDE") if p.exists()]
    if cube_residue:
        print("ERROR: This checkout contains CubeIDE migration files:", file=sys.stderr)
        for item in cube_residue:
            print(f"  {item}", file=sys.stderr)
        print("Use a fresh/clean RoboDurden GD32 checkout for the Keil Studio migration.", file=sys.stderr)
        return 2

    cmd = [sys.executable, str(bundle / "apply_phase3.py"), str(root)]
    if ns.allow_upstream_drift:
        cmd.append("--allow-upstream-drift")
    if ns.skip_vendor:
        cmd.append("--skip-vendor")

    print("=== Applying Phase-3 firmware ===")
    rc = subprocess.call(cmd)
    if rc:
        return rc

    print("\n=== Installing Keil Studio support ===")
    support = bundle / "keilstudio"
    copy_file(support / ".vscode" / "extensions.json", root / ".vscode" / "extensions.json")
    copy_file(support / "vcpkg-configuration.json", root / "vcpkg-configuration.json")
    copy_file(support / "README_KEIL_STUDIO.md", root / "KeilStudio" / "README_KEIL_STUDIO.md")
    copy_file(support / "G5MON_WATCHES.txt", root / "KeilStudio" / "G5MON_WATCHES.txt")
    copy_file(support / "project" / "Gyroor_G5_Phase3.csolution.yml", root / "HoverBoardGigaDevice" / "Gyroor_G5_Phase3.csolution.yml")
    copy_file(support / "project" / "Gyroor_G5_Phase3.cproject.yml", root / "HoverBoardGigaDevice" / "Gyroor_G5_Phase3.cproject.yml")
    copy_file(support / "project" / "Gyroor_G5_GD32F130C8.sct", root / "HoverBoardGigaDevice" / "KeilStudio" / "Gyroor_G5_GD32F130C8.sct")

    # Keep an explicit, clearly named patched µVision project as a fallback converter input.
    copy_file(root / "HoverBoardGigaDevice" / "Hoverboard.uvprojx",
              root / "HoverBoardGigaDevice" / "Gyroor_G5_Phase3.uvprojx")

    try:
        validate_repo(root)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 3

    print("\n=== Validation passed ===")
    print("GD32 target : GD32F130C8")
    print("Device pack : GigaDevice::GD32F1x0_DFP@3.2.1 (declared by upstream µVision project)")
    print("Compiler    : AC6 for the FIRST Keil Studio build")
    print("Monitor     : DEBUG_G5MON/g5mon installed for GD32F130 layout 20 only")
    print("Safety      : FOC_SAFE_BRINGUP=1 + common bridge veto verified; PA6/NTC disabled")
    print("\nNext: open HoverBoardGigaDevice/Gyroor_G5_Phase3.csolution.yml in VS Code / Keil Studio.")
    print("No µVision conversion is required. Gyroor_G5_Phase3.uvprojx is retained only as a fallback.")
    print("Build only on the first pass; do not flash yet. See KeilStudio/README_KEIL_STUDIO.md.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
