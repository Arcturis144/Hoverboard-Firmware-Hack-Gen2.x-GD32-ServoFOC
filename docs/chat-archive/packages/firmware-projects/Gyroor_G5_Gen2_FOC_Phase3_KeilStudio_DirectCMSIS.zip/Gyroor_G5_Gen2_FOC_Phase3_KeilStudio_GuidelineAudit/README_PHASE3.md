# Gyroor G5 Phase 3 — guideline-audited FOC integration

This revision is based on the non-Cube Phase 3 but was reworked after reading `ai_guidelines.md`, `ai_guidelines_v0.md`, and `ai_guidelines_v1.md`.

The active design is intentionally conservative:

- FOC is implemented as the repository's expected `bldcXY` backend: `bldcFOC.c/.h`.
- FOC is selected only for `GD32F130` layout `20`; other targets/layouts retain `BLDC_SINE`.
- The ADC scan is exactly three channels for the FOC build: battery, phase A, phase B.
- PA6 is not sampled or assigned a temperature role.
- The previous IMU-selection rewrite was removed.
- `FOC_SAFE_BRINGUP=1` vetoes common BLDC bridge output.
- `DEBUG_G5MON` provides a low-rate debugger snapshot with no serial logging.
- The heavier adaptive thermal model is disabled for first bring-up.

See `AI_GUIDELINES_AUDIT.md` for the architectural rationale and remaining hardware unknowns.

## Apply

Use a fresh upstream checkout and run `APPLY_PHASE3_KEILSTUDIO.bat`. The wrapper refuses known CubeIDE residue and older Gyroor phase markers.

## First checkpoint

Convert the upstream `GD32F130` µVision target to a CMSIS Solution in Keil Studio and **build only**. Do not flash until the complete build output has been reviewed.
