#include "../Inc/bldcFOC.h"

#ifdef BLDC_FOC

#include "../Inc/defines.h"
#include "../Inc/foc_config.h"
#include "../Inc/driveCapability.h"
#include "../Inc/BLDC_controller.h"
#include "../Inc/rtwtypes.h"
#include <stdint.h>

/* Common Gen2.x state owned by bldc.c. */
extern adc_buf_t adc_buffer;
extern uint8_t hall_a;
extern uint8_t hall_b;
extern uint8_t hall_c;
extern FlagStatus bldc_enable;

/* Default parameter block supplied by EFeru's BLDC_controller_data.c. */
extern P rtP_Left;

/* One EFeru controller instance: one GD32F130 drives one motor. */
static RT_MODEL rtM_Foc_;
static RT_MODEL *const rtM_Foc = &rtM_Foc_;
static DW   rtDW_Foc;
static ExtU rtU_Foc;
static ExtY rtY_Foc;

/* Phase-current zero calibration. */
static uint16_t foc_offset_count = 0;
static int32_t foc_offset_a_acc = 0;
static int32_t foc_offset_b_acc = 0;

/* Debugger / CubeMonitor-visible values. */
volatile uint16_t foc_adc_phase_a_raw = 0;
volatile uint16_t foc_adc_phase_b_raw = 0;
volatile int16_t  foc_adc_phase_a_offset = 0;
volatile int16_t  foc_adc_phase_b_offset = 0;
volatile int16_t  foc_current_a_model = 0;
volatile int16_t  foc_current_b_model = 0;
volatile int16_t  foc_target_model = 0;
volatile int16_t  foc_out_phase_a = 0;
volatile int16_t  foc_out_phase_b = 0;
volatile int16_t  foc_out_phase_c = 0;
volatile int16_t  foc_speed_rpm_x16 = 0;
volatile int16_t  foc_iq_raw = 0;
volatile int16_t  foc_id_raw = 0;
volatile uint8_t  foc_error = 0;
volatile uint8_t  foc_offsets_ready = 0;
volatile uint16_t foc_dynamic_i_max_q4 = 0;

static int32_t foc_clamp_i32(int32_t v, int32_t lo, int32_t hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static uint8_t foc_hall_bit(uint8_t v, uint8_t invert)
{
    v = v ? 1U : 0U;
    return invert ? (uint8_t)!v : v;
}

static int16_t foc_adc_delta_to_model(int32_t delta, int32_t sign)
{
    int32_t v = delta * sign;
    v = (v * FOC_MODEL_COUNTS_PER_AMP) / FOC_ADC_COUNTS_PER_AMP;
    return (int16_t)foc_clamp_i32(v, -32768, 32767);
}

void InitBldc(void)
{
    /*
     * Keep EFeru's generated parameter table, but overwrite the settings that
     * must be explicit for this one-motor GD32F130 port.
     */
    rtP_Left.b_angleMeasEna      = 0;
    rtP_Left.z_selPhaCurMeasABC  = 0; /* provisional: EFeru {phase A, phase B} pair */
    rtP_Left.z_ctrlTypSel        = FOC_CONTROL_TYPE_FOC;
    rtP_Left.b_diagEna           = FOC_DIAGNOSTICS_ENABLE;
    rtP_Left.i_max               = (FOC_I_MOT_MAX_A * FOC_MODEL_COUNTS_PER_AMP) << 4;
    rtP_Left.n_max               = FOC_N_MOT_MAX_RPM << 4;
    rtP_Left.b_fieldWeakEna      = FOC_FIELD_WEAK_ENABLE;
    rtP_Left.id_fieldWeakMax     = (FOC_FIELD_WEAK_MAX_A * FOC_MODEL_COUNTS_PER_AMP) << 4;
    rtP_Left.a_phaAdvMax         = FOC_PHASE_ADV_MAX_DEG << 4;
    rtP_Left.r_fieldWeakHi       = FOC_FIELD_WEAK_HI << 4;
    rtP_Left.r_fieldWeakLo       = FOC_FIELD_WEAK_LO << 4;

    rtM_Foc->defaultParam = &rtP_Left;
    rtM_Foc->dwork        = &rtDW_Foc;
    rtM_Foc->inputs       = &rtU_Foc;
    rtM_Foc->outputs      = &rtY_Foc;

    DriveCapability_Init();
    BLDC_controller_initialize(rtM_Foc);
}

void bldc_get_pwm(int pwm, int pos, int *y, int *b, int *g)
{
    int32_t raw_delta_a;
    int32_t raw_delta_b;
    int32_t target;
    int32_t margin;
    int32_t output_limit;

    (void)pos; /* FOC uses the three Hall bits directly. */

    foc_adc_phase_a_raw = adc_buffer.phase_a;
    foc_adc_phase_b_raw = adc_buffer.phase_b;

    /* Establish current-sensor zero while the bridge is still disabled. */
    if (foc_offset_count < FOC_CURRENT_OFFSET_SAMPLES)
    {
        foc_offset_a_acc += adc_buffer.phase_a;
        foc_offset_b_acc += adc_buffer.phase_b;
        foc_offset_count++;

        if (foc_offset_count == FOC_CURRENT_OFFSET_SAMPLES)
        {
            foc_adc_phase_a_offset = (int16_t)(foc_offset_a_acc / FOC_CURRENT_OFFSET_SAMPLES);
            foc_adc_phase_b_offset = (int16_t)(foc_offset_b_acc / FOC_CURRENT_OFFSET_SAMPLES);
            foc_offsets_ready = 1;
        }

        DriveCapability_Update(0, 0,
                              adc_buffer.phase_a, adc_buffer.phase_b,
                              foc_offsets_ready, adc_buffer.v_batt);
        foc_dynamic_i_max_q4 = DriveCapability_GetEffectiveCurrentModelQ4();
        rtP_Left.i_max = (int16_T)foc_dynamic_i_max_q4;

        *y = 0;
        *b = 0;
        *g = 0;
        return;
    }

    raw_delta_a = (int32_t)foc_adc_phase_a_offset - (int32_t)adc_buffer.phase_a;
    raw_delta_b = (int32_t)foc_adc_phase_b_offset - (int32_t)adc_buffer.phase_b;

    foc_current_a_model = foc_adc_delta_to_model(raw_delta_a, FOC_PHASE_A_SIGN);
    foc_current_b_model = foc_adc_delta_to_model(raw_delta_b, FOC_PHASE_B_SIGN);

    /*
     * Global capability manager. This is intentionally BELOW all drive-profile
     * logic and ABOVE the FOC controller, so every present/future mode is
     * constrained by the same current/sensor/thermal capability ceiling.
     */
    DriveCapability_Update(foc_current_a_model, foc_current_b_model,
                           adc_buffer.phase_a, adc_buffer.phase_b,
                           foc_offsets_ready, adc_buffer.v_batt);
    foc_dynamic_i_max_q4 = DriveCapability_GetEffectiveCurrentModelQ4();
    rtP_Left.i_max = (int16_T)foc_dynamic_i_max_q4;

    /* Gen2.x presents approximately +/-BLDC_TIMER_MID_VALUE. EFeru expects +/-1000. */
    target = ((int32_t)pwm * 1000) / BLDC_TIMER_MID_VALUE;
    target = foc_clamp_i32(target, -1000, 1000);

#if FOC_SAFE_BRINGUP
    target = 0;
#endif
    foc_target_model = (int16_t)target;

#if FOC_SAFE_BRINGUP
    rtU_Foc.b_motEna = 0;
#else
    rtU_Foc.b_motEna = ((bldc_enable == SET) && (foc_dynamic_i_max_q4 > 0U)) ? 1 : 0;
#endif
    rtU_Foc.z_ctrlModReq = FOC_CONTROL_MODE_VOLTAGE;
    rtU_Foc.r_inpTgt     = (int16_T)target;
    rtU_Foc.b_hallA      = foc_hall_bit(hall_a, FOC_HALL_A_INVERT);
    rtU_Foc.b_hallB      = foc_hall_bit(hall_b, FOC_HALL_B_INVERT);
    rtU_Foc.b_hallC      = foc_hall_bit(hall_c, FOC_HALL_C_INVERT);
    rtU_Foc.i_phaAB      = foc_current_a_model;
    rtU_Foc.i_phaBC      = foc_current_b_model;
    rtU_Foc.i_DCLink     = 0; /* OL20180703-V4.1 layout 20 has no DC-link shunt. */
    rtU_Foc.a_mechAngle  = 0;

    BLDC_controller_step(rtM_Foc);

    foc_error           = rtY_Foc.z_errCode;
    foc_speed_rpm_x16   = rtY_Foc.n_mot;
    foc_iq_raw          = rtY_Foc.iq;
    foc_id_raw          = rtY_Foc.id;
    foc_out_phase_a     = rtY_Foc.DC_phaA;
    foc_out_phase_b     = rtY_Foc.DC_phaB;
    foc_out_phase_c     = rtY_Foc.DC_phaC;

    /*
     * Current Gen2 naming is y=phase A, b=phase B, g=phase C.
     * Preserve an EFeru-like PWM margin so low-side shunt samples retain a
     * usable window. This mapping is intentionally not enabled for torque until
     * verified on the unloaded physical motor.
     */
    margin = ((int32_t)BLDC_TIMER_PERIOD * FOC_PWM_MARGIN_PERMILLE) / 1000;
    output_limit = BLDC_TIMER_MID_VALUE - margin;
    if (output_limit < 0) output_limit = 0;

#if FOC_SAFE_BRINGUP
    *y = 0;
    *b = 0;
    *g = 0;
#else
    if ((bldc_enable == RESET) || (foc_dynamic_i_max_q4 == 0U) || foc_error)
    {
        *y = 0;
        *b = 0;
        *g = 0;
    }
    else
    {
        *y = (int)foc_clamp_i32(((int32_t)rtY_Foc.DC_phaA * output_limit) / 1000,
                                -output_limit, output_limit);
        *b = (int)foc_clamp_i32(((int32_t)rtY_Foc.DC_phaB * output_limit) / 1000,
                                -output_limit, output_limit);
        *g = (int)foc_clamp_i32(((int32_t)rtY_Foc.DC_phaC * output_limit) / 1000,
                                -output_limit, output_limit);
    }
#endif
}

#endif /* BLDC_FOC */
