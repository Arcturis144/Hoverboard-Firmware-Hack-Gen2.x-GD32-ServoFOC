#ifndef FOC_CONFIG_H
#define FOC_CONFIG_H

/*
 * Gyroor G5 / OLSZ OL20180703-V4.1 FOC integration configuration.
 *
 * PHASE 2 retains the Phase-1 non-driving bring-up lock and adds a global
 * adaptive drive-capability layer.  Normal/Snow/Boost profiles only request
 * different fractions of the available capability; none can bypass the
 * global current/sensor/thermal safety ceiling.
 */

#define FOC_SAFE_BRINGUP                 1

/* EFeru BLDC_controller numeric selections. */
#define FOC_CONTROL_TYPE_FOC             2
#define FOC_CONTROL_MODE_VOLTAGE         1
#define FOC_DIAGNOSTICS_ENABLE           1

/*
 * Provisional HARD ceiling for the first powered tests after SAFE_BRINGUP is
 * removed.  Do not raise this until PA0/PB0 current scaling and polarity are
 * measured and the inverter/motor thermal limits are characterized.
 */
#define FOC_I_MOT_MAX_A                  5
#define FOC_N_MOT_MAX_RPM                500

/* Field weakening is deliberately disabled during bring-up. */
#define FOC_FIELD_WEAK_ENABLE            0
#define FOC_FIELD_WEAK_MAX_A             0
#define FOC_PHASE_ADV_MAX_DEG            0
#define FOC_FIELD_WEAK_HI                1000
#define FOC_FIELD_WEAK_LO                750

/* EFeru's generated controller uses 50 internal current counts per ampere. */
#define FOC_MODEL_COUNTS_PER_AMP         50

/*
 * PROVISIONAL hardware scale only.
 * Layout 2.1.20 documents 4 mOhm low-side shunts and approximately 20x gain.
 * That implies about 99.3 ADC counts/A at a 3.3 V, 12-bit ADC.
 * Measure/calibrate this before enabling the bridge.
 */
#define FOC_ADC_COUNTS_PER_AMP           99

/* Current polarity: current = (zero_offset - ADC_sample) * sign. */
#define FOC_PHASE_A_SIGN                 1
#define FOC_PHASE_B_SIGN                 1

/* Hall-model mapping. Keep identity until verified with the motor unloaded. */
#define FOC_HALL_A_INVERT                0
#define FOC_HALL_B_INVERT                0
#define FOC_HALL_C_INVERT                0

/* Preserve a low-side-shunt sampling window. */
#define FOC_PWM_MARGIN_PERMILLE          55

/* Offset average length. At 16 kHz this is nominally 125 ms. */
#define FOC_CURRENT_OFFSET_SAMPLES       2000

/* ------------------------------------------------------------------------- */
/* Global adaptive drive-capability manager                                  */
/* ------------------------------------------------------------------------- */

/*
 * These are intentionally conservative Phase-2 defaults. The absolute limit
 * remains 5 A until bench calibration. Values use 0.01 A units to avoid float
 * in the high-rate control path.
 */
#define CAP_ABSOLUTE_CURRENT_CENTIAMP    (FOC_I_MOT_MAX_A * 100)
#define CAP_CONTINUOUS_CURRENT_CENTIAMP  300

/* Profiles are preferences, not safety limits. */
#define CAP_PROFILE_NORMAL_PERMILLE      650
#define CAP_PROFILE_SNOW_PERMILLE        850
#define CAP_PROFILE_BOOST_PERMILLE       1000
#define CAP_DEFAULT_PROFILE              DRIVE_PROFILE_NORMAL

/* Capability model update rate and provisional inverter/motor thermal model. */
#define CAPABILITY_UPDATE_HZ             100
#define CAP_THERMAL_TAU_SECONDS          120
#define CAP_THERMAL_SOFT_PERMILLE        700
#define CAP_THERMAL_HARD_PERMILLE        1000
#define CAP_THERMAL_CUTOFF_PERMILLE      1250

/* Raw ADC readings closer than this to either rail are treated as invalid. */
#define CAP_CURRENT_ADC_RAIL_GUARD       16

/*
 * Battery derating is wired into the common manager but OFF until the final
 * mower battery configuration is confirmed. When enabled it uses the existing
 * Gen2 BAT_LOW_LVL2 / BAT_LOW_DEAD thresholds derived from BAT_CELLS.
 */
#define CAP_USE_BATTERY_DERATE           0

/*
 * Temperature input hook is present but OFF because the board-temperature/PA6
 * function has not yet been proven. Once a real sensor is identified, feed it
 * through DriveCapability_SetTemperatureDeciC() and enable this switch.
 */
#define CAP_USE_TEMPERATURE_SENSOR       0
#define CAP_TEMP_DERATE_START_DECIC      700
#define CAP_TEMP_CUTOFF_DECIC            900

#if CAP_CONTINUOUS_CURRENT_CENTIAMP > CAP_ABSOLUTE_CURRENT_CENTIAMP
#error "Continuous current cannot exceed absolute current"
#endif

/* EFeru's i_max parameter is int16 Q4 at 50 counts/A; keep under its range. */
#if CAP_ABSOLUTE_CURRENT_CENTIAMP > 4000
#error "Phase-2 EFeru adapter supports at most 40.00 A without changing model scaling"
#endif

#endif /* FOC_CONFIG_H */
