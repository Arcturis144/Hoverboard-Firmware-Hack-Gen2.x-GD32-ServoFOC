# Gyroor G5 Gen2.1.20 + EFeru FOC — Phase 2

Target hardware: **OLSZ OL20180703-V4.1**, **GD32F130C8T6**, current RoboDurden Gen2.x-GD32 **layout 2.1.20**.

Phase 2 keeps the Phase-1 Gen2.1.20 + EFeru FOC merge and adds a **single global adaptive drive-capability manager**. The manager sits below all drive profiles and above the EFeru FOC current limit, so Normal, Snow, Boost, RC, and future Pi/autonomous modes all share the same hardware-protection ceiling.

## Control architecture

```text
RC / Pi / future autonomous command
              |
              v
       requested drive profile
       Normal / Snow / Boost
              |
              v
   profile preference current cap
              |
              +-------------------------+
                                        |
PA0/PB0 phase current ---> current validity / I^2 thermal model
battery voltage ---------> optional battery derate
future board temp -------> optional measured-temp derate
                                        |
                                        v
                         GLOBAL CAPABILITY LIMIT
                                        |
                                        v
                         min(profile, capability)
                                        |
                                        v
                         EFeru rtP_Left.i_max
                                        |
                                        v
                                  FOC controller
```

A drive profile can request less than the available capability, but **no profile can request more than the common capability manager permits**.

## Current Phase-2 profile defaults

These are deliberately conservative bring-up values, not final mower values:

```text
Absolute Phase-2 ceiling: 5.00 A
Thermal continuous model: 3.00 A

Normal preference: 65% of absolute = 3.25 A
Snow preference:   85% of absolute = 4.25 A
Boost preference: 100% of absolute = 5.00 A
```

`FOC_SAFE_BRINGUP` remains **1**, so the bridge is still forced off. These limits become relevant only after the current/Hall/PWM validation sequence is complete and the bring-up lock is deliberately removed.

The 5 A absolute ceiling remains intentionally low until the PA0/PB0 current conversion and the actual inverter/motor thermal limits are measured. Raising a profile percentage cannot bypass that ceiling.

## Adaptive thermal model

The manager reconstructs the third phase current from the two measured phase currents:

```text
Ic = -(Ia + Ib)
```

It accumulates the three-phase mean-square current at the PWM/control rate and updates a first-order thermal-load estimate at 100 Hz. The present model uses:

```text
thermal continuous current = 3.00 A
thermal time constant       = 120 s
soft derate begins          = 70% normalized thermal load
continuous-current point    = 100%
full thermal cutoff         = 125%
```

All of those are explicitly **provisional**. They are safe scaffolding for instrumented bring-up, not claimed physical constants of the motor or controller.

Behavior is approximately:

```text
cold / low accumulated I^2t
    -> full hardware current capability available

thermal load rises above soft threshold
    -> permitted current progressively falls toward continuous current

thermal load exceeds hard region
    -> current is reduced below continuous to force cooling

thermal cutoff reached
    -> effective current limit = 0
```

Because this manager is common, the same derating applies in Normal, Snow, Boost, and every future mode.

## What is genuinely self-calibrating already

The phase-current **zero offsets** are re-established on each boot while motor output is disabled. That compensates for ADC/amplifier zero-offset differences between controllers and normal offset drift between power cycles.

The absolute **amps-per-ADC-count gain is not self-calibrated yet**. `FOC_ADC_COUNTS_PER_AMP=99` remains only the engineering estimate from the 4 mOhm shunt / ~20x gain description. One real current reference is still required before meaningful ampere limits can be trusted.

## Temperature hook

The capability manager already contains:

```c
DriveCapability_SetTemperatureDeciC(...)
```

and measured-temperature derating logic, but it is disabled by default:

```c
#define CAP_USE_TEMPERATURE_SENSOR 0
```

We have **not proven what PA6 measures**, so Phase 2 does not pretend that PA6 is a temperature sensor. Once the actual board/heatsink temperature source is identified, it can be connected to this common manager without restructuring the drive modes.

Provisional temperature thresholds are present only as disabled placeholders and must be reviewed against the real sensor location and hardware.

## Battery derating hook

Battery-voltage derating is also implemented in the common manager but disabled initially:

```c
#define CAP_USE_BATTERY_DERATE 0
```

When enabled, it uses Gen2's existing `BAT_LOW_LVL2` and `BAT_LOW_DEAD` thresholds derived from `BAT_CELLS`. Leave it disabled until the final mower/snow-platform battery arrangement is fixed.

## Fail-closed current sensing

The common manager refuses motor capability if:

- current-zero calibration has not completed; or
- either phase-current ADC is near a 12-bit ADC rail, indicating saturation/disconnection/invalid measurement.

When that occurs:

```text
cap_global_limit_centiamp    = 0
cap_effective_limit_centiamp = 0
rtP_Left.i_max               = 0
rtU_Foc.b_motEna             = 0
```

This is independent of the selected drive profile.

## Drive profile API

The profile interface is now part of the firmware:

```c
DriveCapability_SetProfile(DRIVE_PROFILE_NORMAL);
DriveCapability_SetProfile(DRIVE_PROFILE_SNOW);
DriveCapability_SetProfile(DRIVE_PROFILE_BOOST);
```

For now the default is Normal. We have **not yet assigned an RC channel** to switch profiles. That should be done when the FS-iA6B input layer is added.

The profile currently changes only the preferred current envelope. Later Snow can additionally request lower maximum wheel speed / stronger speed regulation, while still passing through this same capability manager.

## CubeMonitor / debugger symbols

Phase-1 FOC symbols remain, plus:

```text
foc_dynamic_i_max_q4

cap_profile
cap_fault_flags
cap_current_sensor_valid
cap_current_rms_centiamp
cap_absolute_limit_centiamp
cap_thermal_limit_centiamp
cap_battery_limit_centiamp
cap_temperature_limit_centiamp
cap_global_limit_centiamp
cap_profile_limit_centiamp
cap_effective_limit_centiamp
cap_thermal_load_permille
cap_temperature_valid
cap_temperature_deci_c
```

Current-limit values ending in `_centiamp` use **0.01 A** units. For example:

```text
425 = 4.25 A
500 = 5.00 A
```

`cap_thermal_load_permille` uses:

```text
1000 = normalized continuous thermal load
```

## Apply Phase 2

### To a clean current Gen2.x-GD32 checkout

```bash
python3 apply_phase2.py /path/to/Hoverboard-Firmware-Hack-Gen2.x-GD32
```

### To a checkout that already has the Phase-1 bundle applied

Run the same command. The patcher recognizes the Phase-1 markers, leaves the already-modified Gen2 base files alone, and replaces/adds the Phase-2 overlay files. Changed overlay files receive `.phase2.bak` backups.

The EFeru generated FOC core remains pinned to commit:

```text
4f141cbc97b297e194fd58e56444bd0322f902ac
```

Only these generated controller components are vendored; EFeru's STM32F103 HAL/application layer is not imported.

## First build gate still applies

The GD32F130C8 has only **64 KiB flash / 8 KiB SRAM**. Phase 2 adds another source module and state variables, so rebuild and record final flash/RAM usage before flashing.

Do not remove:

```c
#define FOC_SAFE_BRINGUP 1
```

until all Phase-1 validation items are complete:

1. image fits flash/RAM;
2. PA0/PB0 zero offsets are stable;
3. ADC-counts-per-amp and polarity are calibrated;
4. two phase-current channels are mapped correctly;
5. Hall order/inversion is proven;
6. FOC phase output mapping is proven;
7. PWM current-sampling window is scoped and valid;
8. unloaded motor first-drive is performed with a current-limited supply.

After that, the next firmware step should be **instrumented current calibration and low-current FOC rotation**, not raising the 5 A absolute limit.
