# Gyroor G5 Phase 3 — Keil Studio / VS Code migration

This support layer moves the **development workflow** for the Gyroor G5 GD32F130C8 Phase-3 firmware into **Arm Keil Studio for Visual Studio Code** while keeping the existing RoboDurden/GigaDevice project as the source of truth.

> **Use a clean/fresh RoboDurden GD32 checkout.** The wrapper intentionally refuses a checkout containing the earlier CubeIDE `.project`, root `Makefile`, or `CubeIDE/` directory so the two IDE migrations are not mixed.

## What this package changes

The installer first applies the normal Phase-3 firmware integration, including:

- OLSZ OL20180703-V4.1 / Gen2.1.20 layout selection
- EFeru FOC adapter and pinned generated FOC source
- global current / thermal / tentative motor-NTC capability manager
- Phase-3 4-channel ADC mapping
- `g5mon` low-rate debugger snapshot structure
- the existing `Hoverboard.uvprojx` source list updated with the Phase-3 files

It then adds only these Keil Studio support files:

- `.vscode/extensions.json`
- `vcpkg-configuration.json`
- `KeilStudio/README_KEIL_STUDIO.md`
- `KeilStudio/G5MON_WATCHES.txt`

It does **not** install CubeIDE files, an Eclipse `.project`, an OpenOCD helper tree, or a stand-alone Makefile.

## Important safety state

The migration does not enable motor output.

`HoverBoardGigaDevice/Inc/foc_config.h` must still contain:

```c
#define FOC_SAFE_BRINGUP 1
```

With that enabled the FOC adapter forces all three phase outputs to zero. Keep it enabled through the first build, first flash, debugger connection, ADC/current validation, Hall/phase validation and monitor checks.

The PA6 motor-NTC interpretation remains provisional. `CAP_MOTOR_NTC_REQUIRE_VALID` stays disabled until the extra motor wire is physically confirmed.

## Why the first Keil Studio build stays on AC6

The upstream `GD32F130` target in `Hoverboard.uvprojx` already uses Arm Compiler 6 and declares the real GigaDevice device and pack:

- Device: `GD32F130C8`
- Pack: `GigaDevice::GD32F1x0_DFP@3.2.1`
- Flash: 64 KiB at `0x08000000`
- RAM: 8 KiB at `0x20000000`

Keeping AC6 for the first converted build preserves the compiler/startup/component assumptions of the known µVision target. A later GCC conversion is possible, but it should be treated as a separate controlled change because compiler switching can also require different startup/linker files.

The included `vcpkg-configuration.json` lets the VS Code Environment Manager obtain the CMSIS build tools, CMake, Ninja and Arm Compiler within the VS Code workflow.

## One-time conversion in VS Code

1. Open the **root of the patched repository** in VS Code.
2. Accept the recommendation to install **Arm Keil Studio Pack**.
3. Allow the Environment Manager to activate/install the tools described by `vcpkg-configuration.json`.
4. In the Explorer locate:

   `HoverBoardGigaDevice/Hoverboard.uvprojx`

5. Right-click that file and choose **Convert µVision project to csolution** (wording can vary slightly by extension version).
6. Convert the **GD32F130** target. Other upstream targets such as GD32F103/GD32E230/MM32SPIN05 are not needed for this controller.
7. In the CMSIS/Manage Solution view verify the converted context resolves:

   - device `GD32F130C8`
   - GigaDevice `GD32F1x0_DFP` pack, version 3.2.1
   - compiler `AC6`

8. Do not flash yet. First use **Build/Rebuild** in the CMSIS view and inspect the complete build output and memory use.

The converter may generate `.csolution.yml`, `.cproject.yml`, `.cbuild-run.yml`, `.vscode/tasks.json`, and `.vscode/launch.json`. Those are the files that let subsequent build/run/debug actions stay inside VS Code.

## First build acceptance checks

Before programming the board, verify all of the following:

- build completes with no linker errors
- output targets Cortex-M3 / GD32F130C8
- flash use is below 64 KiB
- RAM use is below 8 KiB
- `g5mon` is present as a global symbol in the debug image
- `FOC_SAFE_BRINGUP` is still 1
- no STM32 HAL/startup files have appeared

## ST-Link debugging

After the build is accepted:

1. Connect ST-Link to SWDIO, SWCLK and GND.
2. Power the controller normally; do not power the board from the ST-Link 3.3 V pin.
3. In **Manage Solution / Run and Debug**, select an ST-Link debug adapter and SWD protocol.
4. Use the generated Run/Debug configuration from within VS Code.

The controller has no convenient exposed NRST in the current bench wiring, so if reset behavior needs adjustment do that in the Keil Studio/CMSIS debug configuration rather than adding an assumed NRST connection.

Actual flash/debug behavior on this exact Gyroor board still needs bench validation; do not treat a successful project conversion as proof that programming has been tested.

## `g5mon` live monitoring

The firmware updates the global `g5mon` snapshot at a deliberately low rate (default 100 Hz) so debugger reads do not run at the PWM/FOC update rate.

Start with these fields:

```text
g5mon.magic
g5mon.update_counter
g5mon.foc.safe_bringup
g5mon.foc.bridge_enabled
```

Expected safe-bring-up values are:

```text
g5mon.magic              0x47354D31
g5mon.update_counter     increasing
g5mon.foc.safe_bringup   1
g5mon.foc.bridge_enabled 0
```

Then add the current, ADC, Hall, capability and FOC fields listed in `KeilStudio/G5MON_WATCHES.txt` to **Trace and Live** or the normal Watch view.

Do not disable `FOC_SAFE_BRINGUP` merely to make a live value change. Bridge enable is a later bring-up step after the sensor/current/phase checks pass.
