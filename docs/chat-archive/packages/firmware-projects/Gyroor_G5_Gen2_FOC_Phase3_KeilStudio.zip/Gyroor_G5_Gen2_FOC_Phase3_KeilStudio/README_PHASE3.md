# Gyroor G5 Gen2.1.20 + EFeru FOC — Phase 3

Target hardware: **OLSZ OL20180703-V4.1**, **GD32F130C8T6**, RoboDurden Gen2.x-GD32 **layout 2.1.20**.

Phase 3 keeps the Phase-2 global adaptive capability manager and tentatively adds the factory **PA6 resistive temperature channel as the motor NTC**. This is deliberately done in resistance units only: the factory firmware proves a 10 kOhm-divider-style calculation and 8.0 kOhm / 6.0 kOhm thermal thresholds, but the thermistor Beta curve and Celsius values have not yet been measured.

`FOC_SAFE_BRINGUP` remains **1**, so the motor bridge is still forced to zero output.

## Global control architecture

```text
Normal / Snow / Boost / future autonomous profile
                       |
                       v
                profile preference
                       |
                       +------------------------------+
                                                      |
PA0/PB0 phase currents -> current validity + I^2 thermal model
PA6 tentative motor NTC -> measured motor thermal limit
battery voltage --------> optional battery derate
future board temperature> optional second temperature limit
                                                      |
                                                      v
                                      GLOBAL CAPABILITY LIMIT
                                                      |
                                                      v
                                           EFeru FOC i_max
```

Every mode passes through the same capability layer. Snow/Boost can request more torque, but neither can bypass current, thermal, sensor-validity, battery, or motor-NTC limits.

## Tentative PA6 motor-NTC implementation

The FOC ADC DMA scan is now four channels:

```text
slot 0 -> PA4 / VBATT
slot 1 -> PB0 / PHASE_A current
slot 2 -> PA0 / PHASE_B current
slot 3 -> PA6 / tentative motor NTC
```

The current Gen2 ADC DMA length is derived from `sizeof(adc_buffer)`, so extending `adc_buf_t` to four `uint16_t` values automatically makes the DMA and regular ADC sequence four conversions.

The firmware computes tentative NTC resistance as:

```text
Rntc = 10000 * ADC / (4096 - ADC)
```

This is the same divider form reconstructed from the factory firmware, rescaled from the factory's filtered 15-bit representation to the raw 12-bit ADC.

Current thresholds are intentionally the factory resistance points:

```text
R >= 8.0 kOhm : no measured-temperature derate
8.0 -> 6.0 kOhm: smooth provisional derate
R <= 6.0 kOhm : measured motor-temperature current limit = 0
```

This **does not claim** that 8 kOhm or 6 kOhm correspond to any particular Celsius temperature yet.

## How PA6 combines with current heating

The Phase-2 I^2/current-heating model remains active. Phase 3 does not replace it with the NTC; the two protections operate independently and the lower current allowance wins:

```text
allowed current = min(
    absolute hardware ceiling,
    I^2/current-heating limit,
    PA6 motor-NTC limit,
    optional battery limit,
    optional board-temperature limit
)
```

That gives us both:

- **prediction** from current history before the motor gets hot; and
- **direct feedback** from the motor temperature sensor when the motor actually heats.

Once the NTC curve is characterized, the resistance-only limiter can be replaced with a calibrated motor-temperature model without changing the drive-mode architecture.

## Tentative sensor validity policy

While PA6=motor NTC is still a hypothesis:

```c
#define CAP_MOTOR_NTC_REQUIRE_VALID 0
```

An open/short/rail PA6 reading sets `CAP_FAULT_MOTOR_NTC_INVALID`, but does **not** yet force zero torque. After the unidentified motor wire is proven to be the NTC connection, change this to:

```c
#define CAP_MOTOR_NTC_REQUIRE_VALID 1
```

Then loss of the motor-temperature sensor becomes fail-safe.

## Current conservative bring-up values

```text
absolute current ceiling: 5.00 A
continuous current model: 3.00 A
Normal profile:           65%
Snow profile:             85%
Boost profile:           100%
```

These are bring-up scaffolding only. PA0/PB0 amps-per-count and polarity still require physical calibration before meaningful high-current testing.

## CubeMonitor / debugger variables

New PA6 variables:

```text
foc_adc_motor_ntc_raw
cap_motor_ntc_raw
cap_motor_ntc_filtered_raw
cap_motor_ntc_ohm
cap_motor_ntc_valid
cap_motor_ntc_limit_centiamp
```

Existing capability variables remain:

```text
cap_current_rms_centiamp
cap_thermal_load_permille
cap_thermal_limit_centiamp
cap_global_limit_centiamp
cap_profile_limit_centiamp
cap_effective_limit_centiamp
cap_fault_flags
foc_dynamic_i_max_q4
```

`_centiamp` means 0.01 A.

## Apply Phase 3

To a clean supported Gen2.x-GD32 checkout **or** a checkout already patched by Phase 1/2:

```bash
python3 apply_phase3.py /path/to/Hoverboard-Firmware-Hack-Gen2.x-GD32
```

The patcher:

- selects GD32F130 layout 20 on a clean checkout;
- preserves the multi-IMU selection path;
- adds/updates the four-channel FOC ADC buffer and PA6 analog setup;
- installs the Phase-3 FOC/capability overlay;
- adds the FOC/capability and pinned EFeru generated source/header files to the Keil project;
- vendors the EFeru generated FOC core pinned to commit `4f141cbc97b297e194fd58e56444bd0322f902ac`;
- makes `.phase3.bak` backups before changing existing files.

Use `--allow-upstream-drift` only after reviewing upstream changes if the supported Git blobs no longer match.

## Before enabling motor output

Keep:

```c
#define FOC_SAFE_BRINGUP 1
```

until at minimum:

1. the image fits 64 KiB flash / 8 KiB SRAM;
2. PA0/PB0 offsets and amps-per-count are calibrated;
3. Hall order and phase output mapping are proven;
4. PA6 resistance can be observed changing with motor temperature;
5. the unidentified motor wire is electrically confirmed as the NTC lead;
6. the PA6 NTC curve is characterized enough to assign real temperatures;
7. current-limited unloaded FOC rotation has been validated.

For the next bench test, the most useful observation is simply to log `cap_motor_ntc_ohm` while warming the motor and compare it with the extra motor-wire resistance measured to Hall ground.
