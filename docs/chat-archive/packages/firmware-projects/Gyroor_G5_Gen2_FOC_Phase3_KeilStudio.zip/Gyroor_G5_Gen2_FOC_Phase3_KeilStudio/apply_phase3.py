#!/usr/bin/env python3
"""Apply Phase-3 Gyroor G5 Gen2.1.20 + EFeru FOC integration.

Phase 3 adds the tentative factory PA6 motor-NTC channel to the global
capability manager while retaining the Phase-2 current-heating model.
It can be applied to either a clean supported upstream checkout or a checkout
previously patched by Phase 1/2.
"""

from __future__ import annotations
import argparse
import hashlib
import re
import shutil
import subprocess
import sys
from pathlib import Path

EXPECTED = {
    "HoverBoardGigaDevice/Inc/config.h": "75aee4d4e25ed1e3366621120423b9005321d426",
    "HoverBoardGigaDevice/Inc/bldc.h": "8b450cbbca99cf964d7be1d0071a2fbfe2f8b8cb",
    "HoverBoardGigaDevice/Inc/defines.h": "683a72c7f4ab2f0e87b41670a75c5aa452724931",
    "HoverBoardGigaDevice/Inc/defines/defines_2-1-20.h": "b977d94ea58a34ce59f9ce8ecfb5761b0e4b7241",
    "HoverBoardGigaDevice/Src/setup.c": "5bbf6761749decc814ddd0ca49855f77b45e1317",
    "HoverBoardGigaDevice/Hoverboard.uvprojx": "fabcacb87f3de51c4d1ac25c72949d65bd3cce69",
}

MARKER = "GYROOR_G5_FOC_PHASE3"
OLD_MARKERS = ("GYROOR_G5_FOC_PHASE1", "GYROOR_G5_FOC_PHASE2")


def git_blob_sha1(data: bytes) -> str:
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()


def has_old_marker(text: str) -> bool:
    return any(m in text for m in OLD_MARKERS)


def checked_read(root: Path, rel: str, allow_drift: bool) -> str:
    path = root / rel
    data = path.read_bytes()
    text = data.decode("utf-8")
    if MARKER in text or has_old_marker(text):
        return text
    actual = git_blob_sha1(data)
    expected = EXPECTED[rel]
    if actual != expected and not allow_drift:
        raise RuntimeError(
            f"Upstream file changed; refusing automatic patch: {rel}\n"
            f" expected blob {expected}\n actual blob   {actual}\n"
            f"Review upstream changes, then rerun with --allow-upstream-drift if appropriate."
        )
    return text


def backup_and_write(root: Path, rel: str, text: str) -> None:
    path = root / rel
    backup = path.with_suffix(path.suffix + ".phase3.bak")
    if not backup.exists():
        shutil.copy2(path, backup)
    path.write_text(text, encoding="utf-8", newline="")
    print(f"patched {rel}")


def require_once(text: str, old: str, new: str, label: str) -> str:
    if old not in text:
        raise RuntimeError(f"Could not find expected text for {label}")
    return text.replace(old, new, 1)


def patch_config(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Inc/config.h"
    text = checked_read(root, rel, allow_drift)
    if MARKER in text or has_old_marker(text):
        print(f"base integration already present: {rel}")
        return

    anchor = "\t// choose your target in the dropdown list to the top-right of the Keil IDE\n"
    imu = f"""\t/* {MARKER}: compile-time IMU selection for layout 2.1.20. */
\t#define IMU_TYPE_MPU6050_OLD     1
\t#define IMU_TYPE_MPU6050_COMPAT  2
\t#define IMU_TYPE_MPU6500         3
\t#define IMU_TYPE_BMI160          4
\t#ifndef IMU_TYPE
\t\t#define IMU_TYPE IMU_TYPE_MPU6050_OLD
\t#endif
\n"""
    text = require_once(text, anchor, imu + anchor, "config IMU selector")

    text, n = re.subn(
        r"(\t#ifdef GD32F130\t\t// TARGET = 1\r?\n)\t\t#define LAYOUT 1\r?\n\t\t#define LAYOUT_SUB 1[^\r\n]*",
        r"\1\t\t#define LAYOUT 20\n\t\t//#define LAYOUT_SUB 1\t// not used by layout 2.1.20",
        text,
        count=1,
    )
    if n != 1:
        raise RuntimeError("Could not select GD32F130 layout 20")

    old = """\t//#define BLDC_BC\t\t\t// old block commutation bldc control
\t#define BLDC_SINE\t\t\t// silent sine-pwm motor control, added 2025 by Robo Durden. 
\t//#define BLDC_SINE_BOOSTER\t\t// can boost speed by 15% starting from 87% throttle.
"""
    new = f"""\t//#define BLDC_BC\t\t\t// old block commutation bldc control
\t//#define BLDC_SINE\t\t\t// Gen2 sine backend
\t#define BLDC_FOC\t\t\t// {MARKER}: EFeru FOC backend adapter
\t//#define BLDC_SINE_BOOSTER\t\t// only applies to BLDC_SINE
"""
    text = require_once(text, old, new, "BLDC_FOC selection")
    backup_and_write(root, rel, text)


def patch_layout(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Inc/defines/defines_2-1-20.h"
    text = checked_read(root, rel, allow_drift)
    if MARKER in text or has_old_marker(text):
        print(f"IMU compatibility integration already present: {rel}")
        return

    pattern = re.compile(
        r"//#define MPU_6050[^\r\n]*\r?\n#define MPU_6050old\s*\r?\n#define I2C_PB6PB7[^\r\n]*"
    )
    replacement = f"""/* {MARKER}: keep all Gen2-supported IMU implementations selectable. */
#if IMU_TYPE == IMU_TYPE_MPU6050_OLD
\t#define MPU_6050old
#elif IMU_TYPE == IMU_TYPE_MPU6050_COMPAT
\t#define MPU_6050
#elif IMU_TYPE == IMU_TYPE_MPU6500
\t#define MPU_6500
#elif IMU_TYPE == IMU_TYPE_BMI160
\t#define BMI_160
#else
\t#error "Unsupported IMU_TYPE for layout 2.1.20"
#endif
#define I2C_PB6PB7\t// IMU bus on this layout"""
    text, n = pattern.subn(replacement, text, count=1)
    if n != 1:
        raise RuntimeError("Could not replace layout-20 IMU selection")
    backup_and_write(root, rel, text)


def patch_bldc_h(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Inc/bldc.h"
    text = checked_read(root, rel, allow_drift)
    if "bldcFOC.h" in text:
        print(f"FOC backend selector already present: {rel}")
        return
    old = """#if defined(BLDC_BC)
\t#include "../Inc/bldcBC.h"
#elif defined(BLDC_SINE)
\t#include "../Inc/bldcSINE.h"
#endif
"""
    new = f"""#if defined(BLDC_BC)
\t#include "../Inc/bldcBC.h"
#elif defined(BLDC_SINE)
\t#include "../Inc/bldcSINE.h"
#elif defined(BLDC_FOC) /* {MARKER} */
\t#include "../Inc/bldcFOC.h"
#endif
"""
    text = require_once(text, old, new, "bldc backend selector")
    backup_and_write(root, rel, text)


def phase3_adc_struct() -> str:
    return f"""// ADC buffer struct
#ifdef BLDC_FOC /* {MARKER} */
\t#if defined(REMOTE_ADC)
\t\t#error "Phase-3 BLDC_FOC uses a 4-channel motor-feedback ADC scan and cannot be combined with REMOTE_ADC yet"
\t#endif
\t#if !defined(VBATT) || !defined(PHASE_A) || !defined(PHASE_B)
\t\t#error "BLDC_FOC requires VBATT, PHASE_A and PHASE_B in the board layout"
\t#endif
\ttypedef struct
\t{{
\t\tuint16_t v_batt;
\t\tuint16_t phase_a;
\t\tuint16_t phase_b;
\t\tuint16_t motor_ntc; /* tentative factory ADC ch6 / PA6 */
\t}} adc_buf_t;
#else
\ttypedef struct
\t{{
\t  uint16_t v_batt;
\t\tuint16_t current_dc;
\t\t#ifdef REMOTE_ADC
\t\t\tuint16_t speed;
\t\t\tuint16_t steer;
\t\t#endif
\t}} adc_buf_t;
#endif
"""


def patch_defines_h(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Inc/defines.h"
    text = checked_read(root, rel, allow_drift)
    if MARKER in text and "motor_ntc" in text:
        print(f"Phase-3 ADC buffer already present: {rel}")
        return

    phase2 = """// ADC buffer struct
#ifdef BLDC_FOC /* GYROOR_G5_FOC_PHASE2 */
\t#if defined(REMOTE_ADC)
\t\t#error "Phase-2 BLDC_FOC uses a 3-channel phase-current ADC scan and cannot be combined with REMOTE_ADC yet"
\t#endif
\t#if !defined(VBATT) || !defined(PHASE_A) || !defined(PHASE_B)
\t\t#error "BLDC_FOC requires VBATT, PHASE_A and PHASE_B in the board layout"
\t#endif
\ttypedef struct
\t{
\t\tuint16_t v_batt;
\t\tuint16_t phase_a;
\t\tuint16_t phase_b;
\t} adc_buf_t;
#else
\ttypedef struct
\t{
\t  uint16_t v_batt;
\t\tuint16_t current_dc;
\t\t#ifdef REMOTE_ADC
\t\t\tuint16_t speed;
\t\t\tuint16_t steer;
\t\t#endif
\t} adc_buf_t;
#endif
"""
    clean = """// ADC buffer struct
typedef struct
{
  uint16_t v_batt;
\tuint16_t current_dc;
\t#ifdef REMOTE_ADC
\t\tuint16_t speed;
\t\tuint16_t steer;
\t#endif
\t
} adc_buf_t;
"""
    if phase2 in text:
        text = text.replace(phase2, phase3_adc_struct(), 1)
    elif clean in text:
        text = text.replace(clean, phase3_adc_struct(), 1)
    else:
        raise RuntimeError("Could not identify clean or Phase-2 ADC buffer in defines.h")
    backup_and_write(root, rel, text)


def patch_setup(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Src/setup.c"
    text = checked_read(root, rel, allow_drift)
    if MARKER in text and "CAP_MOTOR_NTC_PIN" in text:
        print(f"Phase-3 ADC setup already present: {rel}")
        return

    clean_gpio = """\t\t#ifdef CURRENT_DC
\t\t\tpinMode(CURRENT_DC, GPIO_MODE_ANALOG);
\t\t#endif
\t\t#ifdef REMOTE_ADC
"""
    phase2_gpio = """\t\t#ifdef CURRENT_DC
\t\t\tpinMode(CURRENT_DC, GPIO_MODE_ANALOG);
\t\t#endif
\t\t#ifdef BLDC_FOC /* GYROOR_G5_FOC_PHASE2 */
\t\t\tpinMode(PHASE_A, GPIO_MODE_ANALOG);
\t\t\tpinMode(PHASE_B, GPIO_MODE_ANALOG);
\t\t#endif
\t\t#ifdef REMOTE_ADC
"""
    phase3_gpio = f"""\t\t#ifdef CURRENT_DC
\t\t\tpinMode(CURRENT_DC, GPIO_MODE_ANALOG);
\t\t#endif
\t\t#ifdef BLDC_FOC /* {MARKER} */
\t\t\tpinMode(PHASE_A, GPIO_MODE_ANALOG);
\t\t\tpinMode(PHASE_B, GPIO_MODE_ANALOG);
\t\t\t#if CAP_USE_MOTOR_NTC
\t\t\t\tpinMode(CAP_MOTOR_NTC_PIN, GPIO_MODE_ANALOG);
\t\t\t#endif
\t\t#endif
\t\t#ifdef REMOTE_ADC
"""
    if phase2_gpio in text:
        text = text.replace(phase2_gpio, phase3_gpio, 1)
    elif clean_gpio in text:
        text = text.replace(clean_gpio, phase3_gpio, 1)
    else:
        raise RuntimeError("Could not identify GPIO ADC setup in setup.c")

    clean_adc = """\t\t#ifdef VBATT
\t\t\tTARGET_adc_regular_channel_config(0, PIN_TO_CHANNEL(VBATT), ADC_SAMPLETIME_13POINT5);
\t\t#endif
\t\t#ifdef CURRENT_DC
\t\t\tTARGET_adc_regular_channel_config(1, PIN_TO_CHANNEL(CURRENT_DC), ADC_SAMPLETIME_13POINT5);
\t\t#endif
\t\t#ifdef REMOTE_ADC
\t\t\tadc_regular_channel_config(2, PIN_TO_CHANNEL(PA2), ADC_SAMPLETIME_13POINT5);
\t\t\tadc_regular_channel_config(3, PIN_TO_CHANNEL(PA3), ADC_SAMPLETIME_13POINT5);
\t\t#endif
"""
    phase2_adc = """\t\t#ifdef BLDC_FOC /* GYROOR_G5_FOC_PHASE2 */
\t\t\t/* DMA order must exactly match the BLDC_FOC adc_buf_t. */
\t\t\tTARGET_adc_regular_channel_config(0, PIN_TO_CHANNEL(VBATT), ADC_SAMPLETIME_13POINT5);
\t\t\tTARGET_adc_regular_channel_config(1, PIN_TO_CHANNEL(PHASE_A), ADC_SAMPLETIME_13POINT5);
\t\t\tTARGET_adc_regular_channel_config(2, PIN_TO_CHANNEL(PHASE_B), ADC_SAMPLETIME_13POINT5);
\t\t#else
\t\t\t#ifdef VBATT
\t\t\t\tTARGET_adc_regular_channel_config(0, PIN_TO_CHANNEL(VBATT), ADC_SAMPLETIME_13POINT5);
\t\t\t#endif
\t\t\t#ifdef CURRENT_DC
\t\t\t\tTARGET_adc_regular_channel_config(1, PIN_TO_CHANNEL(CURRENT_DC), ADC_SAMPLETIME_13POINT5);
\t\t\t#endif
\t\t\t#ifdef REMOTE_ADC
\t\t\t\tadc_regular_channel_config(2, PIN_TO_CHANNEL(PA2), ADC_SAMPLETIME_13POINT5);
\t\t\t\tadc_regular_channel_config(3, PIN_TO_CHANNEL(PA3), ADC_SAMPLETIME_13POINT5);
\t\t\t#endif
\t\t#endif
"""
    phase3_adc = f"""\t\t#ifdef BLDC_FOC /* {MARKER} */
\t\t\t/* DMA order must exactly match the BLDC_FOC adc_buf_t. */
\t\t\tTARGET_adc_regular_channel_config(0, PIN_TO_CHANNEL(VBATT), ADC_SAMPLETIME_13POINT5);
\t\t\tTARGET_adc_regular_channel_config(1, PIN_TO_CHANNEL(PHASE_A), ADC_SAMPLETIME_13POINT5);
\t\t\tTARGET_adc_regular_channel_config(2, PIN_TO_CHANNEL(PHASE_B), ADC_SAMPLETIME_13POINT5);
\t\t\tTARGET_adc_regular_channel_config(3, PIN_TO_CHANNEL(CAP_MOTOR_NTC_PIN), ADC_SAMPLETIME_13POINT5);
\t\t#else
\t\t\t#ifdef VBATT
\t\t\t\tTARGET_adc_regular_channel_config(0, PIN_TO_CHANNEL(VBATT), ADC_SAMPLETIME_13POINT5);
\t\t\t#endif
\t\t\t#ifdef CURRENT_DC
\t\t\t\tTARGET_adc_regular_channel_config(1, PIN_TO_CHANNEL(CURRENT_DC), ADC_SAMPLETIME_13POINT5);
\t\t\t#endif
\t\t\t#ifdef REMOTE_ADC
\t\t\t\tadc_regular_channel_config(2, PIN_TO_CHANNEL(PA2), ADC_SAMPLETIME_13POINT5);
\t\t\t\tadc_regular_channel_config(3, PIN_TO_CHANNEL(PA3), ADC_SAMPLETIME_13POINT5);
\t\t\t#endif
\t\t#endif
"""
    if phase2_adc in text:
        text = text.replace(phase2_adc, phase3_adc, 1)
    else:
        idx = text.rfind(clean_adc)
        if idx < 0:
            raise RuntimeError("Could not identify ADC scan setup in setup.c")
        text = text[:idx] + phase3_adc + text[idx + len(clean_adc):]

    backup_and_write(root, rel, text)


def patch_keil_project(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Hoverboard.uvprojx"
    text = checked_read(root, rel, allow_drift)
    changed = False

    source_anchor = """            <File>
              <FileName>bldcSINE.c</FileName>
              <FileType>1</FileType>
              <FilePath>.\\Src\\bldcSINE.c</FilePath>
            </File>
"""
    source_insert = source_anchor + """            <File>
              <FileName>bldcFOC.c</FileName>
              <FileType>1</FileType>
              <FilePath>.\\Src\\bldcFOC.c</FilePath>
            </File>
            <File>
              <FileName>driveCapability.c</FileName>
              <FileType>1</FileType>
              <FilePath>.\\Src\\driveCapability.c</FilePath>
            </File>
            <File>
              <FileName>g5Monitor.c</FileName>
              <FileType>1</FileType>
              <FilePath>.\\Src\\g5Monitor.c</FilePath>
            </File>
            <File>
              <FileName>BLDC_controller.c</FileName>
              <FileType>1</FileType>
              <FilePath>.\\Src\\BLDC_controller.c</FilePath>
            </File>
            <File>
              <FileName>BLDC_controller_data.c</FileName>
              <FileType>1</FileType>
              <FilePath>.\\Src\\BLDC_controller_data.c</FilePath>
            </File>
"""
    if "<FileName>bldcFOC.c</FileName>" not in text:
        text = require_once(text, source_anchor, source_insert, "Keil FOC source files")
        changed = True

    header_anchor = """            <File>
              <FileName>bldcSINE.h</FileName>
              <FileType>5</FileType>
              <FilePath>.\\Inc\\bldcSINE.h</FilePath>
            </File>
"""
    header_insert = header_anchor + """            <File>
              <FileName>bldcFOC.h</FileName>
              <FileType>5</FileType>
              <FilePath>.\\Inc\\bldcFOC.h</FilePath>
            </File>
            <File>
              <FileName>driveCapability.h</FileName>
              <FileType>5</FileType>
              <FilePath>.\\Inc\\driveCapability.h</FilePath>
            </File>
            <File>
              <FileName>foc_config.h</FileName>
              <FileType>5</FileType>
              <FilePath>.\\Inc\\foc_config.h</FilePath>
            </File>
            <File>
              <FileName>g5Monitor.h</FileName>
              <FileType>5</FileType>
              <FilePath>.\\Inc\\g5Monitor.h</FilePath>
            </File>
            <File>
              <FileName>BLDC_controller.h</FileName>
              <FileType>5</FileType>
              <FilePath>.\\Inc\\BLDC_controller.h</FilePath>
            </File>
            <File>
              <FileName>rtwtypes.h</FileName>
              <FileType>5</FileType>
              <FilePath>.\\Inc\\rtwtypes.h</FilePath>
            </File>
"""
    if "<FileName>foc_config.h</FileName>" not in text:
        text = require_once(text, header_anchor, header_insert, "Keil FOC header files")
        changed = True

    if changed:
        text = text.replace("</Project>", f"  <!-- {MARKER} -->\n</Project>", 1)
        backup_and_write(root, rel, text)
    else:
        print(f"Keil FOC files already present: {rel}")


def install_overlay(bundle: Path, root: Path) -> None:
    overlay = bundle / "overlay"
    for src in overlay.rglob("*"):
        if not src.is_file():
            continue
        rel = src.relative_to(overlay)
        dst = root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists() and dst.read_bytes() != src.read_bytes():
            backup = dst.with_suffix(dst.suffix + ".phase3.bak")
            if not backup.exists():
                shutil.copy2(dst, backup)
        shutil.copy2(src, dst)
        print(f"installed {rel}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("repo_root", help="Path to RoboDurden Hoverboard-Firmware-Hack-Gen2.x-GD32 checkout")
    ap.add_argument("--allow-upstream-drift", action="store_true")
    ap.add_argument("--skip-vendor", action="store_true", help="do not download pinned EFeru core")
    ns = ap.parse_args()

    root = Path(ns.repo_root).resolve()
    bundle = Path(__file__).resolve().parent
    if not (root / "HoverBoardGigaDevice" / "Inc" / "defines.h").is_file():
        raise SystemExit(f"Not a Gen2.x-GD32 checkout: {root}")

    try:
        patch_config(root, ns.allow_upstream_drift)
        patch_layout(root, ns.allow_upstream_drift)
        patch_bldc_h(root, ns.allow_upstream_drift)
        patch_defines_h(root, ns.allow_upstream_drift)
        patch_setup(root, ns.allow_upstream_drift)
        patch_keil_project(root, ns.allow_upstream_drift)
        install_overlay(bundle, root)
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    if not ns.skip_vendor:
        vendor = bundle / "vendor_eferu_foc.py"
        rc = subprocess.call([sys.executable, str(vendor), str(root)])
        if rc:
            return rc

    print("\nPhase-3 source integration applied.")
    print("IMPORTANT: FOC_SAFE_BRINGUP=1 still forces all phase outputs to zero.")
    print("PA6 is tentatively treated as the motor NTC using resistance only; no Celsius curve is assumed.")
    print("CAP_MOTOR_NTC_REQUIRE_VALID=0 until the extra motor wire is physically confirmed.")
    print("Current-heating and measured-NTC limits are both global and every drive mode passes through them.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
