#ifndef G5_MONITOR_H
#define G5_MONITOR_H

#include <stdint.h>

/* Keep this deliberately slow enough that SWD Live Expressions do not perturb the FOC loop. */
#ifndef G5_MONITOR_UPDATE_HZ
#define G5_MONITOR_UPDATE_HZ 100U
#endif
#if G5_MONITOR_UPDATE_HZ == 0
#error "G5_MONITOR_UPDATE_HZ must be greater than zero"
#endif

/* Layout 2.1.20 defines ADC_BATTERY_VOLT = 0.02507 V/count. Avoid floating point here. */
#ifndef G5_MONITOR_BATTERY_UV_PER_COUNT
#define G5_MONITOR_BATTERY_UV_PER_COUNT 25070UL
#endif

typedef struct {
    uint16_t battery_raw;
    uint16_t phase_a_raw;
    uint16_t phase_b_raw;
    uint16_t motor_ntc_raw;
    uint32_t battery_millivolt;
} G5_MonitorAdc;

typedef struct {
    int16_t phase_a_model;
    int16_t phase_b_model;
    int16_t phase_c_model_reconstructed;
    int16_t phase_a_centiamp;
    int16_t phase_b_centiamp;
    int16_t phase_c_centiamp_reconstructed;
    uint16_t rms_centiamp;
    int16_t offset_a;
    int16_t offset_b;
    uint8_t offsets_ready;
    uint8_t sensor_valid;
} G5_MonitorCurrent;

typedef struct {
    uint16_t raw;
    uint16_t filtered_raw;
    uint32_t resistance_ohm;
    uint16_t limit_centiamp;
    uint8_t valid;
    uint8_t reserved;
} G5_MonitorMotorNtc;

typedef struct {
    uint16_t thermal_load_permille;
    uint16_t absolute_limit_centiamp;
    uint16_t thermal_limit_centiamp;
    uint16_t battery_limit_centiamp;
    uint16_t temperature_limit_centiamp;
    uint16_t motor_ntc_limit_centiamp;
    uint16_t global_limit_centiamp;
    uint16_t profile_limit_centiamp;
    uint16_t effective_limit_centiamp;
    uint8_t profile;
    uint8_t fault_flags;
} G5_MonitorCapability;

typedef struct {
    uint8_t hall_a;
    uint8_t hall_b;
    uint8_t hall_c;
    uint8_t hall_state;
    int16_t speed_rpm;
    int16_t speed_rpm_x16;
} G5_MonitorMotor;

typedef struct {
    int16_t target;
    int16_t iq_raw;
    int16_t id_raw;
    int16_t iq_centiamp;
    int16_t id_centiamp;
    int16_t pwm_a;
    int16_t pwm_b;
    int16_t pwm_c;
    uint16_t dynamic_i_max_q4;
    uint8_t error;
    uint8_t bridge_enabled;
    uint8_t safe_bringup;
    uint8_t reserved;
} G5_MonitorFoc;

typedef struct {
    uint32_t magic;          /* 0x47354D31 = ASCII-ish "G5M1" */
    uint32_t update_counter;
    G5_MonitorAdc adc;
    G5_MonitorCurrent current;
    G5_MonitorMotorNtc motor_ntc;
    G5_MonitorCapability capability;
    G5_MonitorMotor motor;
    G5_MonitorFoc foc;
} G5_MonitorData;

extern volatile G5_MonitorData g5mon;

/* Called from a low-rate divider inside the FOC adapter. */
void G5Monitor_Update(void);

#endif /* G5_MONITOR_H */
