#ifndef DRIVE_CAPABILITY_H
#define DRIVE_CAPABILITY_H

#include <stdint.h>

typedef enum {
    DRIVE_PROFILE_NORMAL = 0,
    DRIVE_PROFILE_SNOW   = 1,
    DRIVE_PROFILE_BOOST  = 2
} DriveProfile;

enum {
    CAP_FAULT_CURRENT_NOT_READY   = 1u << 0,
    CAP_FAULT_CURRENT_ADC_RAIL    = 1u << 1,
    CAP_FAULT_THERMAL_HARD        = 1u << 2,
    CAP_FAULT_BATTERY_LOW         = 1u << 3,
    CAP_FAULT_TEMPERATURE_HIGH    = 1u << 4,
    CAP_FAULT_MOTOR_NTC_INVALID   = 1u << 5,
    CAP_FAULT_MOTOR_NTC_HOT       = 1u << 6
};

void DriveCapability_Init(void);
void DriveCapability_SetProfile(DriveProfile profile);
DriveProfile DriveCapability_GetProfile(void);

/* Optional second temperature input for a future board/heatsink sensor. */
void DriveCapability_SetTemperatureDeciC(int16_t temperature_deci_c, uint8_t valid);

/* Called from the FOC current-sampling path at the PWM/control rate. */
void DriveCapability_Update(int16_t phase_a_model,
                            int16_t phase_b_model,
                            uint16_t phase_a_raw,
                            uint16_t phase_b_raw,
                            uint8_t current_offsets_ready,
                            uint16_t battery_raw,
                            uint16_t motor_ntc_raw);

/* EFeru i_max format: controller-current counts with four fractional bits. */
uint16_t DriveCapability_GetEffectiveCurrentModelQ4(void);

/* CubeMonitor/debugger-visible state. Current units are 0.01 A. */
extern volatile uint8_t  cap_profile;
extern volatile uint8_t  cap_fault_flags;
extern volatile uint8_t  cap_current_sensor_valid;
extern volatile uint8_t  cap_temperature_valid;
extern volatile int16_t  cap_temperature_deci_c;
extern volatile uint16_t cap_current_rms_centiamp;
extern volatile uint16_t cap_absolute_limit_centiamp;
extern volatile uint16_t cap_thermal_limit_centiamp;
extern volatile uint16_t cap_battery_limit_centiamp;
extern volatile uint16_t cap_temperature_limit_centiamp;
extern volatile uint16_t cap_motor_ntc_limit_centiamp;
extern volatile uint16_t cap_global_limit_centiamp;
extern volatile uint16_t cap_profile_limit_centiamp;
extern volatile uint16_t cap_effective_limit_centiamp;
extern volatile uint16_t cap_thermal_load_permille;

/* Tentative PA6 motor-NTC diagnostics. */
extern volatile uint16_t cap_motor_ntc_raw;
extern volatile uint16_t cap_motor_ntc_filtered_raw;
extern volatile uint32_t cap_motor_ntc_ohm;
extern volatile uint8_t  cap_motor_ntc_valid;

#endif /* DRIVE_CAPABILITY_H */
