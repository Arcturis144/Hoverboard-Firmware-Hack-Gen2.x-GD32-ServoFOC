/* GNU Arm startup for GD32F130C8 / GD32F1x0 Cortex-M3. */
.syntax unified
.cpu cortex-m3
.fpu softvfp
.thumb

.global g_pfnVectors
.global Reset_Handler
.global Default_Handler

.section .text.Reset_Handler,"ax",%progbits
.weak Reset_Handler
.type Reset_Handler, %function
Reset_Handler:
    /* Copy .data from flash to SRAM. */
    ldr r0, =_sdata
    ldr r1, =_edata
    ldr r2, =_sidata
1:
    cmp r0, r1
    bcc 2f
    b 3f
2:
    ldr r3, [r2], #4
    str r3, [r0], #4
    b 1b

3:
    /* Zero .bss. */
    ldr r0, =_sbss
    ldr r1, =_ebss
    movs r2, #0
4:
    cmp r0, r1
    bcc 5f
    b 6f
5:
    str r2, [r0], #4
    b 4b

6:
    bl SystemInit
    bl main
7:
    b 7b
.size Reset_Handler, .-Reset_Handler

.section .text.Default_Handler,"ax",%progbits
.type Default_Handler, %function
Default_Handler:
8:
    b 8b
.size Default_Handler, .-Default_Handler

.section .isr_vector,"a",%progbits
.align 2
.type g_pfnVectors, %object
g_pfnVectors:
    .word _estack
    .word Reset_Handler
    .word NMI_Handler
    .word HardFault_Handler
    .word MemManage_Handler
    .word BusFault_Handler
    .word UsageFault_Handler
    .word 0
    .word 0
    .word 0
    .word 0
    .word SVC_Handler
    .word DebugMon_Handler
    .word 0
    .word PendSV_Handler
    .word SysTick_Handler

    .word WWDGT_IRQHandler
    .word LVD_IRQHandler
    .word RTC_IRQHandler
    .word FMC_IRQHandler
    .word RCU_IRQHandler
    .word EXTI0_1_IRQHandler
    .word EXTI2_3_IRQHandler
    .word EXTI4_15_IRQHandler
    .word TSI_IRQHandler
    .word DMA_Channel0_IRQHandler
    .word DMA_Channel1_2_IRQHandler
    .word DMA_Channel3_4_IRQHandler
    .word ADC_CMP_IRQHandler
    .word TIMER0_BRK_UP_TRG_COM_IRQHandler
    .word TIMER0_Channel_IRQHandler
    .word TIMER1_IRQHandler
    .word TIMER2_IRQHandler
    .word TIMER5_DAC_IRQHandler
    .word 0
    .word TIMER13_IRQHandler
    .word TIMER14_IRQHandler
    .word TIMER15_IRQHandler
    .word TIMER16_IRQHandler
    .word I2C0_EV_IRQHandler
    .word I2C1_EV_IRQHandler
    .word SPI0_IRQHandler
    .word SPI1_IRQHandler
    .word USART0_IRQHandler
    .word USART1_IRQHandler
    .word 0
    .word CEC_IRQHandler
    .word 0
    .word I2C0_ER_IRQHandler
    .word 0
    .word I2C1_ER_IRQHandler
    .word I2C2_EV_IRQHandler
    .word I2C2_ER_IRQHandler
    .word USBD_LP_IRQHandler
    .word USBD_HP_IRQHandler
    .word 0
    .word 0
    .word 0
    .word USBDWakeUp_IRQHandler
    .word CAN0_TX_IRQHandler
    .word CAN0_RX0_IRQHandler
    .word CAN0_RX1_IRQHandler
    .word CAN0_SCE_IRQHandler
    .word SLCD_IRQHandler
    .word DMA_Channel5_6_IRQHandler
    .word 0
    .word 0
    .word SPI2_IRQHandler
    .rept 18
    .word 0
    .endr
    .word CAN1_TX_IRQHandler
    .word CAN1_RX0_IRQHandler
    .word CAN1_RX1_IRQHandler
    .word CAN1_SCE_IRQHandler
.size g_pfnVectors, .-g_pfnVectors

.macro WEAK_ALIAS name
    .weak \name
    .thumb_set \name, Default_Handler
.endm

WEAK_ALIAS NMI_Handler
WEAK_ALIAS HardFault_Handler
WEAK_ALIAS MemManage_Handler
WEAK_ALIAS BusFault_Handler
WEAK_ALIAS UsageFault_Handler
WEAK_ALIAS SVC_Handler
WEAK_ALIAS DebugMon_Handler
WEAK_ALIAS PendSV_Handler
WEAK_ALIAS SysTick_Handler
WEAK_ALIAS WWDGT_IRQHandler
WEAK_ALIAS LVD_IRQHandler
WEAK_ALIAS RTC_IRQHandler
WEAK_ALIAS FMC_IRQHandler
WEAK_ALIAS RCU_IRQHandler
WEAK_ALIAS EXTI0_1_IRQHandler
WEAK_ALIAS EXTI2_3_IRQHandler
WEAK_ALIAS EXTI4_15_IRQHandler
WEAK_ALIAS TSI_IRQHandler
WEAK_ALIAS DMA_Channel0_IRQHandler
WEAK_ALIAS DMA_Channel1_2_IRQHandler
WEAK_ALIAS DMA_Channel3_4_IRQHandler
WEAK_ALIAS ADC_CMP_IRQHandler
WEAK_ALIAS TIMER0_BRK_UP_TRG_COM_IRQHandler
WEAK_ALIAS TIMER0_Channel_IRQHandler
WEAK_ALIAS TIMER1_IRQHandler
WEAK_ALIAS TIMER2_IRQHandler
WEAK_ALIAS TIMER5_DAC_IRQHandler
WEAK_ALIAS TIMER13_IRQHandler
WEAK_ALIAS TIMER14_IRQHandler
WEAK_ALIAS TIMER15_IRQHandler
WEAK_ALIAS TIMER16_IRQHandler
WEAK_ALIAS I2C0_EV_IRQHandler
WEAK_ALIAS I2C1_EV_IRQHandler
WEAK_ALIAS SPI0_IRQHandler
WEAK_ALIAS SPI1_IRQHandler
WEAK_ALIAS USART0_IRQHandler
WEAK_ALIAS USART1_IRQHandler
WEAK_ALIAS CEC_IRQHandler
WEAK_ALIAS I2C0_ER_IRQHandler
WEAK_ALIAS I2C1_ER_IRQHandler
WEAK_ALIAS I2C2_EV_IRQHandler
WEAK_ALIAS I2C2_ER_IRQHandler
WEAK_ALIAS USBD_LP_IRQHandler
WEAK_ALIAS USBD_HP_IRQHandler
WEAK_ALIAS USBDWakeUp_IRQHandler
WEAK_ALIAS CAN0_TX_IRQHandler
WEAK_ALIAS CAN0_RX0_IRQHandler
WEAK_ALIAS CAN0_RX1_IRQHandler
WEAK_ALIAS CAN0_SCE_IRQHandler
WEAK_ALIAS SLCD_IRQHandler
WEAK_ALIAS DMA_Channel5_6_IRQHandler
WEAK_ALIAS SPI2_IRQHandler
WEAK_ALIAS CAN1_TX_IRQHandler
WEAK_ALIAS CAN1_RX0_IRQHandler
WEAK_ALIAS CAN1_RX1_IRQHandler
WEAK_ALIAS CAN1_SCE_IRQHandler
