param(
    [string]$ProjectRoot = (Get-Location).Path,
    [string]$CubeIdeRoot = ""
)
$ErrorActionPreference = "Stop"

function Get-CubeIdeRoots([string]$Explicit) {
    $roots = @()
    if ($Explicit) { $roots += $Explicit }
    if (Test-Path "C:\ST") {
        $roots += (Get-ChildItem "C:\ST" -Directory -Filter "STM32CubeIDE_*" -ErrorAction SilentlyContinue | ForEach-Object { Join-Path $_.FullName "STM32CubeIDE" })
    }
    $p = "$env:ProgramFiles\STMicroelectronics\STM32Cube\STM32CubeIDE"
    if (Test-Path $p) { $roots += $p }
    return $roots | Select-Object -Unique
}

function Find-Tool([string[]]$Roots, [string]$Pattern) {
    foreach ($root in $Roots) {
        $hit = Get-Item (Join-Path $root $Pattern) -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($hit) { return $hit.FullName }
    }
    return $null
}

$roots = Get-CubeIdeRoots $CubeIdeRoot
$gcc = Find-Tool $roots "plugins\com.st.stm32cube.ide.mcu.externaltools.gnu-tools-for-stm32.*\tools\bin\arm-none-eabi-gcc.exe"
$make = Find-Tool $roots "plugins\com.st.stm32cube.ide.mcu.externaltools.make.win32_*\tools\bin\make.exe"
if (-not $gcc) { throw "Could not find CubeIDE arm-none-eabi-gcc. Pass -CubeIdeRoot 'C:\path\to\STM32CubeIDE'." }
if (-not $make) { throw "Could not find CubeIDE make.exe. Pass -CubeIdeRoot 'C:\path\to\STM32CubeIDE'." }

$gccPath = Split-Path -Parent $gcc
Write-Host "CubeIDE GNU Arm: $gccPath"
Write-Host "CubeIDE make:    $make"
Push-Location $ProjectRoot
try {
    & $make "GCC_PATH=$gccPath" all
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
} finally {
    Pop-Location
}
