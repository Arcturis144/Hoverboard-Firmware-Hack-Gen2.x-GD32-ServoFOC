param(
    [string]$ProjectRoot = (Get-Location).Path,
    [string]$CubeIdeRoot = "",
    [int]$SpeedKHz = 400
)
$ErrorActionPreference = "Stop"

function Get-CubeIdeRoots([string]$Explicit) {
    $roots = @()
    if ($Explicit) { $roots += $Explicit }
    if (Test-Path "C:\ST") {
        $roots += (Get-ChildItem "C:\ST" -Directory -Filter "STM32CubeIDE_*" -ErrorAction SilentlyContinue | ForEach-Object { Join-Path $_.FullName "STM32CubeIDE" })
    }
    $p = "$env:ProgramFiles\STMicroelectronics\STM32Cube\STM32CubeIDE"
    if (Test-Path $p) { $roots += $p }
    return $roots | Select-Object -Unique
}
function Find-Tool([string[]]$Roots, [string]$Pattern) {
    foreach ($root in $Roots) {
        $hit = Get-Item (Join-Path $root $Pattern) -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($hit) { return $hit.FullName }
    }
    return $null
}

$roots = Get-CubeIdeRoots $CubeIdeRoot
$gdb = Find-Tool $roots "plugins\com.st.stm32cube.ide.mcu.externaltools.gnu-tools-for-stm32.*\tools\bin\arm-none-eabi-gdb.exe"
$openocd = Find-Tool $roots "plugins\com.st.stm32cube.ide.mcu.externaltools.openocd.win32_*\tools\bin\openocd.exe"
if (-not $gdb) { throw "Could not find CubeIDE arm-none-eabi-gdb." }
if (-not $openocd) { throw "Could not find CubeIDE OpenOCD." }
$toolsDir = Split-Path -Parent $openocd
$scripts = Join-Path (Split-Path -Parent $toolsDir) "share\openocd\scripts"
if (-not (Test-Path $scripts)) {
    $scripts = Get-ChildItem (Split-Path -Parent (Split-Path -Parent $openocd)) -Directory -Recurse -Filter scripts -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
}
if (-not $scripts) { throw "Could not locate CubeIDE OpenOCD scripts directory." }

$elf = Join-Path $ProjectRoot "build\Gyroor_G5_GD32F130_FOC.elf"
$cfg = Join-Path $ProjectRoot "CubeIDE\OpenOCD\gyroor_gd32f130_stlink.cfg"
$gdbScript = Join-Path $ProjectRoot "CubeIDE\OpenOCD\program.gdb"
if (-not (Test-Path $elf)) { throw "Build the firmware first; missing $elf" }

$argString = "-s `"$scripts`" -f `"$cfg`" -c `"adapter speed $SpeedKHz`""
$proc = Start-Process -FilePath $openocd -ArgumentList $argString -PassThru -NoNewWindow
try {
    Start-Sleep -Milliseconds 1500
    if ($proc.HasExited) { throw "OpenOCD exited before GDB connected. Check ST-Link wiring/power and lower SpeedKHz to 100." }
    & $gdb -q -batch -x $gdbScript $elf
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
} finally {
    if (-not $proc.HasExited) { Stop-Process -Id $proc.Id }
}
