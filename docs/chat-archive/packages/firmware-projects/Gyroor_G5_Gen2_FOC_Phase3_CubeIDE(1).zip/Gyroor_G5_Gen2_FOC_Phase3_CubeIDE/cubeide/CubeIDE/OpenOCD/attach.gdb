set pagination off
set confirm off
target extended-remote localhost:3333
monitor halt
printf "Connected without hardware reset. Use 'continue' when ready.\n"
