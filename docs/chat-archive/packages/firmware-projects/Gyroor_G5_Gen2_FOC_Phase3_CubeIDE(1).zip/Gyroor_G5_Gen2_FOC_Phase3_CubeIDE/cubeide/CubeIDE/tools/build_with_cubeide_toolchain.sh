#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="${1:-$(pwd)}"
if command -v arm-none-eabi-gcc >/dev/null 2>&1; then
  exec make -C "$PROJECT_ROOT" all
fi
printf '%s\n' "arm-none-eabi-gcc is not on PATH." >&2
printf '%s\n' "In CubeIDE, use its GNU Arm toolchain path as: make GCC_PATH=/path/to/tools/bin" >&2
exit 2
