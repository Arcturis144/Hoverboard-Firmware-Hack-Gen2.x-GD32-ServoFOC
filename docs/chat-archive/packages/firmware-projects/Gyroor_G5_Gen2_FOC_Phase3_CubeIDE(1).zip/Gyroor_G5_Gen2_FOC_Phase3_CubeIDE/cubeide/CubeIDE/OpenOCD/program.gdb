set pagination off
set confirm off
target extended-remote localhost:3333
monitor halt
load
compare-sections
monitor reset halt
monitor resume
detach
quit
