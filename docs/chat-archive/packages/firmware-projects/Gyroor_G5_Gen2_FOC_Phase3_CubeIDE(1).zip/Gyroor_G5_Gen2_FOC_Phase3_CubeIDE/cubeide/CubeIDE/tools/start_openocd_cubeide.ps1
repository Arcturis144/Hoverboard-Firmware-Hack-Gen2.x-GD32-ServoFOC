param(
    [string]$ProjectRoot = (Get-Location).Path,
    [string]$CubeIdeRoot = "",
    [int]$SpeedKHz = 400
)
$ErrorActionPreference = "Stop"

function Get-CubeIdeRoots([string]$Explicit) {
    $roots = @()
    if ($Explicit) { $roots += $Explicit }
    if (Test-Path "C:\ST") {
        $roots += (Get-ChildItem "C:\ST" -Directory -Filter "STM32CubeIDE_*" -ErrorAction SilentlyContinue | ForEach-Object { Join-Path $_.FullName "STM32CubeIDE" })
    }
    $p = "$env:ProgramFiles\STMicroelectronics\STM32Cube\STM32CubeIDE"
    if (Test-Path $p) { $roots += $p }
    return $roots | Select-Object -Unique
}

function Find-Tool([string[]]$Roots, [string]$Pattern) {
    foreach ($root in $Roots) {
        $hit = Get-Item (Join-Path $root $Pattern) -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($hit) { return $hit.FullName }
    }
    return $null
}

$roots = Get-CubeIdeRoots $CubeIdeRoot
$openocd = Find-Tool $roots "plugins\com.st.stm32cube.ide.mcu.externaltools.openocd.win32_*\tools\bin\openocd.exe"
if (-not $openocd) { throw "Could not find CubeIDE OpenOCD. Pass -CubeIdeRoot 'C:\path\to\STM32CubeIDE'." }
$toolsDir = Split-Path -Parent $openocd
$scripts = Join-Path (Split-Path -Parent $toolsDir) "share\openocd\scripts"
if (-not (Test-Path $scripts)) {
    $scripts = Get-ChildItem (Split-Path -Parent (Split-Path -Parent $openocd)) -Directory -Recurse -Filter scripts -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
}
if (-not $scripts) { throw "Could not locate CubeIDE OpenOCD scripts directory." }

$cfg = Join-Path $ProjectRoot "CubeIDE\OpenOCD\gyroor_gd32f130_stlink.cfg"
if (-not (Test-Path $cfg)) { throw "Missing $cfg" }

Write-Host "OpenOCD: $openocd"
Write-Host "Scripts: $scripts"
Write-Host "SWD:     $SpeedKHz kHz"
& $openocd -s $scripts -f $cfg -c "adapter speed $SpeedKHz"
