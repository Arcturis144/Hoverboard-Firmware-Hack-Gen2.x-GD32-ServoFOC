#!/usr/bin/env python3
"""Vendor the exact GD32F1x0 V3.2.0 headers used by the Gen2 GD32F130 pack sources.

The Gen2 repository carries the peripheral .c files from the GigaDevice pack but
Keil normally supplies the matching headers from the installed DFP. GNU Arm/CubeIDE
needs those headers in the source tree, so this script vendors them from a pinned
public mirror of the GigaDevice V3.2.0 firmware library.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from urllib.request import Request, urlopen

REPO = "CommunityGD32Cores/GD32Firmware"
COMMIT = "4005bb036172cf671976df6160b828a3ee6e738e"  # imports GD32F1x0_Firmware_Library_V3.2.0
SOURCE_DIRS = {
    "CMSIS": "GD32F1x0/CMSIS/GD/GD32F1x0/Include",
    "StdPeriph": "GD32F1x0/GD32F1x0_standard_peripheral/Include",
}


def request_bytes(url: str) -> bytes:
    req = Request(url, headers={"User-Agent": "Gyroor-G5-CubeIDE-vendor/1"})
    with urlopen(req, timeout=30) as r:
        return r.read()


def git_blob_sha1(data: bytes) -> str:
    return hashlib.sha1(f"blob {len(data)}\0".encode("ascii") + data).hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("repo_root", help="Path to the Gen2.x-GD32 checkout")
    ns = ap.parse_args()
    root = Path(ns.repo_root).resolve()
    if not (root / "HoverBoardGigaDevice").is_dir():
        raise SystemExit(f"Not a Gen2.x-GD32 checkout: {root}")

    out_root = root / "HoverBoardGigaDevice" / "GCC" / "GD32F1x0_Headers"
    total = 0

    for group, remote_dir in SOURCE_DIRS.items():
        api = f"https://api.github.com/repos/{REPO}/contents/{remote_dir}?ref={COMMIT}"
        entries = json.loads(request_bytes(api).decode("utf-8"))
        dest = out_root / group
        dest.mkdir(parents=True, exist_ok=True)
        for item in entries:
            if item.get("type") != "file" or not item.get("name", "").endswith(".h"):
                continue
            data = request_bytes(item["download_url"])
            actual = git_blob_sha1(data)
            if actual != item["sha"]:
                raise RuntimeError(f"Git blob verification failed for {item['name']}: {actual} != {item['sha']}")
            path = dest / item["name"]
            path.write_bytes(data)
            print(f"vendored {path.relative_to(root)}  {item['sha']}")
            total += 1

    marker = out_root / "VENDORED_FROM.txt"
    marker.write_text(
        f"Repository: https://github.com/{REPO}\n"
        f"Commit: {COMMIT}\n"
        "Library: GD32F1x0 Firmware Library V3.2.0\n"
        f"Headers: {total}\n",
        encoding="utf-8",
    )
    print(f"Vendored {total} GD32 V3.2.0 headers.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
