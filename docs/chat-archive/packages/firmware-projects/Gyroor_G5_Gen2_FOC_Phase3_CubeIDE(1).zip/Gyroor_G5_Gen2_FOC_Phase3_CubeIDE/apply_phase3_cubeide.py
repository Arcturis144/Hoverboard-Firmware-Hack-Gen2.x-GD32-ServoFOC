#!/usr/bin/env python3
"""Apply Phase-3 FOC + PA6 NTC + CubeIDE/GNU-Arm integration to a Gen2 checkout."""
from __future__ import annotations

import argparse
from pathlib import Path
import shutil
import subprocess
import sys


def backup_then_copy(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() and dst.read_bytes() != src.read_bytes():
        backup = dst.with_name(dst.name + ".phase3cubeide.bak")
        if not backup.exists():
            shutil.copy2(dst, backup)
            print(f"backup {backup}")
    shutil.copy2(src, dst)
    print(f"installed {dst}")


def install_cubeide(bundle: Path, root: Path) -> None:
    tree = bundle / "cubeide"
    for src in tree.rglob("*"):
        if not src.is_file():
            continue
        rel = src.relative_to(tree)
        backup_then_copy(src, root / rel)


def patch_existing_keil_monitor(root: Path) -> None:
    """Keep the old Keil project coherent if Phase 3 was already applied earlier."""
    p = root / "HoverBoardGigaDevice" / "Hoverboard.uvprojx"
    if not p.is_file():
        return
    text = p.read_text(encoding="utf-8", errors="strict")
    changed = False

    if "<FileName>g5Monitor.c</FileName>" not in text and "<FileName>driveCapability.c</FileName>" in text:
        anchor = """            <File>\n              <FileName>driveCapability.c</FileName>\n              <FileType>1</FileType>\n              <FilePath>.\\Src\\driveCapability.c</FilePath>\n            </File>\n"""
        insert = anchor + """            <File>\n              <FileName>g5Monitor.c</FileName>\n              <FileType>1</FileType>\n              <FilePath>.\\Src\\g5Monitor.c</FilePath>\n            </File>\n"""
        if anchor in text:
            text = text.replace(anchor, insert, 1)
            changed = True

    if "<FileName>g5Monitor.h</FileName>" not in text and "<FileName>foc_config.h</FileName>" in text:
        anchor = """            <File>\n              <FileName>foc_config.h</FileName>\n              <FileType>5</FileType>\n              <FilePath>.\\Inc\\foc_config.h</FilePath>\n            </File>\n"""
        insert = anchor + """            <File>\n              <FileName>g5Monitor.h</FileName>\n              <FileType>5</FileType>\n              <FilePath>.\\Inc\\g5Monitor.h</FilePath>\n            </File>\n"""
        if anchor in text:
            text = text.replace(anchor, insert, 1)
            changed = True

    if changed:
        backup = p.with_suffix(p.suffix + ".phase3cubeide.bak")
        if not backup.exists():
            shutil.copy2(p, backup)
        p.write_text(text, encoding="utf-8", newline="")
        print("updated legacy Keil project with g5Monitor files")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("repo_root", help="Path to RoboDurden Hoverboard-Firmware-Hack-Gen2.x-GD32 checkout")
    ap.add_argument("--allow-upstream-drift", action="store_true")
    ap.add_argument("--skip-eferu-vendor", action="store_true", help="do not download the pinned EFeru generated FOC core")
    ap.add_argument("--skip-gd32-headers", action="store_true", help="do not download the pinned GD32F1x0 V3.2.0 headers")
    ns = ap.parse_args()

    root = Path(ns.repo_root).resolve()
    bundle = Path(__file__).resolve().parent
    if not (root / "HoverBoardGigaDevice" / "Inc" / "defines.h").is_file():
        print(f"ERROR: not a Gen2.x-GD32 checkout: {root}", file=sys.stderr)
        return 2

    phase3_cmd = [sys.executable, str(bundle / "apply_phase3.py"), str(root)]
    if ns.allow_upstream_drift:
        phase3_cmd.append("--allow-upstream-drift")
    if ns.skip_eferu_vendor:
        phase3_cmd.append("--skip-vendor")

    print("=== Applying Phase 3 firmware integration ===")
    rc = subprocess.call(phase3_cmd)
    if rc:
        return rc

    patch_existing_keil_monitor(root)

    if not ns.skip_gd32_headers:
        print("=== Vendoring GD32F1x0 V3.2.0 headers for GNU Arm ===")
        rc = subprocess.call([sys.executable, str(bundle / "vendor_gd32_headers.py"), str(root)])
        if rc:
            return rc

    print("=== Installing CubeIDE / GNU Arm project files ===")
    install_cubeide(bundle, root)

    print("\nCubeIDE integration complete.")
    print(f"Project root: {root}")
    print("Import the root into CubeIDE, build target 'all', then add 'g5mon' to Live Expressions.")
    print("FOC_SAFE_BRINGUP remains enabled; motor output is forced to zero.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
