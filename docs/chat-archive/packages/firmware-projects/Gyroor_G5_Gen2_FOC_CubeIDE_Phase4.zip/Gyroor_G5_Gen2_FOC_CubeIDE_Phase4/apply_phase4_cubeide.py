#!/usr/bin/env python3
"""Apply Gyroor G5 Phase-4 CubeIDE integration.

This layers a CubeIDE/GNU-Arm/OpenOCD development workflow and the `g5mon`
Live-Expressions snapshot on top of the Phase-3 Gen2.1.20 + EFeru FOC port.
It accepts either a clean supported RoboDurden checkout or one already patched
through Phase 1/2/3.
"""

from __future__ import annotations
import argparse
import shutil
import subprocess
import sys
from pathlib import Path

MARKER = "GYROOR_G5_FOC_PHASE4_CUBEIDE"


def phase3_ready(root: Path) -> bool:
    try:
        defines = (root / "HoverBoardGigaDevice/Inc/defines.h").read_text(encoding="utf-8")
        setup = (root / "HoverBoardGigaDevice/Src/setup.c").read_text(encoding="utf-8")
        foc = (root / "HoverBoardGigaDevice/Inc/foc_config.h").read_text(encoding="utf-8")
    except FileNotFoundError:
        return False
    return (
        "uint16_t motor_ntc" in defines
        and "CAP_MOTOR_NTC_PIN" in setup
        and "CAP_USE_MOTOR_NTC" in foc
        and (root / "HoverBoardGigaDevice/Src/bldcFOC.c").is_file()
        and (root / "HoverBoardGigaDevice/Src/driveCapability.c").is_file()
    )


def install_phase4_overlay(bundle: Path, root: Path) -> None:
    overlay = bundle / "overlay"
    for src in overlay.rglob("*"):
        if not src.is_file():
            continue
        rel = src.relative_to(overlay)
        dst = root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists() and dst.read_bytes() != src.read_bytes():
            backup = dst.with_suffix(dst.suffix + ".phase4.bak")
            if not backup.exists():
                shutil.copy2(dst, backup)
        shutil.copy2(src, dst)
        print(f"installed {rel}")


def patch_makefile(root: Path) -> None:
    path = root / "HoverBoardGigaDevice/Makefile"
    if not path.is_file():
        raise RuntimeError(f"Missing upstream GNU Makefile: {path}")
    text = path.read_text(encoding="utf-8")
    if MARKER in text:
        print("CubeIDE make include already present: HoverBoardGigaDevice/Makefile")
        return
    if "PREFIX = arm-none-eabi-" not in text or "LDSCRIPT = lib/spl/gd32f1x0/gd32f1x0.ld" not in text:
        raise RuntimeError(
            "The upstream Makefile no longer matches the expected GNU-Arm/GD32F130 layout; "
            "review it before applying the CubeIDE include."
        )
    backup = path.with_suffix(path.suffix + ".phase4.bak")
    if not backup.exists():
        shutil.copy2(path, backup)
    text = text.rstrip() + f"\n\n# {MARKER}: IDE/build/program/debug helpers.\n-include CubeIDE/cubeide.mk\n"
    path.write_text(text, encoding="utf-8", newline="")
    print("patched HoverBoardGigaDevice/Makefile")


def patch_keil_monitor_files(root: Path) -> None:
    """Keep the legacy Keil project internally consistent even though CubeIDE is primary."""
    path = root / "HoverBoardGigaDevice/Hoverboard.uvprojx"
    if not path.is_file():
        return
    text = path.read_text(encoding="utf-8")
    changed = False

    if "<FileName>g5Monitor.c</FileName>" not in text:
        anchor = """            <File>\n              <FileName>driveCapability.c</FileName>\n              <FileType>1</FileType>\n              <FilePath>.\\Src\\driveCapability.c</FilePath>\n            </File>\n"""
        insert = anchor + """            <File>\n              <FileName>g5Monitor.c</FileName>\n              <FileType>1</FileType>\n              <FilePath>.\\Src\\g5Monitor.c</FilePath>\n            </File>\n"""
        if anchor in text:
            text = text.replace(anchor, insert, 1)
            changed = True

    if "<FileName>g5Monitor.h</FileName>" not in text:
        anchor = """            <File>\n              <FileName>driveCapability.h</FileName>\n              <FileType>5</FileType>\n              <FilePath>.\\Inc\\driveCapability.h</FilePath>\n            </File>\n"""
        insert = anchor + """            <File>\n              <FileName>g5Monitor.h</FileName>\n              <FileType>5</FileType>\n              <FilePath>.\\Inc\\g5Monitor.h</FilePath>\n            </File>\n"""
        if anchor in text:
            text = text.replace(anchor, insert, 1)
            changed = True

    if changed:
        backup = path.with_suffix(path.suffix + ".phase4.bak")
        if not backup.exists():
            shutil.copy2(path, backup)
        path.write_text(text, encoding="utf-8", newline="")
        print("patched HoverBoardGigaDevice/Hoverboard.uvprojx (g5Monitor files)")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("repo_root", help="Path to RoboDurden Hoverboard-Firmware-Hack-Gen2.x-GD32 checkout")
    ap.add_argument("--allow-upstream-drift", action="store_true")
    ap.add_argument("--skip-vendor", action="store_true", help="do not fetch/verify the pinned EFeru generated core")
    ns = ap.parse_args()

    root = Path(ns.repo_root).resolve()
    bundle = Path(__file__).resolve().parent
    if not (root / "HoverBoardGigaDevice/Inc/defines.h").is_file():
        raise SystemExit(f"Not a Gen2.x-GD32 checkout: {root}")

    # First bring a clean/Phase1/Phase2 checkout up through Phase 3.
    if not phase3_ready(root):
        base = bundle / "_apply_phase3_base.py"
        cmd = [sys.executable, str(base), str(root)]
        if ns.allow_upstream_drift:
            cmd.append("--allow-upstream-drift")
        if ns.skip_vendor:
            cmd.append("--skip-vendor")
        print("Phase-3 base is not present; applying it first...")
        rc = subprocess.call(cmd)
        if rc:
            return rc
    else:
        print("Phase-3 motor-NTC/FOC base detected; preserving it and adding CubeIDE Phase 4.")

    try:
        install_phase4_overlay(bundle, root)
        patch_makefile(root)
        patch_keil_monitor_files(root)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    # Ensure the pinned EFeru core exists when the Phase-3 base was already present.
    if phase3_ready(root) and not ns.skip_vendor:
        vendor = bundle / "vendor_eferu_foc.py"
        rc = subprocess.call([sys.executable, str(vendor), str(root)])
        if rc:
            return rc

    print("\nPhase-4 CubeIDE integration applied.")
    print("Project to import: <repo>/HoverBoardGigaDevice")
    print("CubeIDE project name: Gyroor_G5_GD32F130_FOC")
    print("Build output: build/GD32F130.elf")
    print("Primary flash launch: Gyroor G5 - Program 400kHz")
    print("Live debug: start 'Gyroor G5 - OpenOCD Server', then 'Gyroor G5 - Attach Live'.")
    print("In Live Expressions add one expression: g5mon")
    print("IMPORTANT: FOC_SAFE_BRINGUP remains 1; motor phase outputs are still forced to zero.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
