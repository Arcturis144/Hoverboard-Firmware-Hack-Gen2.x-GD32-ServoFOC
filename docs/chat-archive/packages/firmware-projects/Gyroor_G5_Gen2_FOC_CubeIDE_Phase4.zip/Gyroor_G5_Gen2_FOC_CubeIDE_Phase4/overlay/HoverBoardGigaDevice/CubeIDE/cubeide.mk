# CubeIDE integration for the Gyroor G5 GD32F130 project.
# Included at the end of the upstream Gen2 Makefile by the Phase-4 patcher.

SWD_KHZ ?= 400

# CubeIDE knows where its bundled GNU Arm toolchain lives. Passing
# CUBEIDE_GNU_BIN from the Eclipse build configuration avoids requiring a
# separate compiler installation or global PATH changes.
ifneq ($(strip $(CUBEIDE_GNU_BIN)),)
  CUBEIDE_GNU_BIN_NORM := $(subst \\,/,$(CUBEIDE_GNU_BIN))
  override PREFIX := $(CUBEIDE_GNU_BIN_NORM)/arm-none-eabi-
  override CC := "$(PREFIX)gcc"
  override AS := "$(PREFIX)gcc" -x assembler-with-cpp
  override CP := "$(PREFIX)objcopy"
  override NM := "$(PREFIX)nm"
  override SZ := "$(PREFIX)size"
  override HEX := $(CP) -O ihex
  override BIN := $(CP) -O binary -S
endif

CUBE_PROGRAMMER ?= STM32_Programmer_CLI
OPENOCD ?= openocd

.PHONY: flash-cubeprogrammer openocd-server flash-openocd print-cubeide-tools

# Primary programming path. This uses the CubeProgrammer CLI shipped with
# CubeIDE, at 400 kHz and hot-plug attach because NRST is not exposed on the
# OL20180703-V4.1 board.
flash-cubeprogrammer: all
	@echo "Programming GD32F130 at $(SWD_KHZ) kHz via STM32CubeProgrammer (hot-plug)..."
	@"$(CUBE_PROGRAMMER)" -c port=SWD freq=$(SWD_KHZ) mode=hotplug -w build/GD32F130.elf -v
	@echo "Programming complete. Power-cycle the controller before normal run testing."

# OpenOCD is the debugger transport for CubeIDE Live Expressions. The target
# configuration is intentionally attach-oriented: no external NRST is assumed.
openocd-server:
	@"$(OPENOCD)" -f CubeIDE/openocd/gyroor_gd32f130_stlink.cfg -c "adapter speed $(SWD_KHZ)"

# Secondary/experimental programming route. Keep CubeProgrammer as the normal
# flasher until OpenOCD flash compatibility has been verified on this exact board.
flash-openocd: all
	@"$(OPENOCD)" -f CubeIDE/openocd/gyroor_gd32f130_stlink.cfg -c "adapter speed $(SWD_KHZ)" -c "program build/GD32F130.elf verify exit"

print-cubeide-tools:
	@echo CC=$(CC)
	@echo OPENOCD=$(OPENOCD)
	@echo CUBE_PROGRAMMER=$(CUBE_PROGRAMMER)
