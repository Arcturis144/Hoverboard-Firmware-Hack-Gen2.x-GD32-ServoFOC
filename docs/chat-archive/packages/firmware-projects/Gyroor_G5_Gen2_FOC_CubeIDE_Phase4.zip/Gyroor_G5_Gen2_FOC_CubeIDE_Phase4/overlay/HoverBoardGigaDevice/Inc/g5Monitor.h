#ifndef G5_MONITOR_H
#define G5_MONITOR_H

#include <stdint.h>

/*
 * Single debugger-visible snapshot for STM32CubeIDE Live Expressions.
 * Add only `g5mon` to Live Expressions and expand the nested members.
 *
 * The snapshot is refreshed at the capability-manager rate (normally 100 Hz),
 * not at the 16 kHz motor-control ISR rate. `sequence` is written last so a
 * changing value means a complete new snapshot has been published.
 */
typedef struct
{
    uint32_t sequence;

    struct
    {
        uint16_t battery_raw;
        uint16_t battery_centivolt;   /* 0.01 V, layout-20 divider calibration */
        uint16_t phase_a_raw;
        uint16_t phase_b_raw;
        uint16_t motor_ntc_raw;
        int16_t  phase_a_offset;
        int16_t  phase_b_offset;
        uint8_t  offsets_ready;
    } adc;

    struct
    {
        int16_t  phase_a_model;
        int16_t  phase_b_model;
        int16_t  phase_c_model;
        int16_t  phase_a_centiamp;    /* provisional until PA0/PB0 gain is calibrated */
        int16_t  phase_b_centiamp;
        int16_t  phase_c_centiamp;
        uint16_t rms_centiamp;
    } current;

    struct
    {
        uint16_t raw;
        uint16_t filtered_raw;
        uint32_t resistance_ohm;
        uint16_t limit_centiamp;
        uint8_t  valid;
    } motor_temp;

    struct
    {
        uint8_t  profile;
        uint8_t  fault_flags;
        uint8_t  current_sensor_valid;
        uint16_t thermal_load_permille;
        uint16_t absolute_limit_centiamp;
        uint16_t thermal_limit_centiamp;
        uint16_t battery_limit_centiamp;
        uint16_t temperature_limit_centiamp;
        uint16_t global_limit_centiamp;
        uint16_t profile_limit_centiamp;
        uint16_t effective_limit_centiamp;
    } capability;

    struct
    {
        uint8_t  hall_a_raw;
        uint8_t  hall_b_raw;
        uint8_t  hall_c_raw;
        uint8_t  hall_raw_bits;       /* A:B:C packed as bits 2:1:0 */
        uint8_t  hall_foc_bits;       /* after configured inversions */
        uint8_t  bldc_enable_request;
        uint8_t  foc_motor_enable;
        uint8_t  safe_bringup;
        uint8_t  error;
        int16_t  target_model;
        int16_t  speed_rpm_x16;
        int16_t  iq_raw;
        int16_t  id_raw;
        int16_t  out_phase_a;
        int16_t  out_phase_b;
        int16_t  out_phase_c;
        uint16_t dynamic_i_max_q4;
    } foc;

} G5MonitorData;

extern volatile G5MonitorData g5mon;

#endif /* G5_MONITOR_H */
