#include "../Inc/g5Monitor.h"

/* Volatile keeps the complete monitor object present and directly readable over SWD. */
volatile G5MonitorData g5mon;
