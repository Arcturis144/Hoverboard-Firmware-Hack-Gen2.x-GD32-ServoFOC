#include "../Inc/driveCapability.h"
#include "../Inc/defines.h"
#include "../Inc/foc_config.h"
#include <stdint.h>

#define CAP_Q16_ONE               65536UL
#define CAP_THERMAL_STATE_MAX_Q16 (4UL * CAP_Q16_ONE)
#define CAP_UPDATE_DIV            (PWM_FREQ / CAPABILITY_UPDATE_HZ)

#if CAPABILITY_UPDATE_HZ == 0
#error "CAPABILITY_UPDATE_HZ must be nonzero"
#endif
#if CAP_UPDATE_DIV == 0
#error "CAPABILITY_UPDATE_HZ cannot exceed PWM_FREQ"
#endif

volatile uint8_t  cap_profile = DRIVE_PROFILE_NORMAL;
volatile uint8_t  cap_fault_flags = CAP_FAULT_CURRENT_NOT_READY;
volatile uint8_t  cap_current_sensor_valid = 0;
volatile uint8_t  cap_temperature_valid = 0;
volatile int16_t  cap_temperature_deci_c = 0;
volatile uint16_t cap_current_rms_centiamp = 0;
volatile uint16_t cap_absolute_limit_centiamp = CAP_ABSOLUTE_CURRENT_CENTIAMP;
volatile uint16_t cap_thermal_limit_centiamp = 0;
volatile uint16_t cap_battery_limit_centiamp = CAP_ABSOLUTE_CURRENT_CENTIAMP;
volatile uint16_t cap_temperature_limit_centiamp = CAP_ABSOLUTE_CURRENT_CENTIAMP;
volatile uint16_t cap_motor_ntc_limit_centiamp = CAP_ABSOLUTE_CURRENT_CENTIAMP;
volatile uint16_t cap_global_limit_centiamp = 0;
volatile uint16_t cap_profile_limit_centiamp = 0;
volatile uint16_t cap_effective_limit_centiamp = 0;
volatile uint16_t cap_thermal_load_permille = 0;
volatile uint32_t cap_update_sequence = 0;

volatile uint16_t cap_motor_ntc_raw = 0;
volatile uint16_t cap_motor_ntc_filtered_raw = 0;
volatile uint32_t cap_motor_ntc_ohm = 0;
volatile uint8_t  cap_motor_ntc_valid = 0;

static uint64_t cap_current_sq_accum = 0;
static uint32_t cap_motor_ntc_raw_accum = 0;
static uint16_t cap_sample_count = 0;
static uint32_t cap_thermal_state_q16 = 0;
static uint16_t cap_battery_raw_latest = 0;
static uint8_t  cap_motor_ntc_filter_ready = 0;

static uint16_t cap_min_u16(uint16_t a, uint16_t b)
{
    return (a < b) ? a : b;
}

static uint16_t cap_clamp_u16_u32(uint32_t v)
{
    return (v > 65535UL) ? 65535U : (uint16_t)v;
}

static uint32_t cap_isqrt_u32(uint32_t x)
{
    uint32_t op = x;
    uint32_t res = 0;
    uint32_t one = 1UL << 30;

    while (one > op) one >>= 2;
    while (one != 0)
    {
        if (op >= res + one)
        {
            op -= res + one;
            res = (res >> 1) + one;
        }
        else
        {
            res >>= 1;
        }
        one >>= 2;
    }
    return res;
}

static uint16_t cap_profile_limit(DriveProfile profile)
{
    uint32_t permille;
    switch (profile)
    {
        case DRIVE_PROFILE_SNOW:  permille = CAP_PROFILE_SNOW_PERMILLE;  break;
        case DRIVE_PROFILE_BOOST: permille = CAP_PROFILE_BOOST_PERMILLE; break;
        case DRIVE_PROFILE_NORMAL:
        default:                  permille = CAP_PROFILE_NORMAL_PERMILLE; break;
    }
    return cap_clamp_u16_u32((CAP_ABSOLUTE_CURRENT_CENTIAMP * permille) / 1000UL);
}

static uint16_t cap_thermal_limit_from_load(uint32_t load_permille)
{
    const uint32_t abs_i  = CAP_ABSOLUTE_CURRENT_CENTIAMP;
    const uint32_t cont_i = CAP_CONTINUOUS_CURRENT_CENTIAMP;

    if (load_permille <= CAP_THERMAL_SOFT_PERMILLE)
        return (uint16_t)abs_i;

    if (load_permille < CAP_THERMAL_HARD_PERMILLE)
    {
        uint32_t span = CAP_THERMAL_HARD_PERMILLE - CAP_THERMAL_SOFT_PERMILLE;
        uint32_t left = CAP_THERMAL_HARD_PERMILLE - load_permille;
        return (uint16_t)(cont_i + ((abs_i - cont_i) * left) / span);
    }

    if (load_permille < CAP_THERMAL_CUTOFF_PERMILLE)
    {
        uint32_t span = CAP_THERMAL_CUTOFF_PERMILLE - CAP_THERMAL_HARD_PERMILLE;
        uint32_t left = CAP_THERMAL_CUTOFF_PERMILLE - load_permille;
        return (uint16_t)((cont_i * left) / span);
    }

    return 0;
}

static uint16_t cap_temperature_limit(void)
{
#if CAP_USE_TEMPERATURE_SENSOR
    if (!cap_temperature_valid)
        return 0;

    if (cap_temperature_deci_c <= CAP_TEMP_DERATE_START_DECIC)
        return CAP_ABSOLUTE_CURRENT_CENTIAMP;

    if (cap_temperature_deci_c >= CAP_TEMP_CUTOFF_DECIC)
        return 0;

    {
        uint32_t span = (uint32_t)(CAP_TEMP_CUTOFF_DECIC - CAP_TEMP_DERATE_START_DECIC);
        uint32_t left = (uint32_t)(CAP_TEMP_CUTOFF_DECIC - cap_temperature_deci_c);
        return (uint16_t)((CAP_ABSOLUTE_CURRENT_CENTIAMP * left) / span);
    }
#else
    return CAP_ABSOLUTE_CURRENT_CENTIAMP;
#endif
}

static uint16_t cap_battery_limit(void)
{
#if CAP_USE_BATTERY_DERATE
    float battery_v = (float)cap_battery_raw_latest * ADC_BATTERY_VOLT;

    if (battery_v <= BAT_LOW_DEAD)
        return 0;
    if (battery_v >= BAT_LOW_LVL2)
        return CAP_ABSOLUTE_CURRENT_CENTIAMP;

    return (uint16_t)((float)CAP_ABSOLUTE_CURRENT_CENTIAMP *
                      (battery_v - BAT_LOW_DEAD) /
                      (BAT_LOW_LVL2 - BAT_LOW_DEAD));
#else
    return CAP_ABSOLUTE_CURRENT_CENTIAMP;
#endif
}

static uint32_t cap_motor_ntc_resistance_ohm(uint16_t adc_raw)
{
#if CAP_USE_MOTOR_NTC
    uint32_t den;

    if ((adc_raw < CAP_MOTOR_NTC_ADC_RAIL_GUARD) ||
        (adc_raw >= (CAP_MOTOR_NTC_ADC_FULL_SCALE - CAP_MOTOR_NTC_ADC_RAIL_GUARD)))
        return 0;

    den = CAP_MOTOR_NTC_ADC_FULL_SCALE - (uint32_t)adc_raw;
    if (den == 0)
        return 0;

    /* Same divider form reconstructed from the factory firmware, rescaled
       from its 15-bit filtered representation to the raw 12-bit ADC. */
    return (CAP_MOTOR_NTC_FIXED_OHM * (uint32_t)adc_raw) / den;
#else
    (void)adc_raw;
    return 0;
#endif
}

static uint16_t cap_motor_ntc_limit_from_ohm(uint32_t resistance_ohm, uint8_t valid)
{
#if CAP_USE_MOTOR_NTC
    if (!valid)
    {
#if CAP_MOTOR_NTC_REQUIRE_VALID
        return 0;
#else
        return CAP_ABSOLUTE_CURRENT_CENTIAMP;
#endif
    }

    if (resistance_ohm >= CAP_MOTOR_NTC_DERATE_START_OHM)
        return CAP_ABSOLUTE_CURRENT_CENTIAMP;

    if (resistance_ohm <= CAP_MOTOR_NTC_CUTOFF_OHM)
        return 0;

    /* Tentative continuous derating between the two factory resistance
       thresholds. We intentionally do not claim a Celsius value yet. */
    {
        uint32_t span = CAP_MOTOR_NTC_DERATE_START_OHM - CAP_MOTOR_NTC_CUTOFF_OHM;
        uint32_t above_cutoff = resistance_ohm - CAP_MOTOR_NTC_CUTOFF_OHM;
        return (uint16_t)((CAP_ABSOLUTE_CURRENT_CENTIAMP * above_cutoff) / span);
    }
#else
    (void)resistance_ohm;
    (void)valid;
    return CAP_ABSOLUTE_CURRENT_CENTIAMP;
#endif
}

void DriveCapability_Init(void)
{
    cap_profile = (uint8_t)CAP_DEFAULT_PROFILE;
    cap_fault_flags = CAP_FAULT_CURRENT_NOT_READY;
    cap_current_sensor_valid = 0;
    cap_current_rms_centiamp = 0;
    cap_absolute_limit_centiamp = CAP_ABSOLUTE_CURRENT_CENTIAMP;
    cap_thermal_limit_centiamp = 0;
    cap_battery_limit_centiamp = CAP_ABSOLUTE_CURRENT_CENTIAMP;
    cap_temperature_limit_centiamp = CAP_ABSOLUTE_CURRENT_CENTIAMP;
    cap_motor_ntc_limit_centiamp = CAP_ABSOLUTE_CURRENT_CENTIAMP;
    cap_global_limit_centiamp = 0;
    cap_profile_limit_centiamp = cap_profile_limit((DriveProfile)cap_profile);
    cap_effective_limit_centiamp = 0;
    cap_thermal_load_permille = 0;
    cap_update_sequence = 0;

    cap_motor_ntc_raw = 0;
    cap_motor_ntc_filtered_raw = 0;
    cap_motor_ntc_ohm = 0;
    cap_motor_ntc_valid = 0;

    cap_current_sq_accum = 0;
    cap_motor_ntc_raw_accum = 0;
    cap_sample_count = 0;
    cap_thermal_state_q16 = 0;
    cap_motor_ntc_filter_ready = 0;
}

void DriveCapability_SetProfile(DriveProfile profile)
{
    if (profile > DRIVE_PROFILE_BOOST)
        profile = DRIVE_PROFILE_NORMAL;
    cap_profile = (uint8_t)profile;
}

DriveProfile DriveCapability_GetProfile(void)
{
    return (DriveProfile)cap_profile;
}

void DriveCapability_SetTemperatureDeciC(int16_t temperature_deci_c, uint8_t valid)
{
    cap_temperature_deci_c = temperature_deci_c;
    cap_temperature_valid = valid ? 1U : 0U;
}

void DriveCapability_Update(int16_t phase_a_model,
                            int16_t phase_b_model,
                            uint16_t phase_a_raw,
                            uint16_t phase_b_raw,
                            uint8_t current_offsets_ready,
                            uint16_t battery_raw,
                            uint16_t motor_ntc_raw)
{
    int32_t ia = phase_a_model;
    int32_t ib = phase_b_model;
    int32_t ic = -(ia + ib);
    uint64_t sq;
    uint8_t rail_fault;

    cap_battery_raw_latest = battery_raw;
    cap_motor_ntc_raw = motor_ntc_raw;

    rail_fault = (phase_a_raw < CAP_CURRENT_ADC_RAIL_GUARD) ||
                 (phase_b_raw < CAP_CURRENT_ADC_RAIL_GUARD) ||
                 (phase_a_raw > (4095U - CAP_CURRENT_ADC_RAIL_GUARD)) ||
                 (phase_b_raw > (4095U - CAP_CURRENT_ADC_RAIL_GUARD));

    cap_current_sensor_valid = (current_offsets_ready && !rail_fault) ? 1U : 0U;

    sq = (uint64_t)((int64_t)ia * ia) +
         (uint64_t)((int64_t)ib * ib) +
         (uint64_t)((int64_t)ic * ic);
    cap_current_sq_accum += sq;
    cap_motor_ntc_raw_accum += motor_ntc_raw;
    cap_sample_count++;

    if (cap_sample_count < CAP_UPDATE_DIV)
        return;

    {
        uint32_t mean_phase_sq;
        uint32_t rms_model;
        uint32_t cont_model;
        uint32_t cont_sq;
        uint32_t heat_ratio_q16;
        int64_t thermal_delta;
        uint32_t thermal_den;
        uint32_t thermal_load_permille;
        uint16_t global_limit;
        uint16_t ntc_avg_raw;

        mean_phase_sq = (uint32_t)(cap_current_sq_accum / ((uint64_t)cap_sample_count * 3ULL));
        rms_model = cap_isqrt_u32(mean_phase_sq);
        cap_current_rms_centiamp = cap_clamp_u16_u32(
            (rms_model * 100UL) / FOC_MODEL_COUNTS_PER_AMP);

        cont_model = ((uint32_t)CAP_CONTINUOUS_CURRENT_CENTIAMP *
                      FOC_MODEL_COUNTS_PER_AMP) / 100UL;
        if (cont_model == 0) cont_model = 1;
        cont_sq = cont_model * cont_model;

        heat_ratio_q16 = (uint32_t)(((uint64_t)mean_phase_sq * CAP_Q16_ONE) / cont_sq);
        if (heat_ratio_q16 > CAP_THERMAL_STATE_MAX_Q16)
            heat_ratio_q16 = CAP_THERMAL_STATE_MAX_Q16;

        thermal_den = (uint32_t)CAP_THERMAL_TAU_SECONDS * CAPABILITY_UPDATE_HZ;
        if (thermal_den == 0) thermal_den = 1;
        thermal_delta = (int64_t)heat_ratio_q16 - (int64_t)cap_thermal_state_q16;
        cap_thermal_state_q16 = (uint32_t)((int64_t)cap_thermal_state_q16 +
                                          thermal_delta / (int64_t)thermal_den);
        if (cap_thermal_state_q16 > CAP_THERMAL_STATE_MAX_Q16)
            cap_thermal_state_q16 = CAP_THERMAL_STATE_MAX_Q16;

        thermal_load_permille = (cap_thermal_state_q16 * 1000UL) / CAP_Q16_ONE;
        cap_thermal_load_permille = cap_clamp_u16_u32(thermal_load_permille);

#if CAP_USE_MOTOR_NTC
        ntc_avg_raw = (uint16_t)(cap_motor_ntc_raw_accum / cap_sample_count);
        if (!cap_motor_ntc_filter_ready)
        {
            cap_motor_ntc_filtered_raw = ntc_avg_raw;
            cap_motor_ntc_filter_ready = 1;
        }
        else
        {
            /* ~80 ms IIR at CAPABILITY_UPDATE_HZ=100, in addition to the
               per-window average of the PWM-rate samples. */
            cap_motor_ntc_filtered_raw = (uint16_t)(
                ((uint32_t)cap_motor_ntc_filtered_raw * 7UL + ntc_avg_raw) / 8UL);
        }

        cap_motor_ntc_ohm = cap_motor_ntc_resistance_ohm(cap_motor_ntc_filtered_raw);
        cap_motor_ntc_valid = (cap_motor_ntc_ohm != 0U) ? 1U : 0U;
#else
        ntc_avg_raw = 0;
        (void)ntc_avg_raw;
        cap_motor_ntc_ohm = 0;
        cap_motor_ntc_valid = 0;
#endif

        cap_absolute_limit_centiamp = CAP_ABSOLUTE_CURRENT_CENTIAMP;
        cap_thermal_limit_centiamp = cap_thermal_limit_from_load(thermal_load_permille);
        cap_battery_limit_centiamp = cap_battery_limit();
        cap_temperature_limit_centiamp = cap_temperature_limit();
        cap_motor_ntc_limit_centiamp = cap_motor_ntc_limit_from_ohm(
            cap_motor_ntc_ohm, cap_motor_ntc_valid);
        cap_profile_limit_centiamp = cap_profile_limit((DriveProfile)cap_profile);

        cap_fault_flags = 0;
        if (!current_offsets_ready)
            cap_fault_flags |= CAP_FAULT_CURRENT_NOT_READY;
        if (rail_fault)
            cap_fault_flags |= CAP_FAULT_CURRENT_ADC_RAIL;
        if (thermal_load_permille >= CAP_THERMAL_CUTOFF_PERMILLE)
            cap_fault_flags |= CAP_FAULT_THERMAL_HARD;
#if CAP_USE_BATTERY_DERATE
        if (cap_battery_limit_centiamp == 0)
            cap_fault_flags |= CAP_FAULT_BATTERY_LOW;
#endif
#if CAP_USE_TEMPERATURE_SENSOR
        if (cap_temperature_limit_centiamp == 0)
            cap_fault_flags |= CAP_FAULT_TEMPERATURE_HIGH;
#endif
#if CAP_USE_MOTOR_NTC
        if (!cap_motor_ntc_valid)
            cap_fault_flags |= CAP_FAULT_MOTOR_NTC_INVALID;
        if (cap_motor_ntc_valid &&
            cap_motor_ntc_ohm <= CAP_MOTOR_NTC_CUTOFF_OHM)
            cap_fault_flags |= CAP_FAULT_MOTOR_NTC_HOT;
#endif

        if (!cap_current_sensor_valid)
        {
            cap_global_limit_centiamp = 0;
            cap_effective_limit_centiamp = 0;
        }
        else
        {
            global_limit = cap_absolute_limit_centiamp;
            global_limit = cap_min_u16(global_limit, cap_thermal_limit_centiamp);
            global_limit = cap_min_u16(global_limit, cap_battery_limit_centiamp);
            global_limit = cap_min_u16(global_limit, cap_temperature_limit_centiamp);
            global_limit = cap_min_u16(global_limit, cap_motor_ntc_limit_centiamp);
            cap_global_limit_centiamp = global_limit;

            cap_effective_limit_centiamp = cap_min_u16(global_limit, cap_profile_limit_centiamp);
        }

        /* Publish after every complete aggregate update. g5Monitor uses this as
           a low-rate snapshot trigger so Live Expressions does not require
           reading dozens of 16 kHz variables independently. */
        cap_update_sequence++;
    }

    cap_current_sq_accum = 0;
    cap_motor_ntc_raw_accum = 0;
    cap_sample_count = 0;
}

uint16_t DriveCapability_GetEffectiveCurrentModelQ4(void)
{
    uint32_t q4 = ((uint32_t)cap_effective_limit_centiamp *
                   FOC_MODEL_COUNTS_PER_AMP * 16UL) / 100UL;
    return cap_clamp_u16_u32(q4);
}
