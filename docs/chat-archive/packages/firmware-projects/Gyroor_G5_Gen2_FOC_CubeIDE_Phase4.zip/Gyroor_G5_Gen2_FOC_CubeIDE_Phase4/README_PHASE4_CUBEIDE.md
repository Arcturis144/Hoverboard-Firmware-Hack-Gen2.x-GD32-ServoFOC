# Gyroor G5 GD32F130 + Gen2.1.20 + EFeru FOC — Phase 4 CubeIDE

Target hardware: **OLSZ OL20180703-V4.1**, **GD32F130C8T6**, RoboDurden Gen2.x-GD32 **layout 2.1.20**.

Phase 4 keeps the Phase-3 FOC/current/I²t/motor-NTC work and moves the normal development workflow into **STM32CubeIDE** without pretending the GD32F130 is an STM32 MCU. CubeIDE is used as the editor, GNU Arm build front end, GDB debugger, programmer launcher, and Live Expressions monitor. The actual device support remains the GD32/Gen2 startup code, headers, peripheral library, and linker script.

**Motor output is still disabled:** `FOC_SAFE_BRINGUP` remains `1`.

## What Phase 4 adds

- CubeIDE import metadata (`.project`, `.cproject`) for the existing Gen2 GNU Makefile project.
- The existing Gen2 GNU Arm build remains authoritative.
- Existing GD32F130 linker script remains authoritative: **64 KiB flash at 0x08000000 and 8 KiB SRAM at 0x20000000**.
- CubeIDE's bundled GNU Arm compiler can be used through `gnu_tools_for_stm32_compiler_path`.
- A CubeProgrammer launch configuration programs at **400 kHz SWD in hot-plug mode** (no NRST required).
- An OpenOCD server configuration for ST-Link/SWD at **400 kHz**.
- A GDB Hardware Debugging attach configuration for live debugging without reset or image download.
- A single debugger-visible `g5mon` structure for Live Expressions.
- `g5mon` refreshes from a **100 Hz snapshot**, not by copying data every 16 kHz motor-control interrupt.

## Apply to the firmware checkout

From the extracted Phase-4 bundle:

```powershell
py .\apply_phase4_cubeide.py C:\path\to\Hoverboard-Firmware-Hack-Gen2.x-GD32
```

It accepts a clean supported upstream checkout or one already patched through Phase 1, 2, or 3. Existing changed files are backed up with `.phase4.bak` before the Phase-4 overlay replaces them.

The pinned EFeru generated FOC core is verified against commit:

```text
4f141cbc97b297e194fd58e56444bd0322f902ac
```

If the EFeru files are already present and verified, they are not downloaded again.

## Import into STM32CubeIDE

After applying the patch:

1. Open STM32CubeIDE.
2. Use **File -> Import -> General -> Existing Projects into Workspace**.
3. Select:

```text
<repo>\HoverBoardGigaDevice
```

4. Import the project named:

```text
Gyroor_G5_GD32F130_FOC
```

Do **not** create a new STM32 MCU project and do not select a substitute STM32 device. This project intentionally uses the GD32 startup, CMSIS/SPL support and Gen2 linker script already in the repository.

## Build

Normal CubeIDE build:

```text
Ctrl+B
```

The CubeIDE project calls the upstream Makefile and passes the IDE's bundled GNU Arm compiler path. Expected outputs are:

```text
HoverBoardGigaDevice\build\GD32F130.elf
HoverBoardGigaDevice\build\GD32F130.hex
HoverBoardGigaDevice\build\GD32F130.bin
HoverBoardGigaDevice\build\GD32F130.map
HoverBoardGigaDevice\build\GD32F130.sym
```

The first build is important because we still need the real linked flash/RAM size of the combined Gen2 + EFeru + capability + monitor image.

## Program from CubeIDE

The project includes the shared External Tools configuration:

```text
Gyroor G5 - Program 400kHz
```

It calls CubeIDE's packaged `STM32_Programmer_CLI.exe` with:

```text
port=SWD
freq=400
mode=hotplug
image=build/GD32F130.elf
verify=enabled
```

Use normal controller/battery-side board power. Do not power the controller from the ST-Link 3.3 V pin.

Because NRST is not exposed, the programming configuration deliberately uses hot-plug instead of connect-under-reset. Power-cycle the controller after programming before normal run testing.

## Attach the debugger and monitor live data

Start these two shared launch configurations in this order:

```text
1. External Tools -> Gyroor G5 - OpenOCD Server
2. Debug -> Gyroor G5 - Attach Live
```

The OpenOCD configuration uses ST-Link SWD at **400 kHz**. If connection is unstable, edit:

```text
CubeIDE\openocd\gyroor_gd32f130_stlink.cfg
```

and change:

```text
adapter speed 400
```

to:

```text
adapter speed 100
```

or **150 kHz** if desired. We already know this hardware is unreliable at multi-MHz SWD rates.

The attach configuration:

- loads ELF symbols;
- does **not** download an image;
- does **not** request NRST;
- connects to OpenOCD on localhost port 3333;
- resumes the target for live monitoring.

## Live Expressions: add only `g5mon`

Open:

```text
Window -> Show View -> Live Expressions
```

Add this single expression:

```text
g5mon
```

Expand it. The structure is grouped as follows.

### `g5mon.adc`

```text
battery_raw
battery_centivolt        0.01 V
phase_a_raw
phase_b_raw
motor_ntc_raw
phase_a_offset
phase_b_offset
offsets_ready
```

### `g5mon.current`

```text
phase_a_model
phase_b_model
phase_c_model
phase_a_centiamp         0.01 A, provisional calibration
phase_b_centiamp         0.01 A, provisional calibration
phase_c_centiamp         0.01 A, provisional calibration
rms_centiamp             0.01 A, provisional calibration
```

The current values are still provisional because `FOC_ADC_COUNTS_PER_AMP = 99` has not yet been physically calibrated.

### `g5mon.motor_temp`

```text
raw
filtered_raw
resistance_ohm
limit_centiamp
valid
```

PA6 is still treated as the **tentative motor NTC**. The resistance calculation and the factory 8.0 kOhm / 6.0 kOhm behavior are firmware-supported; the physical motor wire and the thermistor's Celsius curve still need confirmation.

### `g5mon.capability`

```text
profile
fault_flags
current_sensor_valid
thermal_load_permille
absolute_limit_centiamp
thermal_limit_centiamp
battery_limit_centiamp
temperature_limit_centiamp
global_limit_centiamp
profile_limit_centiamp
effective_limit_centiamp
```

### `g5mon.foc`

```text
hall_a_raw
hall_b_raw
hall_c_raw
hall_raw_bits
hall_foc_bits
bldc_enable_request
foc_motor_enable
safe_bringup
error
target_model
speed_rpm_x16
iq_raw
id_raw
out_phase_a
out_phase_b
out_phase_c
dynamic_i_max_q4
```

`hall_raw_bits` and `hall_foc_bits` pack A:B:C as bits 2:1:0.

`g5mon.sequence` increments after each complete 100 Hz capability update and is written **after** the rest of the snapshot. If it is changing, the firmware is publishing new monitor data.

## Capability fault bits

```text
0x01  current zero offsets not ready
0x02  current ADC at/near rail
0x04  I²/current-heating model at hard cutoff
0x08  battery-low limit (only when enabled)
0x10  second/future board-temperature limit (only when enabled)
0x20  PA6 motor-NTC input invalid
0x40  PA6 motor-NTC at/below the provisional 6.0 kOhm cutoff
```

## What to inspect on the first run

With `FOC_SAFE_BRINGUP=1`, the bridge output remains zero. The first useful live session should establish:

1. `g5mon.sequence` increments steadily.
2. Current offsets converge and `offsets_ready` becomes 1.
3. PA0/PB0 raw values are not pinned at ADC rails.
4. Hall bits change correctly when the wheel is rotated by hand.
5. PA6 `motor_temp.resistance_ohm` is stable and plausible at room temperature.
6. Warming the motor changes PA6 resistance in the expected NTC direction (resistance decreases as temperature rises).
7. The extra motor wire can be confirmed electrically against Hall ground / PA6.
8. `fault_flags` and all current limits behave as expected while no motor torque can be generated.

## Important scope

This package has been assembled and statically checked here, but it has **not yet been linked with the Arm GNU toolchain against the complete upstream tree in this environment**, because that toolchain/repository is not locally available here. The first CubeIDE build on your machine is therefore the authoritative compile/link test.

OpenOCD is used primarily for debugger transport. **CubeProgrammer remains the primary programming route** until OpenOCD flash programming has been verified on this exact GD32 board.
