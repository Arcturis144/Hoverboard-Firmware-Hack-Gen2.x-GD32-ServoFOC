#ifndef BLDC_FOC_H
#define BLDC_FOC_H

#include <stdint.h>

/* CubeMonitor / debugger-visible bring-up values. */
extern volatile uint16_t foc_adc_phase_a_raw;
extern volatile uint16_t foc_adc_phase_b_raw;
extern volatile int16_t  foc_adc_phase_a_offset;
extern volatile int16_t  foc_adc_phase_b_offset;
extern volatile int16_t  foc_current_a_model;
extern volatile int16_t  foc_current_b_model;
extern volatile int16_t  foc_target_model;
extern volatile int16_t  foc_out_phase_a;
extern volatile int16_t  foc_out_phase_b;
extern volatile int16_t  foc_out_phase_c;
extern volatile int16_t  foc_speed_rpm_x16;
extern volatile int16_t  foc_iq_raw;
extern volatile int16_t  foc_id_raw;
extern volatile uint8_t  foc_error;
extern volatile uint8_t  foc_offsets_ready;

#endif /* BLDC_FOC_H */
