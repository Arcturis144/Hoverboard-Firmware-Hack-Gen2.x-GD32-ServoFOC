#ifndef FOC_CONFIG_H
#define FOC_CONFIG_H

/*
 * Gyroor G5 / OLSZ OL20180703-V4.1 FOC integration configuration.
 *
 * PHASE 1 IS A BRING-UP BUILD.  Motor output is intentionally forced to zero
 * until current-sensor scaling, phase-current order, Hall order and PWM sampling
 * are verified on the physical board.
 */

#define FOC_SAFE_BRINGUP                 1

/* EFeru BLDC_controller numeric selections. */
#define FOC_CONTROL_TYPE_FOC             2
#define FOC_CONTROL_MODE_VOLTAGE         1
#define FOC_DIAGNOSTICS_ENABLE           1

/* Conservative values for first powered motor test after SAFE_BRINGUP is removed. */
#define FOC_I_MOT_MAX_A                  5
#define FOC_N_MOT_MAX_RPM                500

/* Field weakening is deliberately disabled during bring-up. */
#define FOC_FIELD_WEAK_ENABLE            0
#define FOC_FIELD_WEAK_MAX_A             0
#define FOC_PHASE_ADV_MAX_DEG            0
#define FOC_FIELD_WEAK_HI                1000
#define FOC_FIELD_WEAK_LO                750

/* EFeru's generated controller uses 50 internal current counts per ampere. */
#define FOC_MODEL_COUNTS_PER_AMP         50

/*
 * PROVISIONAL hardware scale only.
 * Layout 2.1.20 documents 4 mOhm low-side shunts and approximately 20x gain.
 * That implies about 99.3 ADC counts/A at a 3.3 V, 12-bit ADC.
 * Measure/calibrate this before enabling the bridge.
 */
#define FOC_ADC_COUNTS_PER_AMP           99

/*
 * Raw current convention follows the EFeru/split-board implementation:
 * current = zero_offset - ADC_sample.  Flip either sign after bench validation
 * if the physical amplifier polarity differs.
 */
#define FOC_PHASE_A_SIGN                 1
#define FOC_PHASE_B_SIGN                 1

/* Hall-model mapping. Keep identity until verified with the motor unloaded. */
#define FOC_HALL_A_INVERT                0
#define FOC_HALL_B_INVERT                0
#define FOC_HALL_C_INVERT                0

/*
 * Reserve the same approximate current-sampling window used by EFeru FOC:
 * 110 counts on a 2000-count PWM period = 5.5% of the full period.
 */
#define FOC_PWM_MARGIN_PERMILLE          55

/* Offset average length. At 16 kHz this is nominally 125 ms. */
#define FOC_CURRENT_OFFSET_SAMPLES       2000

#endif /* FOC_CONFIG_H */
