# Gyroor G5 Gen2.1.20 + EFeru FOC — Phase 1 integration

Target hardware: **OLSZ OL20180703-V4.1**, **GD32F130C8T6**, current Gen2.x-GD32 **layout 2.1.20**.

This bundle starts the merge without replacing the working Gen2 hardware layer. It adds an EFeru FOC backend to the current Gen2 BLDC abstraction and keeps the existing Gen2 IMU/optical-switch infrastructure.

## What Phase 1 changes

- selects `TARGET=1 / GD32F130` layout **20**;
- adds `BLDC_FOC` beside the existing `BLDC_BC` and `BLDC_SINE` architecture;
- vendors only EFeru's generated `BLDC_controller` core, pinned to commit `4f141cbc97b297e194fd58e56444bd0322f902ac`;
- changes the FOC ADC DMA scan to:
  1. `PA4 / VBATT`
  2. `PB0 / PHASE_A`
  3. `PA0 / PHASE_B`
- retains Gen2's existing TIMER0-synchronised ADC trigger and DMA -> `CalculateBLDC()` path;
- retains `PHOTO_L=PC15` and `PHOTO_R=PA11` for later bumper use;
- makes layout 2.1.20 IMU implementation selectable without changing the board I2C wiring:
  - `IMU_TYPE_MPU6050_OLD`
  - `IMU_TYPE_MPU6050_COMPAT`
  - `IMU_TYPE_MPU6500`
  - `IMU_TYPE_BMI160`
- adds debugger/CubeMonitor-visible phase-current and FOC variables;
- **forces all three motor outputs to zero** with `FOC_SAFE_BRINGUP=1`.

## Apply to a clean current Gen2.x-GD32 checkout

From the directory containing this bundle:

```bash
python3 apply_phase1.py /path/to/Hoverboard-Firmware-Hack-Gen2.x-GD32
```

The patcher checks the Git blob IDs of the upstream files it edits. This bundle was prepared against these current blobs:

```text
Inc/config.h                         75aee4d4e25ed1e3366621120423b9005321d426
Inc/bldc.h                           8b450cbbca99cf964d7be1d0071a2fbfe2f8b8cb
Inc/defines.h                        683a72c7f4ab2f0e87b41670a75c5aa452724931
Inc/defines/defines_2-1-20.h         b977d94ea58a34ce59f9ce8ecfb5761b0e4b7241
Src/setup.c                          5bbf6761749decc814ddd0ca49855f77b45e1317
```

If upstream has moved, the script stops rather than guessing. Review the upstream diff first; `--allow-upstream-drift` exists only for a deliberate manual decision.

The script also downloads and verifies these exact EFeru Git blobs:

```text
Inc/BLDC_controller.h                9d663c24c08a646f05aad8e3be736eb516311576
Inc/rtwtypes.h                       3f68038730a6176838691de74668ce0adf692a7d
Src/BLDC_controller.c                ae63bd4053ebb5225f6fd2edd307ce48c76d6155
Src/BLDC_controller_data.c           626c5371980b8939e0086196fa82968b51d54afc
```

Original modified files receive a `.phase1.bak` backup.

## First build gate

Build before flashing and record both flash and RAM use. The target is a GD32F130C8: **64 KiB flash and 8 KiB SRAM**. The EFeru generated controller is substantial, so fitting the current Gen2 feature set is a hard gate; do not assume it fits until the linker reports the final image size.

If it is too large, the first reductions should be unneeded remote/pilot/debug features and then `-Os`; do not start deleting safety/current code.

## First flash is deliberately non-driving

Leave this in `Inc/foc_config.h`:

```c
#define FOC_SAFE_BRINGUP 1
```

With that set, `bldcFOC.c` still:

- samples `PB0` and `PA0`;
- establishes current-zero offsets;
- feeds the Hall/current values to the EFeru model;
- exposes the model outputs for observation;

but returns **zero** to all three PWM phase commands regardless of the requested throttle.

### Useful CubeMonitor / debugger symbols

```text
foc_adc_phase_a_raw
foc_adc_phase_b_raw
foc_adc_phase_a_offset
foc_adc_phase_b_offset
foc_current_a_model
foc_current_b_model
foc_target_model
foc_out_phase_a
foc_out_phase_b
foc_out_phase_c
foc_speed_rpm_x16
foc_iq_raw
foc_id_raw
foc_error
foc_offsets_ready
```

The existing Gen2 symbols for Hall state, battery voltage, IMU data and photo inputs remain available as before.

## Current-scale status

`FOC_ADC_COUNTS_PER_AMP` is initially **99 ADC counts/A**, derived only from the layout's documented 4 mOhm shunt and approximately 20x amplifier gain:

```text
0.004 ohm * 20 = 0.080 V/A
4095 / 3.3 V * 0.080 V/A = 99.27 ADC counts/A
```

That is a **provisional engineering estimate**, not a calibration. Before motor enable, inject/measure a known phase-current condition or otherwise characterize the amplifier and update `FOC_ADC_COUNTS_PER_AMP` and polarity.

## IMU selection

Default:

```c
#define IMU_TYPE IMU_TYPE_MPU6050_OLD
```

in `Inc/config.h`.

The layout continues to use `PB6/PB7`. Change only the `IMU_TYPE` selection to test the compatible/clone, MPU6500, or BMI160 path. The existing Gen2 drivers share the `MPU_Init()` / `MPU_ReadAll()` interface, so the FOC merge does not discard alternate IMU support.

DMP/quaternion support is intentionally not made a requirement; raw accel/gyro operation is sufficient for the mower's tilt/slope/rollover logic and is more tolerant of MPU6050-compatible clone parts.

## Before changing `FOC_SAFE_BRINGUP` to 0

Do all of these first:

1. Confirm the Phase-1 build fits 64 KiB flash / 8 KiB RAM.
2. Confirm `foc_offsets_ready` becomes 1 and both current channels sit near zero after offset subtraction.
3. Calibrate ADC-counts-per-amp and current polarity.
4. Confirm PB0 and PA0 correspond to the phase-current ordering expected by `z_selPhaCurMeasABC=0`.
5. Confirm Hall A/B/C order/inversion against the EFeru model.
6. Confirm `DC_phaA/B/C` maps to Gen2 yellow/blue/green phase outputs as expected.
7. Scope PWM and verify the phase-current sample instant is inside a valid low-side-shunt measurement window.
8. Only then enable output on an unloaded wheel with a current-limited supply and the conservative 5 A / 500 rpm limits in `foc_config.h`.

Phase 2 should resolve those validation items before torque/speed mode, RC input, Pi communication or mower safety logic is added.
