#!/usr/bin/env python3
"""Apply Phase-1 Gyroor G5 FOC integration to current Gen2.x-GD32.

This script intentionally checks the Git blob IDs of the upstream files it edits.
That prevents silently applying the patch to a materially different upstream tree.
Use --allow-upstream-drift only after manually reviewing the changed upstream files.
"""

from __future__ import annotations
import argparse
import hashlib
import re
import shutil
import subprocess
import sys
from pathlib import Path

EXPECTED = {
    "HoverBoardGigaDevice/Inc/config.h": "75aee4d4e25ed1e3366621120423b9005321d426",
    "HoverBoardGigaDevice/Inc/bldc.h": "8b450cbbca99cf964d7be1d0071a2fbfe2f8b8cb",
    "HoverBoardGigaDevice/Inc/defines.h": "683a72c7f4ab2f0e87b41670a75c5aa452724931",
    "HoverBoardGigaDevice/Inc/defines/defines_2-1-20.h": "b977d94ea58a34ce59f9ce8ecfb5761b0e4b7241",
    "HoverBoardGigaDevice/Src/setup.c": "5bbf6761749decc814ddd0ca49855f77b45e1317",
}

MARKER = "GYROOR_G5_FOC_PHASE1"


def git_blob_sha1(data: bytes) -> str:
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()


def checked_read(root: Path, rel: str, allow_drift: bool) -> str:
    path = root / rel
    data = path.read_bytes()
    if MARKER.encode() in data:
        return data.decode("utf-8")
    actual = git_blob_sha1(data)
    expected = EXPECTED[rel]
    if actual != expected and not allow_drift:
        raise RuntimeError(
            f"Upstream file changed; refusing automatic patch: {rel}\n"
            f" expected blob {expected}\n actual blob   {actual}\n"
            f"Review upstream changes, then rerun with --allow-upstream-drift if appropriate."
        )
    return data.decode("utf-8")


def backup_and_write(root: Path, rel: str, text: str) -> None:
    path = root / rel
    backup = path.with_suffix(path.suffix + ".phase1.bak")
    if not backup.exists():
        shutil.copy2(path, backup)
    path.write_text(text, encoding="utf-8", newline="")
    print(f"patched {rel}")


def require_replace(text: str, old: str, new: str, label: str, count: int = 1) -> str:
    found = text.count(old)
    if found < count:
        if MARKER in text:
            return text
        raise RuntimeError(f"Could not find expected upstream text for {label} (found {found})")
    return text.replace(old, new, count)


def patch_config(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Inc/config.h"
    text = checked_read(root, rel, allow_drift)
    if MARKER in text:
        print(f"already patched: {rel}")
        return

    anchor = "\t// choose your target in the dropdown list to the top-right of the Keil IDE\n"
    imu = f"""\t/* {MARKER}: compile-time IMU selection for layout 2.1.20. */
\t#define IMU_TYPE_MPU6050_OLD     1
\t#define IMU_TYPE_MPU6050_COMPAT  2
\t#define IMU_TYPE_MPU6500         3
\t#define IMU_TYPE_BMI160          4
\t#ifndef IMU_TYPE
\t\t#define IMU_TYPE IMU_TYPE_MPU6050_OLD
\t#endif
\n"""
    text = require_replace(text, anchor, imu + anchor, "config IMU selector")

    text, n = re.subn(
        r"(\t#ifdef GD32F130\t\t// TARGET = 1\r?\n)\t\t#define LAYOUT 1\r?\n\t\t#define LAYOUT_SUB 1[^\r\n]*",
        r"\1\t\t#define LAYOUT 20\n\t\t//#define LAYOUT_SUB 1\t// not used by layout 2.1.20",
        text,
        count=1,
    )
    if n != 1:
        raise RuntimeError("Could not select GD32F130 layout 20")

    old = """\t//#define BLDC_BC\t\t\t// old block commutation bldc control
\t#define BLDC_SINE\t\t\t// silent sine-pwm motor control, added 2025 by Robo Durden. 
\t//#define BLDC_SINE_BOOSTER\t\t// can boost speed by 15% starting from 87% throttle.
"""
    new = """\t//#define BLDC_BC\t\t\t// old block commutation bldc control
\t//#define BLDC_SINE\t\t\t// Gen2 sine backend
\t#define BLDC_FOC\t\t\t// GYROOR_G5_FOC_PHASE1: EFeru FOC backend adapter
\t//#define BLDC_SINE_BOOSTER\t\t// only applies to BLDC_SINE
"""
    text = require_replace(text, old, new, "BLDC_FOC selection")
    backup_and_write(root, rel, text)


def patch_layout(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Inc/defines/defines_2-1-20.h"
    text = checked_read(root, rel, allow_drift)
    if MARKER in text:
        print(f"already patched: {rel}")
        return

    pattern = re.compile(
        r"//#define MPU_6050[^\r\n]*\r?\n#define MPU_6050old\s*\r?\n#define I2C_PB6PB7[^\r\n]*"
    )
    replacement = f"""/* {MARKER}: keep all Gen2-supported IMU implementations selectable. */
#if IMU_TYPE == IMU_TYPE_MPU6050_OLD
\t#define MPU_6050old
#elif IMU_TYPE == IMU_TYPE_MPU6050_COMPAT
\t#define MPU_6050
#elif IMU_TYPE == IMU_TYPE_MPU6500
\t#define MPU_6500
#elif IMU_TYPE == IMU_TYPE_BMI160
\t#define BMI_160
#else
\t#error \"Unsupported IMU_TYPE for layout 2.1.20\"
#endif
#define I2C_PB6PB7\t// IMU bus on this layout"""
    text, n = pattern.subn(replacement, text, count=1)
    if n != 1:
        raise RuntimeError("Could not replace layout-20 IMU selection")
    backup_and_write(root, rel, text)


def patch_bldc_h(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Inc/bldc.h"
    text = checked_read(root, rel, allow_drift)
    if MARKER in text:
        print(f"already patched: {rel}")
        return
    old = """#if defined(BLDC_BC)
\t#include \"../Inc/bldcBC.h\"
#elif defined(BLDC_SINE)
\t#include \"../Inc/bldcSINE.h\"
#endif
"""
    new = """#if defined(BLDC_BC)
\t#include \"../Inc/bldcBC.h\"
#elif defined(BLDC_SINE)
\t#include \"../Inc/bldcSINE.h\"
#elif defined(BLDC_FOC) /* GYROOR_G5_FOC_PHASE1 */
\t#include \"../Inc/bldcFOC.h\"
#endif
"""
    text = require_replace(text, old, new, "bldc backend selector")
    backup_and_write(root, rel, text)


def patch_defines_h(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Inc/defines.h"
    text = checked_read(root, rel, allow_drift)
    if MARKER in text:
        print(f"already patched: {rel}")
        return
    old = """// ADC buffer struct
typedef struct
{
  uint16_t v_batt;
\tuint16_t current_dc;
\t#ifdef REMOTE_ADC
\t\tuint16_t speed;
\t\tuint16_t steer;
\t#endif
\t
} adc_buf_t;
"""
    new = """// ADC buffer struct
#ifdef BLDC_FOC /* GYROOR_G5_FOC_PHASE1 */
\t#if defined(REMOTE_ADC)
\t\t#error \"Phase-1 BLDC_FOC uses a 3-channel phase-current ADC scan and cannot be combined with REMOTE_ADC yet\"
\t#endif
\t#if !defined(VBATT) || !defined(PHASE_A) || !defined(PHASE_B)
\t\t#error \"BLDC_FOC requires VBATT, PHASE_A and PHASE_B in the board layout\"
\t#endif
\ttypedef struct
\t{
\t\tuint16_t v_batt;
\t\tuint16_t phase_a;
\t\tuint16_t phase_b;
\t} adc_buf_t;
#else
\ttypedef struct
\t{
\t  uint16_t v_batt;
\t\tuint16_t current_dc;
\t\t#ifdef REMOTE_ADC
\t\t\tuint16_t speed;
\t\t\tuint16_t steer;
\t\t#endif
\t} adc_buf_t;
#endif
"""
    text = require_replace(text, old, new, "FOC ADC buffer")
    backup_and_write(root, rel, text)


def patch_setup(root: Path, allow_drift: bool) -> None:
    rel = "HoverBoardGigaDevice/Src/setup.c"
    text = checked_read(root, rel, allow_drift)
    if MARKER in text:
        print(f"already patched: {rel}")
        return

    old_gpio = """\t\t#ifdef CURRENT_DC
\t\t\tpinMode(CURRENT_DC, GPIO_MODE_ANALOG);
\t\t#endif
\t\t#ifdef REMOTE_ADC
"""
    new_gpio = """\t\t#ifdef CURRENT_DC
\t\t\tpinMode(CURRENT_DC, GPIO_MODE_ANALOG);
\t\t#endif
\t\t#ifdef BLDC_FOC /* GYROOR_G5_FOC_PHASE1 */
\t\t\tpinMode(PHASE_A, GPIO_MODE_ANALOG);
\t\t\tpinMode(PHASE_B, GPIO_MODE_ANALOG);
\t\t#endif
\t\t#ifdef REMOTE_ADC
"""
    text = require_replace(text, old_gpio, new_gpio, "phase-current GPIO setup")

    old_adc = """\t\t#ifdef VBATT
\t\t\tTARGET_adc_regular_channel_config(0, PIN_TO_CHANNEL(VBATT), ADC_SAMPLETIME_13POINT5);
\t\t#endif
\t\t#ifdef CURRENT_DC
\t\t\tTARGET_adc_regular_channel_config(1, PIN_TO_CHANNEL(CURRENT_DC), ADC_SAMPLETIME_13POINT5);
\t\t#endif
\t\t#ifdef REMOTE_ADC
\t\t\tadc_regular_channel_config(2, PIN_TO_CHANNEL(PA2), ADC_SAMPLETIME_13POINT5);
\t\t\tadc_regular_channel_config(3, PIN_TO_CHANNEL(PA3), ADC_SAMPLETIME_13POINT5);
\t\t#endif
"""
    new_adc = """\t\t#ifdef BLDC_FOC /* GYROOR_G5_FOC_PHASE1 */
\t\t\t/* DMA order must exactly match the BLDC_FOC adc_buf_t. */
\t\t\tTARGET_adc_regular_channel_config(0, PIN_TO_CHANNEL(VBATT), ADC_SAMPLETIME_13POINT5);
\t\t\tTARGET_adc_regular_channel_config(1, PIN_TO_CHANNEL(PHASE_A), ADC_SAMPLETIME_13POINT5);
\t\t\tTARGET_adc_regular_channel_config(2, PIN_TO_CHANNEL(PHASE_B), ADC_SAMPLETIME_13POINT5);
\t\t#else
\t\t\t#ifdef VBATT
\t\t\t\tTARGET_adc_regular_channel_config(0, PIN_TO_CHANNEL(VBATT), ADC_SAMPLETIME_13POINT5);
\t\t\t#endif
\t\t\t#ifdef CURRENT_DC
\t\t\t\tTARGET_adc_regular_channel_config(1, PIN_TO_CHANNEL(CURRENT_DC), ADC_SAMPLETIME_13POINT5);
\t\t\t#endif
\t\t\t#ifdef REMOTE_ADC
\t\t\t\tadc_regular_channel_config(2, PIN_TO_CHANNEL(PA2), ADC_SAMPLETIME_13POINT5);
\t\t\t\tadc_regular_channel_config(3, PIN_TO_CHANNEL(PA3), ADC_SAMPLETIME_13POINT5);
\t\t\t#endif
\t\t#endif
"""
    idx = text.rfind(old_adc)
    if idx < 0:
        raise RuntimeError("Could not find active ADC channel setup")
    text = text[:idx] + new_adc + text[idx + len(old_adc):]
    backup_and_write(root, rel, text)


def install_overlay(bundle: Path, root: Path) -> None:
    overlay = bundle / "overlay"
    for src in overlay.rglob("*"):
        if not src.is_file():
            continue
        rel = src.relative_to(overlay)
        dst = root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        print(f"installed {rel}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("repo_root", help="Path to RoboDurden Hoverboard-Firmware-Hack-Gen2.x-GD32 checkout")
    ap.add_argument("--allow-upstream-drift", action="store_true")
    ap.add_argument("--skip-vendor", action="store_true", help="do not download pinned EFeru core")
    ns = ap.parse_args()

    root = Path(ns.repo_root).resolve()
    bundle = Path(__file__).resolve().parent
    if not (root / "HoverBoardGigaDevice" / "Inc" / "defines.h").is_file():
        raise SystemExit(f"Not a Gen2.x-GD32 checkout: {root}")

    try:
        patch_config(root, ns.allow_upstream_drift)
        patch_layout(root, ns.allow_upstream_drift)
        patch_bldc_h(root, ns.allow_upstream_drift)
        patch_defines_h(root, ns.allow_upstream_drift)
        patch_setup(root, ns.allow_upstream_drift)
        install_overlay(bundle, root)
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    if not ns.skip_vendor:
        vendor = bundle / "vendor_eferu_foc.py"
        rc = subprocess.call([sys.executable, str(vendor), str(root)])
        if rc:
            return rc

    print("\nPhase-1 source integration applied.")
    print("IMPORTANT: FOC_SAFE_BRINGUP=1 forces all phase outputs to zero.")
    print("Build/size-check next; do not remove SAFE_BRINGUP until current/Hall/phase validation is complete.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
