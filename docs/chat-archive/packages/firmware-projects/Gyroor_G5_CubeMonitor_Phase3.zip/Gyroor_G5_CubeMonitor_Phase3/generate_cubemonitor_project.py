#!/usr/bin/env python3
"""
Generate STM32CubeMonitor importable flow JSON files for the Gyroor G5
Gen2.1.20 + EFeru FOC Phase-3 firmware.

The final RAM addresses are linker-dependent, so this generator reads the
symbol table from the compiled Keil .AXF or GCC/Clang .ELF and writes the
addresses into CubeMonitor custom-variable entries.

No third-party Python modules are required for normal ELF32 little-endian
AXF/ELF files with a symbol table.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import struct
import sys
from pathlib import Path
from typing import Dict, List, Tuple

# STM32CubeMonitor custom variable type numbers.
TYPE_U8  = "1"
TYPE_S8  = "2"
TYPE_U16 = "3"
TYPE_S16 = "4"
TYPE_U32 = "5"
TYPE_S32 = "6"
TYPE_FLOAT = "9"
TYPE_DOUBLE = "10"

TYPE_SIZE = {
    TYPE_U8: 1, TYPE_S8: 1,
    TYPE_U16: 2, TYPE_S16: 2,
    TYPE_U32: 4, TYPE_S32: 4,
    TYPE_FLOAT: 4, TYPE_DOUBLE: 8,
}

# display_name, ELF symbol, offset, CubeMonitor type, category, required
SPECS = [
    # ADC/current bring-up
    ("foc_adc_phase_a_raw",       "foc_adc_phase_a_raw",       0, TYPE_U16, "raw_adc", True),
    ("foc_adc_phase_b_raw",       "foc_adc_phase_b_raw",       0, TYPE_U16, "raw_adc", True),
    ("foc_adc_phase_a_offset",    "foc_adc_phase_a_offset",    0, TYPE_S16, "raw_adc", True),
    ("foc_adc_phase_b_offset",    "foc_adc_phase_b_offset",    0, TYPE_S16, "raw_adc", True),
    ("adc_v_batt_raw",            "adc_buffer",                 0, TYPE_U16, "raw_adc", True),
    ("foc_adc_motor_ntc_raw",     "foc_adc_motor_ntc_raw",     0, TYPE_U16, "ntc_adc", True),
    ("cap_motor_ntc_filtered_raw", "cap_motor_ntc_filtered_raw",0, TYPE_U16, "ntc_adc", True),

    # Human-scale current/capability values: 0.01 A
    ("cap_current_rms_centiamp",       "cap_current_rms_centiamp",       0, TYPE_U16, "current_limits", True),
    ("cap_absolute_limit_centiamp",    "cap_absolute_limit_centiamp",    0, TYPE_U16, "current_limits", True),
    ("cap_thermal_limit_centiamp",     "cap_thermal_limit_centiamp",     0, TYPE_U16, "current_limits", True),
    ("cap_battery_limit_centiamp",     "cap_battery_limit_centiamp",     0, TYPE_U16, "current_limits", True),
    ("cap_temperature_limit_centiamp", "cap_temperature_limit_centiamp", 0, TYPE_U16, "current_limits", True),
    ("cap_motor_ntc_limit_centiamp",   "cap_motor_ntc_limit_centiamp",   0, TYPE_U16, "current_limits", True),
    ("cap_global_limit_centiamp",      "cap_global_limit_centiamp",      0, TYPE_U16, "current_limits", True),
    ("cap_profile_limit_centiamp",     "cap_profile_limit_centiamp",     0, TYPE_U16, "current_limits", True),
    ("cap_effective_limit_centiamp",   "cap_effective_limit_centiamp",   0, TYPE_U16, "current_limits", True),

    # Motor thermal model / tentative NTC
    ("cap_motor_ntc_ohm",          "cap_motor_ntc_ohm",          0, TYPE_U32, "ntc_ohm", True),
    ("cap_thermal_load_permille",  "cap_thermal_load_permille",  0, TYPE_U16, "thermal", True),

    # State/faults
    ("foc_offsets_ready",          "foc_offsets_ready",          0, TYPE_U8,  "status", True),
    ("cap_current_sensor_valid",   "cap_current_sensor_valid",   0, TYPE_U8,  "status", True),
    ("cap_motor_ntc_valid",        "cap_motor_ntc_valid",        0, TYPE_U8,  "status", True),
    ("cap_profile",                "cap_profile",                0, TYPE_U8,  "status", True),
    ("cap_fault_flags",            "cap_fault_flags",            0, TYPE_U8,  "status", True),
    ("foc_error",                  "foc_error",                  0, TYPE_U8,  "status", True),
    ("bldc_enable",                "bldc_enable",                0, TYPE_U32, "status", False),
    ("hall_a",                     "hall_a",                     0, TYPE_U8,  "status", False),
    ("hall_b",                     "hall_b",                     0, TYPE_U8,  "status", False),
    ("hall_c",                     "hall_c",                     0, TYPE_U8,  "status", False),

    # Deeper FOC diagnostics
    ("foc_current_a_model",        "foc_current_a_model",        0, TYPE_S16, "foc_current", True),
    ("foc_current_b_model",        "foc_current_b_model",        0, TYPE_S16, "foc_current", True),
    ("foc_iq_raw",                 "foc_iq_raw",                 0, TYPE_S16, "foc_current", True),
    ("foc_id_raw",                 "foc_id_raw",                 0, TYPE_S16, "foc_current", True),
    ("foc_target_model",           "foc_target_model",           0, TYPE_S16, "foc_control", True),
    ("foc_dynamic_i_max_q4",       "foc_dynamic_i_max_q4",       0, TYPE_U16, "foc_control", True),
    ("foc_speed_rpm_x16",          "foc_speed_rpm_x16",          0, TYPE_S16, "foc_speed", True),
    ("foc_out_phase_a",            "foc_out_phase_a",            0, TYPE_S16, "foc_output", True),
    ("foc_out_phase_b",            "foc_out_phase_b",            0, TYPE_S16, "foc_output", True),
    ("foc_out_phase_c",            "foc_out_phase_c",            0, TYPE_S16, "foc_output", True),
]

ESSENTIAL_CATEGORIES = {"raw_adc", "ntc_adc", "current_limits", "ntc_ohm", "thermal", "status"}
DEEP_CATEGORIES = ESSENTIAL_CATEGORIES | {"foc_current", "foc_control", "foc_speed", "foc_output"}

CHARTS_ESSENTIAL = [
    ("Current and capability (0.01 A)", "current_limits", 30),
    ("Motor NTC resistance (ohm)", "ntc_ohm", 60),
    ("Motor NTC ADC (counts)", "ntc_adc", 60),
    ("Thermal load (permille)", "thermal", 120),
    ("Phase-current / battery ADC (counts)", "raw_adc", 20),
    ("Status, faults and Hall states", "status", 30),
]

CHARTS_DEEP = CHARTS_ESSENTIAL + [
    ("FOC current model / Id / Iq (model counts)", "foc_current", 20),
    ("FOC target and dynamic i_max Q4", "foc_control", 20),
    ("FOC speed (RPM x16)", "foc_speed", 20),
    ("FOC three-phase outputs", "foc_output", 10),
]


def parse_elf32_symbols(path: Path) -> Dict[str, Tuple[int, int]]:
    data = path.read_bytes()
    if len(data) < 52 or data[:4] != b"\x7fELF":
        raise ValueError(f"{path} is not an ELF/AXF file")
    if data[4] != 1:
        raise ValueError("Only ELF32 is supported by the dependency-free parser")
    if data[5] != 1:
        raise ValueError("Only little-endian ELF is supported")

    # ELF32 little-endian header fields we need.
    e_shoff = struct.unpack_from("<I", data, 32)[0]
    e_shentsize = struct.unpack_from("<H", data, 46)[0]
    e_shnum = struct.unpack_from("<H", data, 48)[0]
    if e_shentsize < 40 or e_shoff == 0 or e_shnum == 0:
        raise ValueError("ELF has no usable section table")

    sections = []
    for i in range(e_shnum):
        off = e_shoff + i * e_shentsize
        if off + 40 > len(data):
            raise ValueError("ELF section table is truncated")
        sh = struct.unpack_from("<IIIIIIIIII", data, off)
        sections.append({
            "name": sh[0], "type": sh[1], "flags": sh[2], "addr": sh[3],
            "offset": sh[4], "size": sh[5], "link": sh[6], "info": sh[7],
            "addralign": sh[8], "entsize": sh[9],
        })

    symbols: Dict[str, Tuple[int, int]] = {}
    for sec in sections:
        if sec["type"] not in (2, 11):  # SHT_SYMTAB / SHT_DYNSYM
            continue
        link = sec["link"]
        if link >= len(sections):
            continue
        strsec = sections[link]
        strtab = data[strsec["offset"]:strsec["offset"] + strsec["size"]]
        entsize = sec["entsize"] or 16
        if entsize < 16:
            continue
        count = sec["size"] // entsize
        for i in range(count):
            off = sec["offset"] + i * entsize
            if off + 16 > len(data):
                break
            st_name, st_value, st_size, st_info, st_other, st_shndx = struct.unpack_from("<IIIBBH", data, off)
            if st_name == 0 or st_shndx == 0:
                continue
            if st_name >= len(strtab):
                continue
            end = strtab.find(b"\0", st_name)
            if end < 0:
                continue
            name = strtab[st_name:end].decode("utf-8", errors="replace")
            if not name:
                continue
            # Prefer a nonzero, defined data symbol when duplicates occur.
            prev = symbols.get(name)
            if prev is None or (prev[0] == 0 and st_value != 0):
                symbols[name] = (st_value, st_size)
    if not symbols:
        raise ValueError("No symbol table found. Build the AXF/ELF with debug/symbol information and do not strip it.")
    return symbols


def node_id(seed: str) -> str:
    # 16 hex chars works with modern Node-RED and is deterministic.
    return hashlib.sha1(seed.encode("utf-8")).hexdigest()[:16]


def variable_entries(symbols: Dict[str, Tuple[int, int]], categories: set) -> Tuple[List[dict], List[Tuple[str, str, int, str, str, bool]], List[str]]:
    entries = []
    resolved_specs = []
    missing_required = []
    for display, sym, offset, typ, cat, required in SPECS:
        if cat not in categories:
            continue
        if sym not in symbols:
            if required:
                missing_required.append(sym)
            continue
        addr = symbols[sym][0] + offset
        entries.append({"name": display, "address": f"0x{addr:08X}", "type": typ})
        resolved_specs.append((display, sym, offset, typ, cat, required))
    return entries, resolved_specs, missing_required


def make_filter_node(tab_id: str, chart_id: str, varname: str, x: int, y: int) -> dict:
    fid = node_id(f"filter:{tab_id}:{varname}")
    return {
        "id": fid,
        "type": "switch",
        "z": tab_id,
        "name": varname,
        "property": "payload.variablename",
        "propertyType": "msg",
        "rules": [{"t": "eq", "v": varname, "vt": "str"}],
        "checkall": "true",
        "repair": False,
        "outputs": 1,
        "x": x,
        "y": y,
        "wires": [[chart_id]],
    }


def build_flow(flow_name: str, variable_entries_list: List[dict], resolved_specs, charts_def) -> List[dict]:
    tab_id = node_id(flow_name + ":tab")
    ui_tab_id = node_id(flow_name + ":uitab")
    controls_group_id = node_id(flow_name + ":controls")
    variables_id = node_id(flow_name + ":variables")
    acq_out_id = node_id(flow_name + ":acqout")
    acq_in_id = node_id(flow_name + ":acqin")
    processing_id = node_id(flow_name + ":processing")
    start_id = node_id(flow_name + ":start")
    stop_id = node_id(flow_name + ":stop")
    clear_id = node_id(flow_name + ":clear")
    dbg_acq_id = node_id(flow_name + ":dbgacq")
    dbg_proc_id = node_id(flow_name + ":dbgproc")

    nodes: List[dict] = [
        {"id": tab_id, "type": "tab", "label": flow_name, "disabled": False,
         "info": "Gyroor G5 Gen2.1.20 + EFeru FOC Phase-3 monitoring flow. Select the same ST-Link in Probe OUT and Probe IN before deployment."},
        {"id": ui_tab_id, "type": "ui_tab", "name": flow_name, "icon": "dashboard", "disabled": False, "hidden": False},
        {"id": controls_group_id, "type": "ui_group", "name": "Acquisition", "tab": ui_tab_id,
         "order": 1, "disp": True, "width": 12, "collapse": False},
        {"id": acq_out_id, "type": "acquisition out", "z": tab_id, "name": "G5 Probe OUT - SELECT ST-LINK",
         "probeconfig": "", "x": 600, "y": 100, "wires": []},
        {"id": acq_in_id, "type": "acquisition in", "z": tab_id, "name": "G5 Probe IN - SELECT SAME ST-LINK",
         "probeconfig": "", "x": 120, "y": 340, "wires": [[processing_id], [dbg_acq_id]]},
        {"id": variables_id, "type": "variables", "z": tab_id, "groupname": "G5_Phase3",
         "accesspoint": 0, "execonfig": "", "variablelist": variable_entries_list,
         "triggerstartmode": "manual", "triggername": "", "triggerthreshold": "",
         "frequency": "", "frequencyType": "0", "snapshotheader": "", "mode": "direct",
         "lastImportedTime": -1, "openStatus": True, "x": 350, "y": 100,
         "wires": [[acq_out_id]]},
        {"id": start_id, "type": "ui_button", "z": tab_id, "name": "", "group": controls_group_id,
         "order": 1, "width": 4, "height": 1, "passthru": False, "label": "START Acquisition",
         "tooltip": "", "color": "", "bgcolor": "", "icon": "", "payload": "", "payloadType": "str",
         "topic": "start", "x": 120, "y": 80, "wires": [[variables_id]]},
        {"id": stop_id, "type": "ui_button", "z": tab_id, "name": "", "group": controls_group_id,
         "order": 2, "width": 4, "height": 1, "passthru": True, "label": "STOP Acquisition",
         "tooltip": "", "color": "", "bgcolor": "", "icon": "", "payload": "", "payloadType": "str",
         "topic": "stop", "x": 120, "y": 130, "wires": [[variables_id]]},
        {"id": clear_id, "type": "ui_button", "z": tab_id, "name": "", "group": controls_group_id,
         "order": 3, "width": 4, "height": 1, "passthru": False, "label": "Clear Graphs",
         "tooltip": "", "color": "", "bgcolor": "", "icon": "", "payload": "", "payloadType": "str",
         "topic": "clear", "x": 120, "y": 180, "wires": [[]]},
        {"id": processing_id, "type": "processing", "z": tab_id, "groupname": "G5_Phase3",
         "groupid": variables_id, "expressions": [], "statistics": [], "logmode": "no", "logformat": "stcm",
         "x": 350, "y": 340, "wires": [[], [dbg_proc_id]]},
        {"id": dbg_acq_id, "type": "debug", "z": tab_id, "name": "Acquisition errors", "active": True,
         "tosidebar": True, "console": False, "tostatus": False, "complete": "true", "targetType": "full",
         "x": 380, "y": 420, "wires": []},
        {"id": dbg_proc_id, "type": "debug", "z": tab_id, "name": "Processing errors", "active": True,
         "tosidebar": True, "console": False, "tostatus": False, "complete": "true", "targetType": "full",
         "x": 620, "y": 420, "wires": []},
        {"id": node_id(flow_name + ":comment1"), "type": "comment", "z": tab_id,
         "name": "Before Deploy: open BOTH probe nodes and select the same ST-Link. Start at 400 kHz SWD; use 150 kHz if unstable.",
         "info": "NRST is not required for this monitoring flow. Power the controller normally from the battery/bench-supply side.",
         "x": 550, "y": 40, "wires": []},
        {"id": node_id(flow_name + ":comment2"), "type": "comment", "z": tab_id,
         "name": "SAFE_BRINGUP must remain 1 for the first sessions.", "info": "Phase outputs are forced to zero by the Phase-3 firmware while SAFE_BRINGUP is enabled.",
         "x": 330, "y": 240, "wires": []},
    ]

    # Map category -> resolved display variable names.
    cat_names: Dict[str, List[str]] = {}
    for display, sym, offset, typ, cat, required in resolved_specs:
        cat_names.setdefault(cat, []).append(display)

    chart_ids = []
    proc_targets = []
    y_base = 500
    group_order = 2
    for idx, (title, category, duration) in enumerate(charts_def):
        names = cat_names.get(category, [])
        if not names:
            continue
        group_id = node_id(f"{flow_name}:group:{category}")
        chart_id = node_id(f"{flow_name}:chart:{category}")
        chart_ids.append(chart_id)
        nodes.append({"id": group_id, "type": "ui_group", "name": title, "tab": ui_tab_id,
                      "order": group_order, "disp": True, "width": 12, "collapse": False})
        group_order += 1
        nodes.append({"id": chart_id, "type": "ui_chartst", "z": tab_id, "group": group_id,
                      "name": title, "order": 1, "width": 12, "height": 6, "chartType": "line",
                      "curveType": "linear", "duration": str(duration), "ymin": "", "ymax": "",
                      "x": 950, "y": y_base + idx * 150, "wires": []})
        for j, name in enumerate(names):
            sw = make_filter_node(tab_id, chart_id, name, 650, y_base + idx * 150 + j * 22)
            nodes.append(sw)
            proc_targets.append(sw["id"])

    # Wire processing output to every filter; clear to every chart.
    for n in nodes:
        if n.get("id") == processing_id:
            n["wires"][0] = proc_targets
        if n.get("id") == clear_id:
            n["wires"][0] = chart_ids

    return nodes


def write_address_csv(path: Path, entries: List[dict]):
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["name", "address", "cubemonitor_type"])
        for e in entries:
            w.writerow([e["name"], e["address"], e["type"]])


def main() -> int:
    ap = argparse.ArgumentParser(description="Generate STM32CubeMonitor flows for Gyroor G5 Phase-3 FOC firmware")
    ap.add_argument("elf", type=Path, help="Compiled Hoverboard.axf or .elf with symbols")
    ap.add_argument("-o", "--output-dir", type=Path, default=Path("CubeMonitor_Generated"), help="Output directory")
    args = ap.parse_args()

    try:
        symbols = parse_elf32_symbols(args.elf)
    except Exception as e:
        print(f"ERROR reading symbols: {e}", file=sys.stderr)
        return 2

    args.output_dir.mkdir(parents=True, exist_ok=True)

    all_entries, all_specs, missing_deep = variable_entries(symbols, DEEP_CATEGORIES)
    ess_entries, ess_specs, missing_ess = variable_entries(symbols, ESSENTIAL_CATEGORIES)

    # Deduplicate missing symbols while preserving order.
    missing_ess = list(dict.fromkeys(missing_ess))
    missing_deep = list(dict.fromkeys(missing_deep))
    if missing_ess:
        print("ERROR: required Phase-3 symbols were not found:", file=sys.stderr)
        for s in missing_ess:
            print(f"  {s}", file=sys.stderr)
        print("Build the Phase-3 firmware with symbols/debug info and do not strip the AXF/ELF.", file=sys.stderr)
        return 3

    essential_flow = build_flow("Gyroor G5 - Bringup", ess_entries, ess_specs, CHARTS_ESSENTIAL)
    deep_flow = build_flow("Gyroor G5 - Deep Diagnostics", all_entries, all_specs, CHARTS_DEEP)

    essential_path = args.output_dir / "Gyroor_G5_Bringup_Monitor.json"
    deep_path = args.output_dir / "Gyroor_G5_Deep_Diagnostics_Monitor.json"
    csv_path = args.output_dir / "Gyroor_G5_Monitor_Addresses.csv"

    essential_path.write_text(json.dumps(essential_flow, indent=2), encoding="utf-8")
    deep_path.write_text(json.dumps(deep_flow, indent=2), encoding="utf-8")
    write_address_csv(csv_path, all_entries)

    optional_missing = []
    for display, sym, offset, typ, cat, required in SPECS:
        if not required and sym not in symbols:
            optional_missing.append(sym)

    print(f"Generated: {essential_path}")
    print(f"Generated: {deep_path}")
    print(f"Generated: {csv_path}")
    print(f"Bring-up variables: {len(ess_entries)}")
    print(f"Deep variables: {len(all_entries)}")
    if optional_missing:
        print("Optional symbols not present (flow still valid): " + ", ".join(sorted(set(optional_missing))))
    if missing_deep:
        # This would only be non-essential deep symbols; currently deep FOC globals are required.
        print("Warning: some deep-diagnostic symbols were missing: " + ", ".join(missing_deep))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
