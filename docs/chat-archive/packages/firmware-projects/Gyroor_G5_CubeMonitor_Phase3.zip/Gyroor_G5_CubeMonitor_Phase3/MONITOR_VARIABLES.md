# Monitor variable checklist

## First power-up / SAFE_BRINGUP

| Variable | Type | Units | What we want to see |
|---|---|---|---|
| `foc_offsets_ready` | u8 | boolean | 0 then 1 after current-offset calibration |
| `foc_adc_phase_a_raw` | u16 | ADC counts | stable, not near 0/4095 |
| `foc_adc_phase_b_raw` | u16 | ADC counts | stable, not near 0/4095 |
| `foc_adc_phase_a_offset` | s16 | ADC counts | near phase-A raw at zero current |
| `foc_adc_phase_b_offset` | s16 | ADC counts | near phase-B raw at zero current |
| `cap_current_sensor_valid` | u8 | boolean | 1 after offsets are ready |
| `cap_current_rms_centiamp` | u16 | 0.01 A | near zero with bridge disabled |
| `cap_motor_ntc_ohm` | u32 | ohm | finite and physically responsive if PA6 is motor NTC |
| `cap_motor_ntc_valid` | u8 | boolean | 1 for a valid divider reading |
| `cap_fault_flags` | u8 | bitfield | normally 0 after initialization, except tentative NTC issues |
| `foc_error` | u8 | EFeru error | 0 |
| `cap_thermal_load_permille` | u16 | per-mille | near 0 with no motor current |
| `cap_effective_limit_centiamp` | u16 | 0.01 A | current allowed by all common limits + profile |

## Hand-turn motor tests

Use the optional Hall signals if the linker exports them:

- `hall_a`
- `hall_b`
- `hall_c`

They should step through valid 3-bit Hall combinations as the wheel is rotated by hand.

## After current scale/polarity is calibrated

Use the Deep Diagnostics flow to compare:

- `foc_current_a_model`
- `foc_current_b_model`
- `foc_iq_raw`
- `foc_id_raw`
- `foc_target_model`
- `foc_dynamic_i_max_q4`
- `foc_out_phase_a`, `foc_out_phase_b`, `foc_out_phase_c`
- `foc_speed_rpm_x16`

Do not remove `FOC_SAFE_BRINGUP` until phase-current polarity, Hall order, phase order, current scaling, and the NTC input have been checked.
