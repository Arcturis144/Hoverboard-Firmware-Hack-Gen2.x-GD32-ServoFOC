# Gyroor G5 STM32CubeMonitor project — Phase 3

This package creates STM32CubeMonitor flows for the **Gyroor G5 / OLSZ OL20180703-V4.1**, using the Phase-3 Gen2.1.20 + EFeru FOC integration.

## Why this is generated after the firmware build

CubeMonitor's custom-variable entries contain **absolute RAM addresses**. Those addresses are assigned by the linker and can change whenever the firmware is rebuilt. Therefore this package reads the final `.axf`/`.elf` symbol table and generates a monitor flow whose addresses exactly match that firmware build.

No placeholder RAM addresses are used.

## Generate the flows

Build the Phase-3 firmware with symbols/debug information retained. Keil's normal `.axf` output is an ELF file and is supported.

Windows:

```text
py generate_cubemonitor_project.py C:\path\to\Hoverboard.axf
```

Linux:

```text
python3 generate_cubemonitor_project.py /path/to/Hoverboard.axf
```

By default this creates:

```text
CubeMonitor_Generated/
  Gyroor_G5_Bringup_Monitor.json
  Gyroor_G5_Deep_Diagnostics_Monitor.json
  Gyroor_G5_Monitor_Addresses.csv
```

The generator has a dependency-free ELF32 parser, so `pyelftools` is not required.

## Which flow to use first

Start with **Gyroor_G5_Bringup_Monitor.json**. It contains the variables needed for the non-driving first tests without adding all of the deeper FOC signals to the SWD acquisition load.

Use **Gyroor_G5_Deep_Diagnostics_Monitor.json** after the connection is stable or when we specifically need Id/Iq, FOC outputs, target or speed information.

## Import into STM32CubeMonitor

1. Import the generated `.json` flow.
2. Open `G5 Probe OUT - SELECT ST-LINK` and select your ST-Link.
3. Open `G5 Probe IN - SELECT SAME ST-LINK` and select the **same** ST-Link.
4. Use **SWD**. Start at **400 kHz**; if the connection is unreliable, use **150 kHz**.
5. Power the controller normally from its battery/bench-supply input. Do not power the controller from the ST-Link 3.3 V pin.
6. Deploy the flow.
7. Open Dashboard and click `START Acquisition`.

NRST is not required for this monitor flow.

For the first sessions keep:

```c
#define FOC_SAFE_BRINGUP 1
```

so the firmware executes the ADC/current/NTC/capability/FOC logic while the phase output remains forced to zero.

## Bring-up dashboard

### Current and capability — units are 0.01 A

`cap_current_rms_centiamp` is reconstructed three-phase RMS motor current. A displayed value of `125` means **1.25 A**.

The limit traces show why the controller is limiting torque:

- `cap_absolute_limit_centiamp`
- `cap_thermal_limit_centiamp`
- `cap_battery_limit_centiamp`
- `cap_temperature_limit_centiamp` — reserved second temperature input, currently disabled
- `cap_motor_ntc_limit_centiamp`
- `cap_global_limit_centiamp`
- `cap_profile_limit_centiamp`
- `cap_effective_limit_centiamp`

With the current Phase-3 bring-up configuration, after current-offset calibration and with a cool/valid NTC, Normal profile should settle around an effective preference of **325 = 3.25 A**, because Normal requests 65% of the temporary 5.00 A absolute ceiling. This is still only a bring-up limit, not the final hardware rating.

### Motor NTC

- `cap_motor_ntc_ohm`: calculated resistance in ohms.
- `foc_adc_motor_ntc_raw`: instantaneous PA6 ADC value.
- `cap_motor_ntc_filtered_raw`: filtered PA6 value used by the capability manager.

Tentative Phase-3 behavior, based on the factory firmware:

```text
>= 8000 ohm : no NTC derating
8000..6000  : progressively reduced current ceiling
<= 6000 ohm : NTC current ceiling reaches zero
```

We have not assigned Celsius values yet; first we need to physically confirm the extra motor wire/NTC and characterize its resistance curve.

### Current-sensor bring-up

- `foc_adc_phase_a_raw`
- `foc_adc_phase_b_raw`
- `foc_adc_phase_a_offset`
- `foc_adc_phase_b_offset`
- `adc_v_batt_raw` — generated from `adc_buffer + 0`

With the bridge disabled and no motor current, phase A/B raw values should settle close to their measured offsets.

`foc_offsets_ready` should transition from 0 to 1 after startup calibration. The Phase-3 configuration averages 2000 control samples; at the intended 16 kHz control rate this is roughly 125 ms.

### Thermal model

`cap_thermal_load_permille` is the current-derived I-squared thermal state:

```text
0       = cold model
700     = start of thermal-limit reduction
1000    = hard-model region
1250    = thermal cutoff
```

The model is global to every drive mode. The actual permitted current is the minimum of the hard ceiling, I² thermal model, motor NTC, battery/other temperature limits, and the selected profile preference.

### Status/fault variables

Important expected state after initialization:

```text
foc_offsets_ready          = 1
cap_current_sensor_valid   = 1
foc_error                  = 0
```

`cap_motor_ntc_valid` should become 1 if PA6 is connected to a valid resistive divider. During the current tentative stage, an invalid NTC raises a flag but does not force zero torque because `CAP_MOTOR_NTC_REQUIRE_VALID` remains 0.

`cap_fault_flags` bit meanings:

```text
0x01  current offsets not ready
0x02  phase-current ADC at/near rail
0x04  I² thermal model at hard cutoff
0x08  battery low              (battery derating currently disabled)
0x10  second temperature high  (second temperature input currently disabled)
0x20  PA6 motor NTC invalid
0x40  PA6 motor NTC at/below cutoff resistance
```

`cap_profile`:

```text
0 = Normal
1 = Snow
2 = Boost
```

If the base Gen2 symbols are present, the flow also displays `hall_a`, `hall_b`, `hall_c`, and `bldc_enable`. They are treated as optional by the generator because their exact visibility can depend on the upstream build.

## Deep diagnostics flow

The Deep Diagnostics flow adds:

- `foc_current_a_model`
- `foc_current_b_model`
- `foc_iq_raw`
- `foc_id_raw`
- `foc_target_model`
- `foc_dynamic_i_max_q4`
- `foc_speed_rpm_x16`
- `foc_out_phase_a/b/c`

These are mainly for validating current polarity, Hall/phase order and EFeru FOC behavior after the basic ADC/NTC/current-offset path is proven.

Useful scale references:

```text
FOC current model:       50 counts = 1 A
foc_speed_rpm_x16:       16 counts = 1 RPM
foc_dynamic_i_max_q4:    800 counts = 1 A
centiamp variables:      100 counts = 1 A
```

## Regenerate after every firmware link

Whenever code changes and the firmware is relinked, rerun the generator against the new `.axf`/`.elf`. The flow contains absolute addresses and should always match the exact image that is flashed.
