Blue Pill hoverboard UART sniffer v6 - STM32duino 3.0.0 / 64K build
============================================================================

This revision is specifically intended to fit the official 64 KiB flash size
of an STM32F103C8.

The v5 build overflowed FLASH by 6168 bytes when compiled with -Og.
Two changes are made here:

1. Use:
     Optimize -> Smallest (-Os default)
   rather than Debug (-Og).

2. The baud detector was rewritten to use integer arithmetic only.
   It no longer uses float/fabsf or float printing, which avoids pulling
   unnecessary floating-point support into flash.

EXACT SETTINGS
--------------
Board:
  Generic STM32F1 series

Board part number:
  BluePill F103C8

U(S)ART support:
  Enabled (no generic 'Serial')

USB support:
  CDC (generic 'Serial' supersede U(S)ART)

USB speed:
  Low/Full Speed

Optimize:
  Smallest (-Os default)

Debug symbols and core logs:
  Symbols Enabled (-g)
  Do NOT choose Core Logs.

C Runtime Library:
  Newlib Nano (default)

Upload method:
  STM32CubeProgrammer (SWD)

Why keep "Symbols Enabled (-g)"?
The STM32 core 3.0.0 menu also adds -DNDEBUG for that selection. This prevents
core debug logging from being compiled onto the board's default UART TX pin,
PA9. Debug symbols themselves live primarily in the ELF debug sections and
are not programmed into normal flash.

PASSIVE CONNECTIONS
-------------------
Hoverboard MASTER PA2 TX -> Blue Pill PA10
Hoverboard SLAVE  PA2 TX -> Blue Pill PA3
Hoverboard GND           -> Blue Pill GND

Leave Blue Pill PA9 and PA2 unconnected to the hoverboard for now.
