/*
  BluePill_Hoverboard_UART_MITM_v9_C6.ino

  Transparent full-duplex UART man-in-the-middle bridge for the stock
  Gyroor G5 / OL20180703-V4.1 master <-> slave link.

  Target: STM32F103C6 Blue Pill (32 KiB flash / 10 KiB RAM)
  Framework: STM32duino / STMicroelectronics Arduino_Core_STM32 3.0.0

  Factory UART already measured/verified:
    115200 baud, 8-N-1

  IMPORTANT: this is INLINE, not passive sniffing. The two original UART
  signal conductors between master and slave MUST be broken/intercepted.
  Keep the other non-UART harness conductors connected straight through.

  MASTER-facing Blue Pill port (USART1):
    Master TX  -> PA10  (USART1 RX)
    Master RX  <- PA9   (USART1 TX)

  SLAVE-facing Blue Pill port (USART2):
    Slave TX   -> PA3   (USART2 RX)
    Slave RX   <- PA2   (USART2 TX)

  Common hoverboard GND -> Blue Pill GND
  Do NOT connect hoverboard 3.3 V to Blue Pill 3.3 V.
  Power the Blue Pill from USB before powering the hoverboard boards.

  Data path:
    Master TX -> PA10 -> USART1 RX -> USART2 TX -> PA2 -> Slave RX
    Slave TX  -> PA3  -> USART2 RX -> USART1 TX -> PA9 -> Master RX

  Native USB CDC on PA11/PA12 logs traffic to the PC. Bridging continues
  even if USB Serial Monitor is not open.
*/

#include <Arduino.h>

// ----- Required STM32duino 3.0.0 menu configuration checks -----
#if !defined(HAL_UART_MODULE_ENABLED)
  #error "Set Tools > U(S)ART support to: Enabled (no generic 'Serial')"
#endif

#if !defined(HWSERIAL_NONE)
  #error "Set Tools > U(S)ART support to: Enabled (no generic 'Serial') so the core does not also create Serial1."
#endif

#if !defined(USBCON) || !defined(USBD_USE_CDC)
  #error "Set Tools > USB support to: CDC (generic 'Serial' supersede U(S)ART)"
#endif

#if defined(DISABLE_GENERIC_SERIALUSB)
  #error "Select Tools > USB support: CDC (generic 'Serial' supersede U(S)ART)"
#endif

#if !defined(NDEBUG)
  #error "Set Tools > Debug symbols and core logs to: Symbols Enabled (-g). Do not enable Core Logs."
#endif

#define LOG_PORT Serial

static const uint32_t LINK_BAUD = 115200;
static const uint32_t FRAME_GAP_US = 434;  // 50 bit-times at 115200 baud

// STM32duino core 3.0.0 concrete serial class is Uart.
// Constructor order is RX, TX.
Uart MasterSide((pin_size_t)PA10, (pin_size_t)PA9); // USART1, faces MASTER
Uart SlaveSide ((pin_size_t)PA3,  (pin_size_t)PA2); // USART2, faces SLAVE

// Normal stock packets observed so far are 17 bytes. 64 bytes leaves room
// for other packet types while keeping RAM use small on the F103C6.
struct CaptureFrame {
  uint8_t data[64];
  uint8_t len;
  uint32_t firstUs;
  uint32_t lastUs;
};

CaptureFrame m2sFrame = {{0}, 0, 0, 0};
CaptureFrame s2mFrame = {{0}, 0, 0, 0};

uint32_t m2sBytes = 0;
uint32_t s2mBytes = 0;
uint32_t droppedLogBytes = 0;

static void printHexByte(uint8_t v)
{
  static const char hex[] = "0123456789ABCDEF";
  LOG_PORT.write(hex[(v >> 4) & 0x0F]);
  LOG_PORT.write(hex[v & 0x0F]);
}

static void flushFrame(CaptureFrame &f, const char *direction)
{
  if (f.len == 0) return;

  // Logging must never be required for forwarding. If USB CDC is not open,
  // discard only the display copy; the UART bridge has already forwarded it.
  if (!LOG_PORT) {
    f.len = 0;
    return;
  }

  LOG_PORT.print(f.firstUs);
  LOG_PORT.print(" us  ");
  LOG_PORT.print(direction);
  LOG_PORT.print("  [");
  LOG_PORT.print(f.len);
  LOG_PORT.print("]  ");

  for (uint8_t i = 0; i < f.len; i++) {
    printHexByte(f.data[i]);
    if ((uint8_t)(i + 1U) < f.len) LOG_PORT.write(' ');
  }
  LOG_PORT.println();
  f.len = 0;
}

static void captureByte(CaptureFrame &f, uint8_t v, const char *direction)
{
  const uint32_t now = micros();

  if (f.len && (uint32_t)(now - f.lastUs) > FRAME_GAP_US)
    flushFrame(f, direction);

  if (f.len == 0)
    f.firstUs = now;

  if (f.len >= sizeof(f.data)) {
    // Forwarding already happened. This only truncates/segments the USB log.
    droppedLogBytes++;
    flushFrame(f, direction);
    f.firstUs = now;
  }

  f.data[f.len++] = v;
  f.lastUs = now;
}

static inline void serviceMasterToSlave()
{
  while (MasterSide.available() > 0) {
    const int r = MasterSide.read();
    if (r < 0) break;

    const uint8_t b = (uint8_t)r;

    // FIRST forward the byte. Logging is secondary.
    SlaveSide.write(b);
    m2sBytes++;
    captureByte(m2sFrame, b, "M>S");
  }
}

static inline void serviceSlaveToMaster()
{
  while (SlaveSide.available() > 0) {
    const int r = SlaveSide.read();
    if (r < 0) break;

    const uint8_t b = (uint8_t)r;

    // FIRST forward the byte. Logging is secondary.
    MasterSide.write(b);
    s2mBytes++;
    captureByte(s2mFrame, b, "S>M");
  }
}

static inline void flushCompletedFrames()
{
  const uint32_t now = micros();

  if (m2sFrame.len && (uint32_t)(now - m2sFrame.lastUs) > FRAME_GAP_US)
    flushFrame(m2sFrame, "M>S");

  if (s2mFrame.len && (uint32_t)(now - s2mFrame.lastUs) > FRAME_GAP_US)
    flushFrame(s2mFrame, "S>M");
}

void setup()
{
  // Bring the inline bridge up immediately. Do NOT wait for USB enumeration;
  // the hoverboard boards may expect communication during startup.
  MasterSide.begin(LINK_BAUD, SERIAL_8N1);
  SlaveSide.begin(LINK_BAUD, SERIAL_8N1);

  LOG_PORT.begin(115200); // USB CDC; PC baud selection does not set USB speed.

  // No blocking wait for Serial Monitor here.
  delay(10);

  if (LOG_PORT) {
    LOG_PORT.println();
    LOG_PORT.println("Blue Pill hoverboard UART MITM v9 / STM32F103C6");
    LOG_PORT.println("INLINE MODE - original two UART conductors must be interrupted.");
    LOG_PORT.println("Master-facing: PA10=RX from master TX, PA9=TX to master RX");
    LOG_PORT.println("Slave-facing : PA3=RX from slave TX,  PA2=TX to slave RX");
    LOG_PORT.println("Link: 115200 baud, 8-N-1");
    LOG_PORT.println("Format: timestamp  direction  [bytes]  hex data");
    LOG_PORT.println();
  }
}

void loop()
{
  // Service both directions before doing any display work.
  serviceMasterToSlave();
  serviceSlaveToMaster();

  // A second pass reduces latency if bytes arrived while the opposite
  // direction was being serviced.
  serviceMasterToSlave();
  serviceSlaveToMaster();

  flushCompletedFrames();
}
