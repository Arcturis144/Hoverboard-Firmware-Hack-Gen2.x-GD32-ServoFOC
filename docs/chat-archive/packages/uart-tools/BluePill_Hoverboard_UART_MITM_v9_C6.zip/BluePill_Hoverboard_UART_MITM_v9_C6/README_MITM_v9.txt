Blue Pill hoverboard UART MITM v9 - STM32F103C6 / STM32duino 3.0.0
================================================================================

PURPOSE
-------
This replaces the passive v7 sniffer with a transparent full-duplex inline
bridge. The master and slave each get their own RX/TX pair on the Blue Pill.
The Blue Pill forwards traffic in both directions and logs a copy over USB CDC.

Confirmed stock link settings from the captures:
  115200 baud
  8 data bits
  no parity
  1 stop bit

BLUE PILL PINS
--------------
Master-facing USART1:
  PA10 = RX <- MASTER TX
  PA9  = TX -> MASTER RX

Slave-facing USART2:
  PA3  = RX <- SLAVE TX
  PA2  = TX -> SLAVE RX

Common:
  Blue Pill GND -> hoverboard board GND

Do NOT connect the hoverboard 3.3 V rail to the Blue Pill 3.3 V rail.
Power the Blue Pill from USB.

SIGNAL PATH
-----------
MASTER TX -> PA10 -> Blue Pill -> PA2 -> SLAVE RX
SLAVE  TX -> PA3  -> Blue Pill -> PA9 -> MASTER RX

PHYSICAL HARNESS MODIFICATION
-----------------------------
The two UART conductors in the original 4-wire master/slave harness must NOT
remain directly connected between the two hoverboard boards while the Blue Pill
TX outputs are connected.

Intercept ONLY the two UART signal wires:

  UART conductor A:
    master-side end -> PA10
    slave-side end  <- PA2

  UART conductor B:
    slave-side end  -> PA3
    master-side end <- PA9

Keep the other two non-UART harness conductors connected straight through.
One or both may be involved in ground/power/wake, so do not cut them out of the
system merely to insert the UART bridge.

The easiest physical implementation is usually to cut/depin ONLY the two UART
conductors in the cable and bring the four resulting signal ends to the Blue
Pill. This avoids needing to alter the controller PCBs.

IMPORTANT: determine which conductor is master TX versus master RX before
connecting the Blue Pill TX pins. On the master PCB the factory firmware uses:
  PA2 = USART TX
  PA3 = USART RX

ARDUINO IDE SETTINGS
--------------------
  Board: Generic STM32F1 series
  Board part number: BluePill F103C6 (32K)
  U(S)ART support: Enabled (no generic 'Serial')
  USB support: CDC (generic 'Serial' supersede U(S)ART)
  USB speed: Low/Full Speed
  Optimize: Smallest (-Os default)
  Debug symbols and core logs: Symbols Enabled (-g)
  C Runtime Library: Newlib Nano (default)
  Upload method: STM32CubeProgrammer (SWD)

BOOT JUMPERS
------------
  BOOT0 = 0
  BOOT1 = 0

POWER-UP ORDER FOR FIRST BENCH TEST
-----------------------------------
1. Connect the MITM wiring with the hoverboard power OFF.
2. Power the Blue Pill from USB first.
3. Open Serial Monitor if desired.
4. Power the hoverboard master/slave pair.
5. Verify that both M>S and S>M packets appear and that the boards behave as
   they did before insertion of the Blue Pill.

The bridge operates even if Serial Monitor is closed. USB logging is secondary;
bytes are forwarded before being copied to the display buffer.

FAILURE EXPECTATION
-------------------
Because this device is now inline, a Blue Pill reset, loss of USB power, wrong
wiring, or firmware crash can interrupt master/slave communication. Keep wheels
unloaded for the first test.
