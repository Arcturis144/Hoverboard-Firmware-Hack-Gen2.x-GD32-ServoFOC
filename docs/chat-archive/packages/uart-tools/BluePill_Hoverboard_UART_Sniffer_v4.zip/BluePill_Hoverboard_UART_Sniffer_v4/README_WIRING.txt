Blue Pill hoverboard UART sniffer v4
========================================

This revision targets STMicroelectronics STM32 Arduino core 3.0.0.

Core 3.0.0 introduced a BREAKING CHANGE:
  the STM32 implementation class previously named HardwareSerial is now Uart.

Therefore the two explicit hoverboard UARTs are:

  Uart MasterUART(PA10, PA9);  // RX, TX = USART1
  Uart SlaveUART(PA3,  PA2);   // RX, TX = USART2

The Arduino API class named HardwareSerial in core 3.0.0 is an abstract base
class, which is why trying to construct HardwareSerial(PA10, PA9) failed.

Keep these two files in the same sketch folder:
  BluePill_Hoverboard_UART_Sniffer_v4.ino
  SnifferTypes.h

PASSIVE WIRING
--------------
Keep the original hoverboard master/slave harness fully connected.

  Hoverboard MASTER PA2 TX -> Blue Pill PA10
  Hoverboard SLAVE  PA2 TX -> Blue Pill PA3
  Hoverboard GND           -> Blue Pill GND

Do not connect Blue Pill PA9 or PA2 to the hoverboard yet.
Those are Blue Pill TX pins reserved for the later MITM mode.

Recommended Arduino settings for this version:
  Board: Generic STM32F1 series
  Board part number: BluePill F103C8
  USB support: CDC, with USB CDC providing generic Serial
  Upload: STM32CubeProgrammer (SWD)
  Optimize: Debug (-Og) while developing
  C runtime: Newlib Nano

The Uart objects are explicitly instantiated by the sketch; they do not
depend on the core creating Serial1/Serial2 globals.
