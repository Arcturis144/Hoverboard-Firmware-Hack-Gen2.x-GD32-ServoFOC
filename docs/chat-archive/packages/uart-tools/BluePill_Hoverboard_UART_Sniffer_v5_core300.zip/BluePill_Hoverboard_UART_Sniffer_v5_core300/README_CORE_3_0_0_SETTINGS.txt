Blue Pill hoverboard UART sniffer v5 - STM32duino 3.0.0 audit
================================================================

This version was audited against the actual STMicroelectronics Arduino Core
for STM32 tag 3.0.0.

EXACT ARDUINO IDE SETTINGS
--------------------------
Board:
  Generic STM32F1 series

Board part number:
  BluePill F103C8

U(S)ART support:
  Enabled (no generic 'Serial')

USB support:
  CDC (generic 'Serial' supersede U(S)ART)

USB speed:
  Low/Full Speed

Optimize:
  Debug (-Og)

Debug symbols and core logs:
  Symbols Enabled (-g)
  IMPORTANT: do NOT select Core Logs or Core Logs and Symbols.

C Runtime Library:
  Newlib Nano (default)

Upload method:
  STM32CubeProgrammer (SWD)

WHY THESE SETTINGS MATTER
-------------------------
STM32duino 3.0.0 renamed the concrete HardwareSerial implementation to Uart.

"Enabled (no generic 'Serial')" is important: it enables HAL UART support but
defines HWSERIAL_NONE, preventing the core from also creating Serial1 on the
same USART1 peripheral that this sketch explicitly uses.

The USB CDC generic option maps Serial to SerialUSB, so USB is the PC log
channel while USART1 and USART2 remain dedicated to the hoverboard.

"Symbols Enabled (-g)" defines NDEBUG in the 3.0.0 board menu. Core Logs do
not. Core UART debug defaults to the board's PIN_SERIAL_TX (PA9 on Blue Pill),
which would be undesirable because PA9 is our future USART1 TX / MITM pin.

PIN / CLOCK CONFIRMATION FROM CORE 3.0.0
----------------------------------------
The Blue Pill variant maps:
  PA10 = USART1 RX
  PA9  = USART1 TX
  PA3  = USART2 RX
  PA2  = USART2 TX
  PA11 = USB D-
  PA12 = USB D+

The Blue Pill system clock configuration is:
  CPU/HCLK = 72 MHz
  APB1     = 36 MHz
  APB2     = 72 MHz
  USB      = 48 MHz

PASSIVE WIRING
--------------
Keep the original hoverboard master/slave cable connected.

  Hoverboard MASTER PA2 TX -> Blue Pill PA10
  Hoverboard SLAVE  PA2 TX -> Blue Pill PA3
  Hoverboard GND           -> Blue Pill GND

Do NOT connect Blue Pill PA9 or PA2 to the hoverboard yet.

ST-LINK
-------
Use the 4-pin SWD header on the end of the Blue Pill:
  ST-Link SWDIO -> SWIO
  ST-Link SWCLK -> SWCLK
  ST-Link GND   -> GND

If Blue Pill is USB-powered, leave ST-Link 3.3 V disconnected.

FILES
-----
Keep both in the same Arduino sketch directory:
  BluePill_Hoverboard_UART_Sniffer_v5_core300.ino
  SnifferTypes.h

The sketch now contains compile-time checks for the critical menu choices.
If a relevant Arduino setting is wrong, compilation should stop with a
specific message instead of failing later with a misleading linker error.
