This v2 fixes the two compile errors from STM32 Arduino core 3.0.0:

1. PA10 and PA3 are integer Arduino pin macros for the Blue Pill variant,
   so the sketch now uses uint32_t instead of PinName.

2. Arduino's automatic .ino prototype generation was seeing CaptureFrame
   before its declaration. BaudGuess and CaptureFrame now live in
   SnifferTypes.h, which is included before Arduino-generated prototypes.

Keep both files in the same sketch folder:
  BluePill_Hoverboard_UART_Sniffer_v2.ino
  SnifferTypes.h

Passive wiring remains:
  Hoverboard master PA2 TX -> Blue Pill PA10
  Hoverboard slave  PA2 TX -> Blue Pill PA3
  Hoverboard GND           -> Blue Pill GND

Do not connect Blue Pill PA9 or PA2 to the hoverboard yet.
