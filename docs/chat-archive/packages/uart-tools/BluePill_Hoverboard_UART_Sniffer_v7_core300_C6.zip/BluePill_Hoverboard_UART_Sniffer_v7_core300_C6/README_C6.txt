Blue Pill hoverboard UART sniffer v7 - STM32F103C6 / STM32duino 3.0.0
================================================================================

This revision is specifically for the BluePill F103C6:
  32 KiB flash
  10 KiB RAM

Fixes from v6:
- Replaces the accidentally retained FRAME_BUFFER_SIZE reference with
  sizeof(f.data), so the frame-buffer bound is derived directly from the
  CaptureFrame definition.
- Reduces each edge timing buffer from 256 to 128 samples to save 1024 bytes
  of RAM on the C6.
- Adjusts the early baud-detection completion threshold accordingly.
- Corrects target comments from C8/64K to C6/32K.

Arduino IDE settings:
  Board: Generic STM32F1 series
  Board part number: BluePill F103C6 (32K)
  U(S)ART support: Enabled (no generic 'Serial')
  USB support: CDC (generic 'Serial' supersede U(S)ART)
  USB speed: Low/Full Speed
  Optimize: Smallest (-Os default)
  Debug symbols and core logs: Symbols Enabled (-g)
  C Runtime Library: Newlib Nano (default)
  Upload method: STM32CubeProgrammer (SWD)

Passive wiring:
  Hoverboard MASTER PA2 TX -> Blue Pill PA10
  Hoverboard SLAVE  PA2 TX -> Blue Pill PA3
  Hoverboard GND           -> Blue Pill GND

Leave Blue Pill PA9 and PA2 unconnected to the hoverboard for passive sniffing.
