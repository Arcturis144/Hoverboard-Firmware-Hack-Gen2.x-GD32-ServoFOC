/*
  BluePill_Hoverboard_UART_Sniffer_v8_C6_HID.ino

  Target: STM32F103C6 Blue Pill
  Flash: 32 KiB total; HID Bootloader 2.2 reserves 2 KiB (0x800)
  Application starts at 0x08000800.

  Passive hoverboard connections:
    master PA2 TX -> Blue Pill PA10 (USART1 RX)
    slave  PA2 TX -> Blue Pill PA3  (USART2 RX)
    GND            -> Blue Pill GND

  PA9 and PA2 on the Blue Pill remain unconnected to the hoverboard.

  This revision intentionally does NOT use STM32duino Uart/HardwareSerial.
  USART1/USART2 RX are driven directly through the F103 registers to reduce
  flash use on the 32 KiB F103C6.
*/

#include <Arduino.h>
#include "SnifferTypes.h"

static const pin_size_t MASTER_RX_PIN = PA10;
static const pin_size_t SLAVE_RX_PIN  = PA3;

/*
  Required STM32duino 3.0.0 settings:

  Board part number:
    BluePill F103C6 (32K)

  U(S)ART support:
    Disabled

  USB support:
    CDC (generic 'Serial' supersede U(S)ART)

  USB speed:
    Low/Full Speed

  Optimize:
    Smallest (-Os default)

  Debug symbols and core logs:
    Symbols Enabled (-g)

  C Runtime Library:
    Newlib Nano (default)

  Upload method:
    HID Bootloader 2.2
*/

#if defined(HAL_UART_MODULE_ENABLED)
  #error "For v8 select Tools > U(S)ART support > Disabled. v8 drives USART1/2 directly."
#endif

#if !defined(USBCON) || !defined(USBD_USE_CDC)
  #error "Select Tools > USB support > CDC (generic 'Serial' supersede U(S)ART)"
#endif

#if defined(DISABLE_GENERIC_SERIALUSB)
  #error "Select USB CDC with generic Serial enabled."
#endif

#if !defined(NDEBUG)
  #error "Select Debug symbols and core logs > Symbols Enabled (-g), not Core Logs."
#endif

#if !defined(BL_HID)
  #error "Select Tools > Upload method > HID Bootloader 2.2 so the application is linked at 0x08000800."
#endif

#define LOG_PORT Serial

// ---------------- edge timing / baud detector ----------------

static const uint8_t EDGE_SAMPLES = 96;

volatile uint32_t masterDelta[EDGE_SAMPLES];
volatile uint32_t slaveDelta[EDGE_SAMPLES];
volatile uint8_t masterDeltaCount = 0;
volatile uint8_t slaveDeltaCount  = 0;
volatile uint32_t masterLastCycle = 0;
volatile uint32_t slaveLastCycle  = 0;

static const uint32_t baudTable[] = {
  2400, 4800, 9600, 19200, 38400,
  57600, 115200, 230400, 460800
};
static const uint8_t BAUD_COUNT =
    sizeof(baudTable) / sizeof(baudTable[0]);

static inline void enableCycleCounter()
{
  CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
  DWT->CYCCNT = 0;
  DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

void masterEdgeISR()
{
  const uint32_t now = DWT->CYCCNT;
  const uint32_t last = masterLastCycle;
  masterLastCycle = now;

  if (last && masterDeltaCount < EDGE_SAMPLES) {
    const uint32_t d = now - last;
    if (d >= 50) masterDelta[masterDeltaCount++] = d;
  }
}

void slaveEdgeISR()
{
  const uint32_t now = DWT->CYCCNT;
  const uint32_t last = slaveLastCycle;
  slaveLastCycle = now;

  if (last && slaveDeltaCount < EDGE_SAMPLES) {
    const uint32_t d = now - last;
    if (d >= 50) slaveDelta[slaveDeltaCount++] = d;
  }
}

static void scoreSet(
  const volatile uint32_t *samples,
  uint8_t count,
  uint32_t baud,
  uint16_t &fit,
  uint16_t &oneBit,
  uint16_t &used,
  uint32_t &errorSum)
{
  const uint32_t cpb =
      (SystemCoreClock + baud / 2UL) / baud;

  for (uint8_t i = 0; i < count; ++i) {
    const uint32_t d = samples[i];
    const uint32_t bits = (d + cpb / 2UL) / cpb;

    if (bits < 1UL || bits > 20UL) continue;

    ++used;

    const uint32_t expected = cpb * bits;
    const uint32_t diff =
        (d > expected) ? (d - expected) : (expected - d);
    const uint32_t err =
        (diff * 1000UL + expected / 2UL) / expected;

    if (err <= 150UL) {
      ++fit;
      errorSum += err;
      if (bits == 1UL) ++oneBit;
    }
  }
}

static BaudGuess guessBaud(
  const volatile uint32_t *a, uint8_t countA,
  const volatile uint32_t *b, uint8_t countB)
{
  BaudGuess best = {0, 0, 0, 0, 65535, 0};

  for (uint8_t k = 0; k < BAUD_COUNT; ++k) {
    uint16_t fit = 0, oneBit = 0, used = 0;
    uint32_t errorSum = 0;
    const uint32_t baud = baudTable[k];

    if (a && countA) scoreSet(a, countA, baud, fit, oneBit, used, errorSum);
    if (b && countB) scoreSet(b, countB, baud, fit, oneBit, used, errorSum);
    if (!used) continue;

    const uint32_t score =
        (uint32_t)fit * 10UL + (uint32_t)oneBit * 40UL;
    const uint16_t meanErr =
        fit ? (uint16_t)(errorSum / fit) : 65535;

    if (score > best.score ||
        (score == best.score && meanErr < best.meanErrorPermille)) {
      best = {baud, fit, oneBit, used, meanErr, score};
    }
  }

  return best;
}

static void printGuess(char tag, const BaudGuess &g)
{
  LOG_PORT.write(tag);
  LOG_PORT.write(' ');

  if (!g.baud || !g.usedCount) {
    LOG_PORT.println("none");
    return;
  }

  LOG_PORT.print(g.baud);
  LOG_PORT.print(" fit=");
  LOG_PORT.print((100UL * g.fitCount) / g.usedCount);
  LOG_PORT.print("% one=");
  LOG_PORT.print(g.oneBitCount);
  LOG_PORT.print(" err=");
  LOG_PORT.print(g.meanErrorPermille / 10U);
  LOG_PORT.write('.');
  LOG_PORT.print(g.meanErrorPermille % 10U);
  LOG_PORT.println('%');
}

// ---------------- minimal raw USART1 / USART2 RX ----------------

static const uint8_t RX_MASK = 127; // 128-byte rings

volatile uint8_t masterRx[128];
volatile uint8_t slaveRx[128];
volatile uint8_t masterHead = 0, masterTail = 0;
volatile uint8_t slaveHead  = 0, slaveTail  = 0;
volatile uint16_t masterDropped = 0, slaveDropped = 0;

static inline void ringPush(
  volatile uint8_t *buf,
  volatile uint8_t &head,
  volatile uint8_t &tail,
  volatile uint16_t &dropped,
  uint8_t v)
{
  const uint8_t next = (uint8_t)((head + 1U) & RX_MASK);
  if (next == tail) {
    ++dropped;
    return;
  }
  buf[head] = v;
  head = next;
}

extern "C" void USART1_IRQHandler(void)
{
  const uint32_t sr = USART1->SR;

  if (sr & (USART_SR_RXNE | USART_SR_ORE | USART_SR_NE | USART_SR_FE)) {
    const uint8_t v = (uint8_t)USART1->DR;
    if (sr & USART_SR_RXNE)
      ringPush(masterRx, masterHead, masterTail, masterDropped, v);
  }
}

extern "C" void USART2_IRQHandler(void)
{
  const uint32_t sr = USART2->SR;

  if (sr & (USART_SR_RXNE | USART_SR_ORE | USART_SR_NE | USART_SR_FE)) {
    const uint8_t v = (uint8_t)USART2->DR;
    if (sr & USART_SR_RXNE)
      ringPush(slaveRx, slaveHead, slaveTail, slaveDropped, v);
  }
}

static inline bool masterAvailable()
{
  return masterHead != masterTail;
}

static inline bool slaveAvailable()
{
  return slaveHead != slaveTail;
}

static inline uint8_t masterRead()
{
  const uint8_t v = masterRx[masterTail];
  masterTail = (uint8_t)((masterTail + 1U) & RX_MASK);
  return v;
}

static inline uint8_t slaveRead()
{
  const uint8_t v = slaveRx[slaveTail];
  slaveTail = (uint8_t)((slaveTail + 1U) & RX_MASK);
  return v;
}

static void rawUartsBegin(uint32_t baud)
{
  // GPIOA clock, USART1 clock (APB2), USART2 clock (APB1)
  RCC->APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_USART1EN;
  RCC->APB1ENR |= RCC_APB1ENR_USART2EN;

  // PA10 and PA3: input floating (MODE=00, CNF=01 => nibble 0x4)
  GPIOA->CRH = (GPIOA->CRH & ~(0xFUL << 8))  | (0x4UL << 8);   // PA10
  GPIOA->CRL = (GPIOA->CRL & ~(0xFUL << 12)) | (0x4UL << 12);  // PA3

  USART1->CR1 = 0;
  USART1->CR2 = 0;
  USART1->CR3 = 0;
  USART2->CR1 = 0;
  USART2->CR2 = 0;
  USART2->CR3 = 0;

  // F103C6 Blue Pill variant: PCLK2=72 MHz, PCLK1=36 MHz.
  USART1->BRR = (72000000UL + baud / 2UL) / baud;
  USART2->BRR = (36000000UL + baud / 2UL) / baud;

  (void)USART1->SR; (void)USART1->DR;
  (void)USART2->SR; (void)USART2->DR;

  NVIC_ClearPendingIRQ(USART1_IRQn);
  NVIC_ClearPendingIRQ(USART2_IRQn);
  NVIC_SetPriority(USART1_IRQn, 2);
  NVIC_SetPriority(USART2_IRQn, 2);
  NVIC_EnableIRQ(USART1_IRQn);
  NVIC_EnableIRQ(USART2_IRQn);

  USART1->CR1 = USART_CR1_RE | USART_CR1_RXNEIE | USART_CR1_UE;
  USART2->CR1 = USART_CR1_RE | USART_CR1_RXNEIE | USART_CR1_UE;
}

// ---------------- burst logger ----------------

CaptureFrame masterFrame = {{0}, 0, 0, 0};
CaptureFrame slaveFrame  = {{0}, 0, 0, 0};

uint32_t activeBaud = 0;
uint32_t frameGapUs = 1000;

static void printHex(uint8_t v)
{
  static const char hex[] = "0123456789ABCDEF";
  LOG_PORT.write(hex[v >> 4]);
  LOG_PORT.write(hex[v & 15]);
}

static void flushFrame(CaptureFrame &f, char direction)
{
  if (!f.len) return;

  LOG_PORT.print(f.firstUs);
  LOG_PORT.write(' ');
  LOG_PORT.write(direction);
  LOG_PORT.write(' ');
  LOG_PORT.print(f.len);
  LOG_PORT.write(' ');

  for (uint8_t i = 0; i < f.len; ++i) {
    printHex(f.data[i]);
    if (i + 1U < f.len) LOG_PORT.write(' ');
  }
  LOG_PORT.println();
  f.len = 0;
}

static void addByte(CaptureFrame &f, uint8_t v, char direction)
{
  const uint32_t now = micros();

  if (f.len && (uint32_t)(now - f.lastUs) > frameGapUs)
    flushFrame(f, direction);

  if (!f.len) f.firstUs = now;

  if (f.len >= sizeof(f.data)) {
    flushFrame(f, direction);
    f.firstUs = now;
  }

  f.data[f.len++] = v;
  f.lastUs = now;
}

static void serviceSniffer()
{
  while (masterAvailable()) addByte(masterFrame, masterRead(), 'M');
  while (slaveAvailable())  addByte(slaveFrame,  slaveRead(),  'S');

  const uint32_t now = micros();

  if (masterFrame.len &&
      (uint32_t)(now - masterFrame.lastUs) > frameGapUs)
    flushFrame(masterFrame, 'M');

  if (slaveFrame.len &&
      (uint32_t)(now - slaveFrame.lastUs) > frameGapUs)
    flushFrame(slaveFrame, 'S');
}

void setup()
{
  LOG_PORT.begin(115200);

  // USB CDC is initialized by begin(). Wait for the PC to actually open the
  // COM port before doing the one-shot baud measurement, so the result cannot
  // disappear before Serial Monitor is opened.
  while (!LOG_PORT) {
    delay(10);
  }

  LOG_PORT.println("G5 sniffer v8 C6/HID");

  pinMode(MASTER_RX_PIN, INPUT);
  pinMode(SLAVE_RX_PIN, INPUT);

  enableCycleCounter();
  attachInterrupt(digitalPinToInterrupt(MASTER_RX_PIN), masterEdgeISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(SLAVE_RX_PIN),  slaveEdgeISR,  CHANGE);

  const uint32_t start = millis();
  while ((millis() - start) < 5000UL) {
    if (masterDeltaCount >= 64 && slaveDeltaCount >= 64) break;
  }

  noInterrupts();
  detachInterrupt(digitalPinToInterrupt(MASTER_RX_PIN));
  detachInterrupt(digitalPinToInterrupt(SLAVE_RX_PIN));
  interrupts();

  const uint8_t mc = masterDeltaCount;
  const uint8_t sc = slaveDeltaCount;

  LOG_PORT.print("edges M=");
  LOG_PORT.print(mc);
  LOG_PORT.print(" S=");
  LOG_PORT.println(sc);

  const BaudGuess gm = guessBaud(masterDelta, mc, nullptr, 0);
  const BaudGuess gs = guessBaud(slaveDelta, sc, nullptr, 0);
  const BaudGuess gc = guessBaud(masterDelta, mc, slaveDelta, sc);

  printGuess('M', gm);
  printGuess('S', gs);
  printGuess('C', gc);

  activeBaud = gc.baud;
  if (!activeBaud) {
    LOG_PORT.println("no baud; reset");
    return;
  }

  frameGapUs = 50000000UL / activeBaud; // 5 character-times at 8-N-1
  if (frameGapUs < 100UL) frameGapUs = 100UL;

  LOG_PORT.print("RX ");
  LOG_PORT.print(activeBaud);
  LOG_PORT.println(" 8N1");
  LOG_PORT.println("time_us dir len hex");

  rawUartsBegin(activeBaud);
}

void loop()
{
  if (activeBaud) serviceSniffer();
}
