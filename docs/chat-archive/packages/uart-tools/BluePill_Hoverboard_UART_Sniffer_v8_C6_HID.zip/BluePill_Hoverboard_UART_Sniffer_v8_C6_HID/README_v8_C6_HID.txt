Blue Pill G5 dual-UART sniffer v8
===================================

Target
------
STM32F103C6 Blue Pill
32 KiB flash / 10 KiB RAM

This build is designed for HID Bootloader 2.2:
- HID bootloader occupies 0x08000000..0x080007FF (2 KiB)
- Arduino application is linked from 0x08000800
- usable application flash is 30 KiB = 30720 bytes

Why v8 is smaller than v7
-------------------------
- No STM32duino Uart/HardwareSerial objects.
- U(S)ART support must be Disabled.
- USART1 and USART2 receive are configured directly using F103 registers.
- Shorter diagnostic strings.
- 96 edge timing samples per direction.
- 128-byte RX rings and 128-byte burst buffers.
- Integer-only baud detector.
- No 64-bit division in the normal code path.

Arduino STM32 core 3.0.0 settings
---------------------------------
Board:
  Generic STM32F1 series

Board part number:
  BluePill F103C6 (32K)

U(S)ART support:
  Disabled

USB support:
  CDC (generic 'Serial' supersede U(S)ART)

USB speed:
  Low/Full Speed

Optimize:
  Smallest (-Os default)

Debug symbols and core logs:
  Symbols Enabled (-g)
  Do NOT enable Core Logs.

C Runtime Library:
  Newlib Nano (default)

Upload method:
  HID Bootloader 2.2

IMPORTANT:
Selecting HID Bootloader 2.2 is what makes STM32duino 3.0.0 link the sketch
at flash offset 0x800. Do not compile this build as SWD-at-zero after the HID
bootloader has been installed.

Passive wiring
--------------
Hoverboard MASTER PA2 TX -> Blue Pill PA10
Hoverboard SLAVE  PA2 TX -> Blue Pill PA3
Hoverboard GND           -> Blue Pill GND

Do not connect Blue Pill PA9 or PA2 to the hoverboard.

USB behavior
------------
The HID bootloader itself appears as a USB HID device, not as a COM port.
After the bootloader launches this sketch, the sketch initializes USB CDC.
Windows should then create the COM port used by Arduino Serial Monitor.

The sketch waits for the PC to OPEN that CDC COM port before it performs its
one-shot baud detection. This prevents the baud result from being lost before
Serial Monitor is opened.

BOOT jumpers for normal use
---------------------------
BOOT0 = 0
BOOT1 = 0
