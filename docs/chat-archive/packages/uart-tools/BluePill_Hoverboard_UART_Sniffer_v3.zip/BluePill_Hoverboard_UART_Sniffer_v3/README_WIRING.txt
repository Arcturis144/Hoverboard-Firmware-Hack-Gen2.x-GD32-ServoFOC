Blue Pill hoverboard UART sniffer v3
========================================

Fix for STM32 Arduino core 3.0.0 linker error:
  undefined reference to `Serial2'

The Blue Pill variant does not instantiate every SerialN object by default.
This version explicitly creates the two hardware UART objects:

  HardwareSerial MasterUART(PA10, PA9);  // RX, TX = USART1
  HardwareSerial SlaveUART(PA3,  PA2);   // RX, TX = USART2

This follows the STM32duino HardwareSerial API, whose constructor pin order
is RX first, TX second.

Keep BOTH source files in the same Arduino sketch folder:
  BluePill_Hoverboard_UART_Sniffer_v3.ino
  SnifferTypes.h

PASSIVE WIRING
--------------
Keep the stock master/slave harness connected.

  Hoverboard MASTER PA2 TX -> Blue Pill PA10
  Hoverboard SLAVE  PA2 TX -> Blue Pill PA3
  Hoverboard GND           -> Blue Pill GND

Do not connect Blue Pill PA9 or PA2 to the hoverboard yet. Those are the
Blue Pill TX pins and are reserved for the later inline MITM stage.

Native USB CDC remains the PC logging connection.
