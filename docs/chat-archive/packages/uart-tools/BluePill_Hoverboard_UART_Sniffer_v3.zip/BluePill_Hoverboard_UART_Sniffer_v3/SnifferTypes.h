#pragma once
#include <Arduino.h>

struct BaudGuess {
  uint32_t baud;
  uint16_t fitCount;
  uint16_t oneBitCount;
  uint16_t usedCount;
  float meanErrorPercent;
  uint32_t score;
};

struct CaptureFrame {
  uint8_t data[256];
  uint16_t len;
  uint32_t firstUs;
  uint32_t lastUs;
};
